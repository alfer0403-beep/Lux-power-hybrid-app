package com.lux.monitor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlinx.coroutines.delay

import android.content.SharedPreferences
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.rememberTextMeasurer
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.sin

/** Latest current weather from Open-Meteo (filled by fetchForecast). */
class WxData(val code:Int,val cloud:Int,val isDay:Boolean)
object WxState{ var data by mutableStateOf<WxData?>(null) }
/** true = sky scene, false = classic ring. Set from Settings > Appearance. */
object SceneCfg{ var on by mutableStateOf(true) }

@Composable fun HeroOrScene(x:Lux,rt:String){
  if(SceneCfg.on) SkyScene(x,rt) else Hero(x,rt)
}

/** Mobile-only photographic hero. LandscapeBoard continues to use the original HeroOrScene renderer. */
@Composable fun MobileTropicalHero(x:Lux,rt:String){
  val sp=LocalContext.current.getSharedPreferences("c",0)
  var minuteTick by remember { mutableStateOf(0) }
  LaunchedEffect(Unit){ while(true){ delay(60_000); minuteTick++ } }
  val now=remember(minuteTick) { LocalTime.now() }
  val minute=now.hour*60+now.minute
  val (sunrise,sunset)=riseSet(sp)
  val daylight=when {
    minute in sunrise..sunset -> 1f
    else -> 0f
  }
  val wx=WxState.data
  val weatherCode=wx?.code ?: 0
  val rainy=weatherCode in 51..67 || weatherCode in 80..82 || weatherCode>=95
  val cloudy=(wx?.cloud ?: 0)>65
  val night=daylight<0.5f
  val shade=when { rainy -> 0.42f; cloudy -> 0.28f; night -> 0.34f; else -> 0.13f }
  val transition=rememberInfiniteTransition(label="mobile-weather")
  val rainPhase by transition.animateFloat(0f,1f,infiniteRepeatable(tween(1100, easing=LinearEasing)),label="rain")
  val weatherLabel=wxText(wx,if(daylight>0f) 1f else 0f)
  val tempText=if(wx==null) "WEATHER" else weatherLabel.uppercase()

  Card(
    modifier=Modifier.fillMaxWidth(),
    shape=RoundedCornerShape(24.dp),
    colors=androidx.compose.material3.CardDefaults.cardColors(containerColor=Color(0xFF101923))
  ){
    Box(Modifier.fillMaxWidth().aspectRatio(1.18f).clip(RoundedCornerShape(24.dp))){
      Image(painterResource(R.drawable.lux_tropical_home),contentDescription="Tropical home with rooftop solar panels",modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
      Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF081321).copy(alpha=shade+0.10f),Color.Transparent,Color(0xFF050A10).copy(alpha=0.82f)))))
      // Weather tint and rain are driven by the same Open-Meteo state used by SkyScene.
      Canvas(Modifier.fillMaxSize()){
        if(cloudy || rainy){
          drawRect(Color(0xFF64748B).copy(alpha=if(rainy) 0.16f else 0.08f))
        }
        if(rainy){
          repeat(54){ i->
            val px=((i*47)%size.width.toInt().coerceAtLeast(1)).toFloat()
            val py=(((i*67)%size.height.toInt().coerceAtLeast(1))+rainPhase*size.height).rem(size.height)
            drawLine(Color(0xFFB7D9F2).copy(alpha=0.32f),Offset(px,py),Offset(px-5f,py+13f),1.2f)
          }
        }
        // Slight cool tint after sunset, without replacing the existing dynamic sky renderer.
        if(night) drawRect(Color(0xFF07152D).copy(alpha=0.16f))
      }
      Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.SpaceBetween){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.Top,horizontalArrangement=Arrangement.SpaceBetween){
          Column {
            Text("LUX MONITOR",fontSize=17.sp,letterSpacing=2.2.sp,fontWeight=FontWeight.Bold,color=Color.White)
            Text("SMART ENERGY · SMARTER LIVING",fontSize=8.sp,letterSpacing=1.1.sp,color=Color.White.copy(alpha=0.82f))
          }
          Column(horizontalAlignment=Alignment.End){
            Text(if(wx==null) "Add location" else tempText,fontSize=10.sp,fontWeight=FontWeight.SemiBold,color=Color.White)
            Text("${now.hour.toString().padStart(2,'0')}:${now.minute.toString().padStart(2,'0')}",fontSize=11.sp,color=Color.White.copy(alpha=0.82f))
          }
        }
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
            MobileFlowMetric("SOLAR",kw(x.pv),AMBER,Modifier.weight(1f))
            Text("→",fontSize=13.sp,color=Color.White.copy(alpha=0.78f))
            MobileFlowMetric("HOME",kw(x.load),VIOLET,Modifier.weight(1f))
            Text(if(x.charge>20) "↓" else if(x.discharge>20) "↑" else "·",fontSize=13.sp,color=GREEN)
            MobileFlowMetric("BATTERY","${x.soc}%",GREEN,Modifier.weight(1f))
          }
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            MobileFlowMetric(if(x.gridOut>20) "GRID EXPORT" else "GRID IMPORT",kw(if(x.gridOut>20) x.gridOut else x.gridIn),if(x.gridOut>20) CYAN else BLUE,Modifier.weight(1f))
            MobileFlowMetric("BATTERY VOLTAGE","${x.vBat} V",GREEN,Modifier.weight(1f))
          }
          Text("Energy flow follows live inverter readings · Runtime $rt",fontSize=9.sp,color=Color.White.copy(alpha=0.82f),modifier=Modifier.align(Alignment.CenterHorizontally))
        }
      }
    }
  }
}

@Composable private fun MobileFlowMetric(label:String,value:String,color:Color,modifier:Modifier){
  Column(modifier.clip(RoundedCornerShape(13.dp)).background(Color(0xD90A121B)).padding(horizontal=9.dp,vertical=8.dp)){
    Text(label,fontSize=8.sp,letterSpacing=0.7.sp,color=Color(0xFFB9C5D4),maxLines=1)
    Text(value,fontSize=14.sp,fontWeight=FontWeight.Bold,color=Color(0xFFF1F5F9),maxLines=1)
    Box(Modifier.padding(top=4.dp).fillMaxWidth().height(2.dp).clip(RoundedCornerShape(2.dp)).background(color.copy(alpha=0.78f)))
  }
}

private fun riseSet(sp:SharedPreferences):Pair<Int,Int>{
  val lat=sp.getString("lat","")!!.toDoubleOrNull(); val lon=sp.getString("lon","")!!.toDoubleOrNull()
  return (if(lat!=null&&lon!=null) sunTimes(lat,lon,LocalDate.now()) else null) ?: Pair(390,1110)
}
private fun wxText(w:WxData?,day:Float):String{
  if(w==null) return "Add location"
  return when{
    w.code==0 -> if(day<0.5f) "Clear night" else "Clear"
    w.code in 1..3 -> "Partly cloudy"
    w.code==45||w.code==48 -> "Fog"
    w.code in 51..67||w.code in 80..82 -> "Rain"
    w.code in 71..77||w.code in 85..86 -> "Snow"
    w.code>=95 -> "Thunderstorm"
    else -> "Cloudy"
  }
}
private fun DrawScope.drawCloud(cx:Float,cy:Float,s:Float,k:Float,col:Color,a:Float){
  drawRoundRect(color=col,topLeft=Offset((cx-38f*s)*k,(cy-6f*s)*k),size=Size(76f*s*k,22f*s*k),cornerRadius=CornerRadius(11f*s*k),alpha=a)
  drawCircle(color=col,radius=15f*s*k,center=Offset((cx-14f*s)*k,(cy-6f*s)*k),alpha=a)
  drawCircle(color=col,radius=20f*s*k,center=Offset((cx+6f*s)*k,(cy-10f*s)*k),alpha=a)
  drawCircle(color=col,radius=13f*s*k,center=Offset((cx+26f*s)*k,(cy-4f*s)*k),alpha=a)
}

/** Sky that follows the real time of day (sunrise and sunset from your location), the weather, and the battery/solar state. */
@Composable fun SkyScene(x:Lux,rt:String){
  val sp=LocalContext.current.getSharedPreferences("c",0)
  val tm=rememberTextMeasurer()
  val anim by rememberInfiniteTransition(label="sky").animateFloat(0f,1f,infiniteRepeatable(tween(4000,easing=LinearEasing)),label="a")
  val now=LocalTime.now(); val m=now.hour*60+now.minute
  val (rise,set)=riseSet(sp)
  val w=WxState.data; val code=w?.code?:0; val cloud=w?.cloud?:10
  val dawnT=((m-(rise-40)).toFloat()/80f).coerceIn(0f,1f)
  val duskT=(((set+40)-m).toFloat()/80f).coerceIn(0f,1f)
  val day=minOf(dawnT,duskT)
  val warm=(maxOf(0f,1f-abs((m-rise).toFloat())/50f)+maxOf(0f,1f-abs((m-set).toFloat())/50f)).coerceAtMost(1f)
  val rainy=code in 51..67||code in 80..82||code>=95
  val snowy=code in 71..77||code in 85..86
  val grey=if(rainy||snowy||cloud>70) 0.35f else 0f
  val top=lerp(lerp(Color(0xFF04070D),Color(0xFF0D2440),day),Color(0xFF1B2330),grey)
  val bot=lerp(lerp(lerp(Color(0xFF0B1628),Color(0xFF24527F),day),Color(0xFFE0784A),warm*0.55f),Color(0xFF232B38),grey)
  val inDay=m in rise..set
  val tt=if(inDay) (m-rise).toFloat()/maxOf(1,set-rise).toFloat()
    else ((m-set+1440)%1440).toFloat()/maxOf(1,(rise-set+1440)%1440).toFloat()
  val clock="%02d:%02d".format(now.hour,now.minute)
  Canvas(Modifier.fillMaxWidth().aspectRatio(360f/330f)){
    val k=size.width/360f
    fun P(a:Float,b:Float)=Offset(a*k,b*k)
    fun pt(u:Float,v:Float)=P(60f+150f*u-16f*v,140f-36f*v)
    val ground=236f
    val facade=lerp(Color(0xFF0A0F16),lerp(CARD,Color.White,0.09f),0.35f+0.65f*day)
    val facadeHi=lerp(facade,Color.White,0.06f)
    val edge=lerp(LINE,LINE2,0.5f)
    val carC=lerp(Color(0xFFE6EDF5),CARD,(1f-day)*0.4f)
    // sky and ground
    drawRect(brush=Brush.verticalGradient(listOf(top,bot),0f,ground*k),size=Size(size.width,ground*k))
    drawRect(brush=Brush.verticalGradient(listOf(lerp(bot,Color.Black,0.5f),BG),ground*k,size.height),topLeft=Offset(0f,ground*k),size=Size(size.width,size.height-ground*k))
    // stars at night
    val starA=(1f-day)*(if(cloud>60) 0.35f else 0.9f)
    if(starA>0.02f){
      val rnd=java.util.Random(11)
      repeat(70){
        val sx=rnd.nextFloat()*360f; val sy=rnd.nextFloat()*200f; val ph=rnd.nextFloat()*6.28f
        drawCircle(color=Color.White,radius=(0.6f+rnd.nextFloat()*0.9f)*k,center=P(sx,sy),alpha=starA*(0.55f+0.45f*sin(anim*6.28f+ph)))
      }
    }
    // sun by day, moon by night, both travelling the same arc
    val ax=40f+280f*tt; val ay=118f-92f*sin(Math.PI.toFloat()*tt)
    if(day>0.05f){
      val sc=P(ax,ay)
      drawCircle(brush=Brush.radialGradient(colors=listOf(Color(0xFFFDE68A).copy(alpha=0.5f*day),Color.Transparent),center=sc,radius=70f*k),radius=70f*k,center=sc)
      drawCircle(color=Color(0xFFFDE68A),radius=13f*k,center=sc,alpha=day)
    }
    if(day<0.95f){
      val mc=P(ax,ay); val ma=1f-day
      drawCircle(color=Color(0xFFE2E8F0),radius=11f*k,center=mc,alpha=ma)
      drawCircle(color=top,radius=10f*k,center=mc+Offset(5f*k,-3f*k),alpha=ma)
    }
    // clouds: more cover, more clouds; rain adds two more
    val nClouds=(when{ cloud<15->0; cloud<40->2; cloud<70->4; else->6 })+(if(rainy) 2 else 0)
    val cCol=lerp(Color(0xFF8DA2BF),Color(0xFF2A3446),1f-day)
    repeat(nClouds){ i->
      val cx=(((i*97+40)%400).toFloat()+anim*60f*(1f+(i%3)*0.3f))%400f-20f
      val cy=40f+((i*29)%70).toFloat()
      drawCloud(cx,cy,0.9f+(i%3)*0.25f,k,cCol,0.3f+0.35f*(cloud/100f))
    }
    if(rainy){ repeat(42){ i->
      val x=((i*53)%360).toFloat(); val y=((((i*41)%250).toFloat()+anim*250f)%250f)+40f
      if(y<ground-4f) drawLine(color=Color(0xFF9ED8FF),start=P(x,y),end=P(x-5f,y+12f),strokeWidth=1.2f*k,cap=StrokeCap.Round,alpha=0.4f)
    } }
    if(snowy){ repeat(36){ i->
      val x=((i*61)%360).toFloat(); val y=((((i*43)%250).toFloat()+anim*250f)%250f)+40f
      if(y<ground-4f) drawCircle(color=Color.White,radius=1.8f*k,center=P(x,y),alpha=0.7f)
    } }
    if(code==45||code==48) drawRect(color=Color(0xFFB8C4D6),topLeft=P(0f,150f),size=Size(size.width,80f*k),alpha=0.22f)
    if(code>=95&&anim>0.94f) drawRect(color=Color.White,alpha=0.12f)
    // horizon
    drawLine(color=lerp(Color(0xFFE0784A),LINE2,0.6f).copy(alpha=0.25f+0.35f*warm),start=P(0f,ground),end=P(360f,ground),strokeWidth=1f*k)
    // grid pole
    val pole=lerp(Color(0xFF8A99AD),LINE2,0.3f)
    drawLine(color=pole,start=P(28f,ground),end=P(28f,118f),strokeWidth=2.5f*k,cap=StrokeCap.Round)
    drawLine(color=pole,start=P(16f,128f),end=P(40f,128f),strokeWidth=2f*k,cap=StrokeCap.Round)
    drawLine(color=pole.copy(alpha=0.6f),start=P(16f,128f),end=P(2f,142f),strokeWidth=0.8f*k)
    drawLine(color=pole.copy(alpha=0.6f),start=P(40f,128f),end=P(56f,142f),strokeWidth=0.8f*k)
    // house: main block, cantilever upper box, garage with car
    drawRoundRect(color=facade,topLeft=P(56f,140f),size=Size(158f*k,96f*k),cornerRadius=CornerRadius(4f*k))
    drawRoundRect(color=lerp(facade,Color.White,0.12f),topLeft=P(48f,132f),size=Size(176f*k,10f*k),cornerRadius=CornerRadius(3f*k))
    drawRoundRect(color=facadeHi,topLeft=P(214f,108f),size=Size(86f*k,42f*k),cornerRadius=CornerRadius(4f*k))
    drawRoundRect(color=lerp(facadeHi,Color.White,0.12f),topLeft=P(208f,102f),size=Size(98f*k,8f*k),cornerRadius=CornerRadius(3f*k))
    drawRoundRect(color=facade,topLeft=P(262f,186f),size=Size(82f*k,50f*k),cornerRadius=CornerRadius(3f*k))
    drawRoundRect(color=lerp(facade,Color.White,0.12f),topLeft=P(258f,180f),size=Size(90f*k,7f*k),cornerRadius=CornerRadius(3f*k))
    drawRect(color=Color(0xFF05080D),topLeft=P(270f,196f),size=Size(66f*k,40f*k))
    drawRoundRect(color=carC,topLeft=P(276f,212f),size=Size(60f*k,16f*k),cornerRadius=CornerRadius(7f*k))
    drawRoundRect(color=carC,topLeft=P(288f,203f),size=Size(34f*k,12f*k),cornerRadius=CornerRadius(6f*k))
    drawCircle(color=Color(0xFF05080D),radius=4f*k,center=P(288f,230f))
    drawCircle(color=Color(0xFF05080D),radius=4f*k,center=P(326f,230f))
    // windows: dark glass by day, warm light by night
    fun win(x0:Float,y0:Float,w0:Float,h0:Float){
      drawRoundRect(color=lerp(Color(0xFF0A1220),Color(0xFF2A4A6E),day*0.6f),topLeft=P(x0,y0),size=Size(w0*k,h0*k),cornerRadius=CornerRadius(3f*k))
      drawRoundRect(color=lerp(Color(0xFF3A2A12),AMBER,0.85f),topLeft=P(x0,y0),size=Size(w0*k,h0*k),cornerRadius=CornerRadius(3f*k),alpha=(1f-day)*0.9f)
      drawRoundRect(brush=Brush.verticalGradient(listOf(Color.White.copy(alpha=0.14f*day),Color.Transparent),y0*k,(y0+h0)*k),topLeft=P(x0,y0),size=Size(w0*k,h0*k),cornerRadius=CornerRadius(3f*k))
      drawLine(color=lerp(facade,Color.White,0.25f),start=P(x0+w0/2f,y0),end=P(x0+w0/2f,y0+h0),strokeWidth=1.5f*k)
      if(day<0.9f) drawCircle(color=AMBER,radius=38f*k,center=P(x0+w0/2f,y0+h0/2f),alpha=0.08f*(1f-day))
    }
    win(72f,164f,50f,40f); win(132f,164f,50f,40f); win(226f,118f,62f,20f)
    // solar array on the roof plane
    val pp=Path().apply{ val a=pt(0f,0f); val b=pt(1f,0f); val c=pt(1f,1f); val d=pt(0f,1f); moveTo(a.x,a.y); lineTo(b.x,b.y); lineTo(c.x,c.y); lineTo(d.x,d.y); close() }
    drawPath(path=pp,color=lerp(Color(0xFF0C2238),Color(0xFF1F4C7A),day))
    for(i in 1..3) drawLine(color=Color(0xFF2B5C84),start=pt(i/4f,0f),end=pt(i/4f,1f),strokeWidth=1f*k)
    drawLine(color=Color(0xFF2B5C84),start=pt(0f,0.5f),end=pt(1f,0.5f),strokeWidth=1f*k)
    drawPath(path=pp,color=Color.White,alpha=0.05f+0.08f*day,style=Stroke(1.2f*k))
    // inverter on the wall
    drawRoundRect(color=lerp(Color(0xFFD8E0EA),Color(0xFF3A4656),1f-day),topLeft=P(190f,186f),size=Size(18f*k,24f*k),cornerRadius=CornerRadius(3f*k))
    drawCircle(color=GREEN,radius=1.6f*k,center=P(199f,197f))
    // battery stack, filled to the state of charge
    val bx=222f; val byy=196f; val bw=24f; val bh=40f
    drawRoundRect(color=Color(0xFF0E1622),topLeft=P(bx,byy),size=Size(bw*k,bh*k),cornerRadius=CornerRadius(3f*k))
    val fh=(bh-4f)*x.soc/100f
    if(fh>0.5f) drawRoundRect(brush=Brush.verticalGradient(listOf(GREEN,CYAN),(byy+bh-2f-fh)*k,(byy+bh-2f)*k),topLeft=P(bx+2f,byy+bh-2f-fh),size=Size((bw-4f)*k,fh*k),cornerRadius=CornerRadius(2f*k))
    for(j in 1..2) drawLine(color=Color(0xFF05080D).copy(alpha=0.6f),start=P(bx+2f,byy+bh*j/3f),end=P(bx+bw-2f,byy+bh*j/3f),strokeWidth=1f*k)
    drawRoundRect(color=edge,topLeft=P(bx,byy),size=Size(bw*k,bh*k),cornerRadius=CornerRadius(3f*k),style=Stroke(1f*k))
    drawRect(color=edge,topLeft=P(bx+8f,byy-3f),size=Size(8f*k,3f*k))
    // animated power flows
    fun flow(a:Offset,b:Offset,on:Boolean,col:Color,fwd:Boolean){
      if(!on){ drawLine(color=LINE2.copy(alpha=0.5f),start=a,end=b,strokeWidth=2f*k,cap=StrokeCap.Round); return }
      val ph=(if(fwd) 1f-anim else anim)*12f*k
      drawLine(color=col.copy(alpha=0.25f),start=a,end=b,strokeWidth=5f*k,cap=StrokeCap.Round)
      drawLine(color=col,start=a,end=b,strokeWidth=2.6f*k,cap=StrokeCap.Round,pathEffect=PathEffect.dashPathEffect(floatArrayOf(6f*k,8f*k),ph))
    }
    flow(pt(0.5f,0f),P(199f,186f),x.pv>20,AMBER,true)
    flow(P(208f,200f),P(222f,210f),x.charge>20||x.discharge>20,if(x.charge>20) GREEN else RED,x.charge>20)
    flow(P(190f,206f),P(30f,206f),x.gridOut>20||x.gridIn>20,if(x.gridOut>20) CYAN else BLUE,x.gridOut>20)
    flow(P(199f,210f),P(199f,234f),x.load>20,VIOLET,true)
    // readouts
    label(tm,"${x.soc}%",14f*k,34f*k,30f*k,WHITE,mono=true,bold=true)
    label(tm,"Runtime $rt",14f*k,58f*k,11f*k,DIM)
    label(tm,wxText(w,day),236f*k,20f*k,11f*k,WHITE,bold=true)
    label(tm,clock,236f*k,36f*k,11f*k,DIM,mono=true)
    label(tm,"SOLAR",150f*k,66f*k,9f*k,AMBER,center=true)
    label(tm,kw(x.pv),150f*k,82f*k,15f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,if(x.gridOut>20) "TO GRID" else "FROM GRID",14f*k,252f*k,9f*k,if(x.gridOut>20) CYAN else BLUE)
    label(tm,kw(if(x.gridOut>20) x.gridOut else x.gridIn),14f*k,268f*k,14f*k,WHITE,mono=true,bold=true)
    label(tm,"HOME",199f*k,252f*k,9f*k,VIOLET,center=true)
    label(tm,kw(x.load),199f*k,268f*k,14f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,if(x.charge>20) "CHARGING" else if(x.discharge>20) "DISCHARGING" else "BATTERY",262f*k,252f*k,9f*k,GREEN)
    label(tm,"${x.soc}%",262f*k,268f*k,14f*k,WHITE,mono=true,bold=true)
  }
}
