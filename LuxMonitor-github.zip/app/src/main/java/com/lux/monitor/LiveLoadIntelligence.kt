package com.lux.monitor

import android.content.SharedPreferences
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

/** A user-confirmed wattage/name pair. A match is a hint, never proof of appliance state. */
private data class LearnedLoad(val watts: Double, val name: String)

private object LiveLoadLabels {
    private const val KEY = "liveLoadLabels"

    private fun read(sp: SharedPreferences): List<LearnedLoad> {
        val json = runCatching { JSONArray(sp.getString(KEY, "[]")) }.getOrNull()
            ?: return emptyList()
        return (0 until json.length()).mapNotNull { i ->
            runCatching {
                val item = json.getJSONObject(i)
                LearnedLoad(item.getDouble("w"), item.getString("n"))
            }.getOrNull()
        }.filter { it.watts > 0.0 && it.name.isNotBlank() }
    }

    fun find(sp: SharedPreferences, watts: Double): LearnedLoad? {
        if (watts < 100.0) return null
        return read(sp)
            .filter { abs(it.watts - watts) <= maxOf(150.0, it.watts * 0.22) }
            .minByOrNull { abs(it.watts - watts) }
    }

    fun save(sp: SharedPreferences, watts: Double, name: String) {
        if (watts < 100.0 || name.isBlank()) return
        val updated = read(sp).filterNot {
            abs(it.watts - watts) <= maxOf(150.0, it.watts * 0.22)
        } + LearnedLoad(watts, name.trim())
        val json = JSONArray()
        updated.forEach { json.put(JSONObject().put("w", it.watts).put("n", it.name)) }
        sp.edit().putString(KEY, json.toString()).apply()
    }
}

/**
 * Compares the measured inverter load with the estimated always-on baseline.
 * Appliance suggestions and saved wattage matches are explicitly estimates.
 */
@Composable
fun LiveLoadIntelligenceCard(
    actualLoadW: Number,
    baselineWatts: Number?,
    sp: SharedPreferences
) {
    val actual = actualLoadW.toDouble().coerceAtLeast(0.0)
    val baseline = baselineWatts?.toDouble()?.coerceAtLeast(0.0)
    val difference = baseline?.let { actual - it }
    val extra = difference?.coerceAtLeast(0.0) ?: 0.0
    var revision by remember { mutableStateOf(0) }
    val learned = remember(extra, revision) { LiveLoadLabels.find(sp, extra) }
    val suggestion = if (extra >= 100.0) guessLoad(extra.roundToInt(), 1, 0.0) else null

    var loadName by remember { mutableStateOf(learned?.name ?: "") }
    var savedMessage by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "MEASURED HOUSEHOLD LOAD",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${actual.roundToInt()} W",
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "EXTRA LOAD",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = difference?.let { "${extra.roundToInt()} W" } ?: "—",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (baseline == null) {
                Text(
                    "The always-on baseline is not available yet. The app needs enough recorded history before it can estimate extra load.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    "Estimated always-on baseline: ${baseline.roundToInt()} W",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (difference != null && difference < 0.0) {
                    Text(
                        "Measured load is below the baseline estimate. Check the baseline; the measured reading has not been changed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            if (baseline != null && extra >= 100.0) {
                if (learned != null) {
                    Text(
                        "Previously identified as: ${learned.name} (matched by similar wattage)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text(
                        "Possible load: ${suggestion ?: "Unidentified appliance"}. This is only a wattage-based suggestion.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                OutlinedTextField(
                    value = loadName,
                    onValueChange = { loadName = it; savedMessage = "" },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Name this extra load") },
                    placeholder = { Text(suggestion ?: "e.g. Living room A/C") }
                )
                Button(
                    onClick = {
                        LiveLoadLabels.save(sp, extra, loadName)
                        if (loadName.isNotBlank()) {
                            savedMessage = "Saved. Similar wattage loads can now be labelled ${loadName.trim()}."
                            revision++
                        }
                    },
                    enabled = loadName.isNotBlank() && extra >= 100.0,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (learned == null) "Save name and teach the app" else "Update learned name")
                }
                if (savedMessage.isNotBlank()) {
                    Text(savedMessage, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary)
                }
            } else if (baseline != null) {
                Text(
                    "No significant extra load above the estimated baseline right now.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                "Learning is based on the wattage you confirm. Similar total-load readings may include more than one appliance; this does not prove which device is on.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
