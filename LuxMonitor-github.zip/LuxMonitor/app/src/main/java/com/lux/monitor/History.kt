package com.lux.monitor
import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import android.net.Uri
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZoneOffset
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

class Pt(val t:Long,val pv:Int,val bat:Int,val grid:Int,val load:Int,val soc:Int)

/** One sample per minute, kept for 7 days in app storage. bat: + = charging, grid: + = export. */
object History{
  val pts=mutableStateListOf<Pt>()
  private var file:File?=null; private var last=0L
  fun init(ctx:Context){
    if(file!=null) return
    val f=File(ctx.filesDir,"history.csv"); file=f
    val cut=System.currentTimeMillis()-7*86400000L
    if(f.exists()) f.forEachLine{ l->
      val p=l.split(",")
      val t=p.getOrNull(0)?.toLongOrNull()
      if(p.size==6&&t!=null&&t>=cut) pts.add(Pt(t,p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt())) }
  }
  fun add(ctx:Context,x:Lux){
    init(ctx); val now=System.currentTimeMillis(); if(now-last<60000) return; last=now
    val p=Pt(now,x.pv,x.charge-x.discharge,x.gridOut-x.gridIn,x.load,x.soc); pts.add(p)
    file!!.appendText("${p.t},${p.pv},${p.bat},${p.grid},${p.load},${p.soc}\n")
    if(pts.size>10100){ pts.subList(0,100).clear(); file!!.writeText(pts.joinToString(""){"${it.t},${it.pv},${it.bat},${it.grid},${it.load},${it.soc}\n"}) }
  }
  fun export(ctx:Context):String{
    if(android.os.Build.VERSION.SDK_INT<29) return "Export needs Android 10 or newer"
    init(ctx)
    val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"LuxMonitor_history.csv");put(MediaStore.Downloads.MIME_TYPE,"text/csv")}
    val u=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v)?:return "Export failed"
    val df=SimpleDateFormat("yyyy-MM-dd HH:mm")
    ctx.contentResolver.openOutputStream(u)?.use{ o->
      o.write("time,solar_w,battery_w(charging+),grid_w(export+),load_w,soc\n".toByteArray())
      pts.forEach{ o.write("${df.format(Date(it.t))},${it.pv},${it.bat},${it.grid},${it.load},${it.soc}\n".toByteArray()) } }
    return "Saved to Downloads/LuxMonitor_history.csv"
  }
}

/** Day totals (from the inverter's own daily counters), kept indefinitely. Order: yield, consumption, import, export, charge, discharge. */
object Daily{
  val days=mutableStateMapOf<String,List<Double>>()
  private var file:File?=null; private var last=0L
  fun init(ctx:Context){
    if(file!=null) return
    val f=File(ctx.filesDir,"daily.csv"); file=f
    if(f.exists()) f.forEachLine{ l-> val p=l.split(","); if(p.size>=7) days[p[0]]=p.drop(1).map{it.toDoubleOrNull()?:0.0} }
  }
  fun put(ctx:Context,x:Lux){
    init(ctx); val key=LocalDate.now().toString()
    val dm=maxOf(days[key]?.getOrNull(9)?:0.0,if(x.cellMaxV>0) (x.cellMaxV-x.cellMinV)*1000.0 else 0.0)
    days[key]=listOf(x.yld,x.cons,x.impDay,x.expDay,x.chgDay,x.dischgDay,x.e1,x.e2,x.e3,dm)
    val n=System.currentTimeMillis(); if(n-last<60000) return; last=n
    flush()
  }
  fun flush(){ file?.writeText(days.entries.sortedBy{it.key}.joinToString(""){"${it.key},${it.value.joinToString(",")}\n"}) }
  fun sum(from:LocalDate,to:LocalDate):Pair<List<Double>,Int>{
    var d=from; val t=MutableList(6){0.0}; var n=0
    while(!d.isAfter(to)){ days[d.toString()]?.let{ v-> n++; for(i in 0..5) t[i]+=v[i] }; d=d.plusDays(1) }
    return Pair(t,n)
  }
}

/** Monthly totals imported from a Home Assistant Energy dashboard CSV. Order: yield, consumption, import, export, charge, discharge, import cost, export credit. */
object Monthly{
  val rows=mutableStateMapOf<String,List<Double>>()
  private var file:File?=null
  fun init(ctx:Context){
    if(file!=null) return
    val f=File(ctx.filesDir,"monthly.csv"); file=f
    if(f.exists()) f.forEachLine{ l-> val p=l.split(","); if(p.size==9) rows[p[0]]=p.drop(1).map{it.toDoubleOrNull()?:0.0} }
  }
  fun save(){ file?.writeText(rows.entries.sortedBy{it.key}.joinToString(""){"${it.key},${it.value.joinToString(",")}\n"}) }
  fun lastComplete():Pair<String,List<Double>>?{
    val cur=YearMonth.now().toString()
    return rows.entries.filter{it.key<cur}.maxByOrNull{it.key}?.let{ Pair(it.key,it.value) }
  }
  fun importCsv(ctx:Context,uri:Uri):String{
    init(ctx); Daily.init(ctx)
    val lines=ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readLines()?:return "Couldn't read the file"
    if(lines.size<2) return "The file is empty"
    val h=lines[0].removePrefix("\uFEFF").split(",")
    if(h.size<4||h[1]!="type") return "This doesn't look like a Home Assistant energy export"
    val inst=h.drop(3).map{ runCatching{Instant.parse(it)}.getOrNull() }
    if(inst.any{it==null}) return "Unexpected date columns"
    val hrs=if(inst.size>1) Duration.between(inst[0],inst[1]).toHours() else 720L
    val idx=mapOf("solar_production" to 0,"calculated_total_consumption" to 1,"grid_consumption" to 2,"grid_return" to 3,
      "battery_in" to 4,"battery_out" to 5,"grid_consumption_cost" to 6,"grid_return_compensation" to 7)
    val tmp=HashMap<String,DoubleArray>()
    for(l in lines.drop(1)){
      val c=l.split(","); val k=idx[c.getOrNull(1)]?:continue
      for(j in inst.indices){
        val v=c.getOrNull(3+j)?.toDoubleOrNull()?:continue; val t=inst[j]!!
        val key=if(hrs>=600) t.plusSeconds(43200).atZone(ZoneOffset.UTC).toLocalDate().toString().substring(0,7)
          else if(hrs>=20) t.plusSeconds(43200).atZone(ZoneOffset.UTC).toLocalDate().toString()
          else t.atZone(ZoneId.systemDefault()).toLocalDate().toString()
        tmp.getOrPut(key){DoubleArray(8)}[k]+=v } }
    var m=0; var d=0
    for((k,a) in tmp){ if(k.length==7){ rows[k]=a.toList(); m++ } else { Daily.days[k]=a.take(6); d++ } }
    file!!.writeText(rows.entries.sortedBy{it.key}.joinToString(""){"${it.key},${it.value.joinToString(",")}\n"})
    Daily.flush()
    return if(m+d==0) "No usable rows found" else "Imported $m months and $d days"
  }
}
