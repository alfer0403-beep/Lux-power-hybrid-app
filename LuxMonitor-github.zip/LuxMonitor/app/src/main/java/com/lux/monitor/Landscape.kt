package com.lux.monitor
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.background
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Always-open card, same look as a Section. */
@Composable fun Panel(title:String,ic:Path,col:Color,mod:Modifier=Modifier,content:@Composable ColumnScope.()->Unit){
  Card(mod,shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
      Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
        Ico(ic,col,16); Text(title,fontSize=11.sp,letterSpacing=1.5.sp,fontWeight=FontWeight.Bold,color=WHITE) }
      content() } }
}

/** Landscape layout: daily energy on the left, flow diagram in the middle, efficiency and battery on the right, power graph across the bottom. */
@Composable fun LandscapeBoard(x:Lux,rt:String){
  val hist=Store.d!=null&&History.pts.size>30
  val cd=if(Store.d==null) DS else chartData(if(hist) 1 else 0)
  val tl=if(Store.d==null) listOf("00:00","12:00","24:00") else timeLabels(if(hist) 1 else 0)
  Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(10.dp)){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.CenterVertically){
      Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Panel("DAILY ENERGY",I_SOL,AMBER,Modifier.fillMaxWidth()){
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){ Kpi("YIELD",x.yld,AMBER,I_SOL,Modifier.weight(1f)); Kpi("USED",x.cons,VIOLET,I_HOME,Modifier.weight(1f)) }
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){ Kpi("IMPORT",x.impDay,BLUE,I_GRID,Modifier.weight(1f)); Kpi("EXPORT",x.expDay,CYAN,I_GRID,Modifier.weight(1f)) }
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){ Kpi("BAT IN",x.chgDay,GREEN,I_BAT,Modifier.weight(1f)); Kpi("BAT OUT",x.dischgDay,GREEN,I_BAT,Modifier.weight(1f)) } } }
      Card(Modifier.weight(1.25f),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=CARD)){ Hero(x,rt) }
      Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Panel("EFFICIENCY",I_INV,CYAN,Modifier.fillMaxWidth()){
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Ratio("SELF-USE",if(x.yld>0) ((x.yld-x.expDay)/x.yld).toFloat() else 0f,VIOLET,I_HOME,Modifier.weight(1f))
            Ratio("AUTARKY",if(x.cons>0) (1-x.impDay/x.cons).toFloat() else 0f,CYAN,I_GRID,Modifier.weight(1f))
            Ratio("INV LOAD",x.load/12000f,GREEN,I_INV,Modifier.weight(1f)) } }
        Panel("BATTERY BANK",I_BAT,GREEN,Modifier.fillMaxWidth()){
          Text("${x.soc}%  \u00B7  ${x.vBat} V",fontSize=16.sp,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=WHITE)
          Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF17212C))){
            Box(Modifier.fillMaxWidth(maxOf(x.soc/100f,0.01f)).fillMaxHeight().background(Brush.horizontalGradient(listOf(CYAN,GREEN)))) }
          Text(if(Store.d==null) "Sample data" else stateText(x.state),fontSize=11.sp,color=DIM) } } }
    Panel("REAL-TIME POWER",I_HIS,CYAN,Modifier.fillMaxWidth()){
      Chart(cd,150.dp)
      Row(Modifier.fillMaxWidth().padding(start=30.dp,end=32.dp),Arrangement.SpaceBetween){ tl.forEach{ Text(it,fontSize=10.sp,color=DIM) } }
      Legend(cd,false) } }
}
