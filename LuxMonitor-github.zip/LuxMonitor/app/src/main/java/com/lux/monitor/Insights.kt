package com.lux.monitor
import android.content.SharedPreferences
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class Ev(val t:Long,val watts:Double,val minutes:Int,val kwh:Double)
class Sig(val bucket:Int,val n:Int,val kwh:Double,val avgMin:Double)

/** Finds appliance-style load steps (rise of 700 W or more that later drops back) in the last 7 days of 1-minute history. */
fun loadEvents():List<Ev>{
  val pts=History.pts.toList().sortedBy{it.t}
  if(pts.size<300) return emptyList()
  val l=pts.map{ it.load.toDouble() }
  fun med(a:Int,b:Int):Double{ val s=l.subList(a,b).sorted(); return s[s.size/2] }
  val out=ArrayList<Ev>(); var i=6
  while(i<pts.size-8){
    if(pts[i+6].t-pts[i-6].t>14*60000L){ i++; continue }
    val pre=med(i-6,i-1); val d=med(i+1,i+6)-pre
    if(d>=700){
      var j=i+6; var end=-1
      while(j<pts.size-5&&j<i+360){
        if(pts[j].t-pts[j-1].t>5*60000L) break
        if(med(j,j+5)<pre+0.3*d){ end=j; break }
        j++ }
      if(end>0){
        var e=0.0
        for(k in i until end){ val dt=minOf(pts[k+1].t-pts[k].t,300000L)/3600000.0; e+=maxOf(0.0,l[k]-pre)*dt/1000.0 }
        val minutes=((pts[end].t-pts[i].t)/60000).toInt()
        if(minutes>=3) out.add(Ev(pts[i].t,d,minutes,e))
        i=end } else i+=6
    } else i++
  }
  return out
}
fun signatures(ev:List<Ev>):List<Sig> =
  ev.groupBy{ (Math.round(it.watts/300.0)*300).toInt() }.filter{ it.value.size>=2 }
    .map{ (b,l)-> Sig(b,l.size,l.sumOf{it.kwh},l.map{it.minutes}.average()) }.sortedByDescending{it.kwh}
fun guessLoad(w:Int,n:Int,min:Double):String=when{
  w>=5000 -> "EV charger or large heat pump"
  w>=2500&&min>=20 -> "Dryer, oven or water heater"
  w in 1000..2500&&n>=10 -> "A/C or compressor cycling"
  w in 1000..2500 -> "Appliance (iron, kettle, heater)"
  w in 600..1000&&min>=60 -> "Pool pump or dehumidifier"
  else -> "Small appliance" }
/** Always-on load: the 10th percentile of each day's load, averaged. */
fun baselineW():Double?{
  val z=ZoneId.systemDefault()
  val v=History.pts.toList().groupBy{ Instant.ofEpochMilli(it.t).atZone(z).toLocalDate() }.values.filter{it.size>=600}
    .map{ val s=it.map{p->p.load}.sorted(); s[s.size/10].toDouble() }
  return if(v.isEmpty()) null else v.average()
}

@Composable fun ColumnScope.LoadInsightsCard(sp:SharedPreferences){
  val ri=sp.getString("ri","0.25")!!.toDoubleOrNull()?:0.0; val cur=sp.getString("cu","$")!!
  val key=History.pts.size/60
  val sigs=remember(key){ signatures(loadEvents()) }
  val base=remember(key){ baselineW() }
  val peak=History.pts.toList().maxByOrNull{it.load}
  val ld=LocalDate.now()
  val yest=Daily.days[ld.minusDays(1).toString()]?.get(1)
  val prior=(2..8).mapNotNull{ Daily.days[ld.minusDays(it.toLong()).toString()]?.get(1) }
  Section("WHAT USED THE POWER",I_HOME,VIOLET,summary=base?.let{ "always-on "+fm(it)+" W" }?:""){
    if(History.pts.size<300) Text("Needs a day or two of recorded history. Keep the app running in the background.",fontSize=12.sp,color=AMBER)
    if(base!=null){
      val eDay=prior.takeIf{it.isNotEmpty()}?.average()
      Bullet("Always-on load: about ${fm(base)} W, which is ${fm(base*24/1000.0,1)} kWh a day"+(if(eDay!=null&&eDay>1) " (${fm(base*24/1000.0/eDay*100)}% of your use)." else ".")) }
    if(peak!=null) Bullet("Highest load recorded: ${fm(peak.load/1000.0,1)} kW on "+Instant.ofEpochMilli(peak.t).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE HH:mm"))+".")
    if(yest!=null&&prior.size>=3){ val a=prior.average()
      Bullet("Yesterday you used ${fm(yest,1)} kWh, ${if(yest>=a) fm((yest/a-1)*100)+"% above" else fm((1-yest/a)*100)+"% below"} your previous week's average of ${fm(a,1)} kWh.") }
    if(sigs.isNotEmpty()){
      Text("Biggest repeating loads (last 7 days)",fontSize=12.sp,fontWeight=FontWeight.Bold,color=WHITE,modifier=Modifier.padding(top=8.dp))
      sigs.take(4).forEach{ s->
        val nm=sp.getString("sig${s.bucket}","")!!.ifBlank{ guessLoad(s.bucket,s.n,s.avgMin) }
        Column(Modifier.padding(vertical=4.dp)){
          Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){
            Text(nm,fontSize=13.sp,fontWeight=FontWeight.Bold,color=WHITE,modifier=Modifier.weight(1f))
            Text(fm(s.bucket/1000.0,1)+" kW",fontSize=12.sp,fontFamily=FontFamily.Monospace,color=AMBER) }
          Text("${s.n} runs, about ${fm(s.avgMin)} min each, ${fm(s.kwh,1)} kWh ($cur${fm(s.kwh*ri,2)}) in 7 days",fontSize=11.sp,color=DIM) } }
      Text("The names are guesses from power size and run time. Type your own to remember them:",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=6.dp))
      sigs.take(3).forEach{ PrefField(sp,"sig${it.bucket}","Name the "+fm(it.bucket/1000.0,1)+" kW load","") }
    } else if(History.pts.size>=300) Text("No repeating appliance-sized loads found yet.",fontSize=12.sp,color=DIM)
  }
}

@Composable fun TrendRow(label:String,now:String,note:String,ok:Boolean?){
  Column(Modifier.padding(vertical=4.dp)){
    Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){
      Text(label,fontSize=12.sp,color=WHITE,modifier=Modifier.weight(1f))
      Text(now,fontSize=12.sp,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=if(ok==null) DIM else if(ok) GREEN else AMBER) }
    Text(note,fontSize=11.sp,color=DIM) }
}
fun med(l:List<Double>):Double?=if(l.size<3) null else l.sorted()[l.size/2]

@Composable fun ColumnScope.HealthTrendsCard(sp:SharedPreferences){
  val today=LocalDate.now()
  val ds=Daily.days.entries.filter{ it.key<today.toString() }.sortedBy{it.key}
  fun eff(l:List<Map.Entry<String,List<Double>>>):Double?{ val c=l.sumOf{it.value[4]}; val d=l.sumOf{it.value[5]}; return if(c>5) d/c*100 else null }
  val effNow=eff(ds.takeLast(7)); val effBefore=eff(ds.dropLast(7).takeLast(21))
  val fc=Store.fc
  val ratios=fc?.let{ f-> f.dates.indices.filter{ f.dates[it]<today.toString() }.mapNotNull{ i->
    val y=Daily.days[f.dates[i]]?.get(0); if(y!=null&&y>1&&f.rad[i]>1.0) y/f.rad[i] else null } }
  val rNow=ratios?.takeLast(7)?.let{ med(it) }; val rBefore=ratios?.dropLast(7)?.let{ med(it) }
  val sohL=ds.filter{ it.value.size>10&&it.value[10]>0 }
  val sohNow=sohL.lastOrNull()?.value?.get(10)
  val soh30=sohL.firstOrNull{ it.key>=today.minusDays(30).toString() }?.value?.get(10)
  val cycL=ds.filter{ it.value.size>11&&it.value[11]>0 }
  val cycNow=cycL.lastOrNull()?.value?.get(11)
  val cyc30=cycL.firstOrNull{ it.key>=today.minusDays(30).toString() }
  val cycRate=if(cycNow!=null&&cyc30!=null){ val dd=java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(cyc30.key),LocalDate.parse(cycL.last().key)); if(dd>=7) (cycNow-cyc30.value[11])/dd else null } else null
  val ct=cellTrend()
  val sh=panelHealth()
  var score=100; val issues=ArrayList<String>()
  if(effNow!=null&&effBefore!=null&&effNow<effBefore-3){ score-=15; issues.add("battery efficiency") }
  if(rNow!=null&&rBefore!=null&&rNow<rBefore*0.93){ score-=if(rNow<rBefore*0.88) 30 else 20; issues.add("solar yield") }
  if(sohNow!=null&&sohNow<95){ score-=10; issues.add("battery health") }
  if(sohNow!=null&&soh30!=null&&sohNow<soh30-1){ score-=10; issues.add("battery health trend") }
  if(ct!=null&&(ct.first>100||ct.first>ct.second+30)){ score-=15; issues.add("cell spread") }
  if(sh!=null&&sh.any{ it.share<it.normal*0.85 }){ score-=10; issues.add("a solar string") }
  val label=if(score>=85) "Good" else if(score>=65) "Watch" else "Attention"
  Section("HEALTH & EFFICIENCY TRENDS",I_TMP,CYAN,summary="$label $score"){
    Text(if(issues.isEmpty()) "Everything with enough data looks healthy." else "Worth a look: "+issues.joinToString(", ")+".",fontSize=13.sp,fontWeight=FontWeight.Bold,color=if(issues.isEmpty()) GREEN else AMBER,modifier=Modifier.padding(bottom=4.dp))
    if(effNow!=null) TrendRow("Battery round-trip efficiency",fm(effNow)+"%",if(effBefore!=null) "Previous 3 weeks: ${fm(effBefore)}%. Includes inverter losses; typical is about 88 to 94%." else "Needs more weeks of data to compare.",if(effBefore==null) null else effNow>=effBefore-3)
    else TrendRow("Battery round-trip efficiency","needs data","Needs a week of recorded charge and discharge totals.",null)
    if(rNow!=null) TrendRow("Solar yield per unit of sunshine",fm(rNow,1)+" kWh",if(rBefore!=null) "Earlier: ${fm(rBefore,1)} kWh (${if(rNow>=rBefore) "+" else ""}${fm((rNow/rBefore-1)*100)}%). A steady drop over weeks can mean dirty or shaded panels; rain often resets it." else "Needs 3 weeks of daily yield to compare.",if(rBefore==null) null else rNow>=rBefore*0.93)
    else TrendRow("Solar yield per unit of sunshine","needs data","Needs your location in Settings and at least 3 recorded sunny days.",null)
    if(sohNow!=null) TrendRow("Battery state of health",fm(sohNow)+"%",if(soh30!=null) "30 days ago: ${fm(soh30)}%." else "Trend appears after a month of data.",sohNow>=95&&(soh30==null||sohNow>=soh30-1))
    if(cycNow!=null) TrendRow("Battery cycles",fm(cycNow),if(cycRate!=null&&cycRate>0.01) "About ${fm(cycRate,2)} cycles a day. At that rate 6000 cycles (the V5 rating) is roughly ${fm(6000/cycRate/365,0)} years away." else "Cycle rate appears after a week of data.",null)
    if(ct!=null) TrendRow("Battery cell spread",fm(ct.first)+" mV","Before: ${fm(ct.second)} mV. Under about 50 mV is healthy; a steady climb suggests a weak cell or balance problem.",ct.first<=100&&ct.first<=ct.second+30)
    Text("Trends compare the last 7 days with the weeks before. Weather, temperature and missing days can shift them, so look for steady changes, not single bad days.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=6.dp))
  }
}
