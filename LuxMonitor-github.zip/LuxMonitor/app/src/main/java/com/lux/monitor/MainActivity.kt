package com.lux.monitor
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextAlign
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import android.content.SharedPreferences
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*

class Vm:ViewModel()

class MainActivity:ComponentActivity(){
  override fun onCreate(b:Bundle?){super.onCreate(b)
    val sp=getSharedPreferences("c",0)
    History.init(this); Daily.init(this); Monthly.init(this)
    val tm0=sp.getString("theme","0")!!
    Packs.idx=sp.getString("pack","0")!!.toIntOrNull()?:0
    Th.auto=tm0=="auto"; Th.dayIdx=sp.getString("autoDay","2")!!.toIntOrNull()?:2
    Th.idx=if(Th.auto) (if(isNight(sp)) 1 else Th.dayIdx) else (tm0.toIntOrNull()?:0)
    if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),1)
    setContent{MaterialTheme(colorScheme=darkColorScheme()){Surface(Modifier.fillMaxSize(),color=BG){Screen(viewModel(),sp)}}}}
}

val BG:Color get()=Th.cur.bg; val CARD:Color get()=Th.cur.card; val LINE:Color get()=Th.cur.line; val LINE2:Color get()=Th.cur.line2
val DIM:Color get()=Th.cur.dim; val WHITE:Color get()=Th.cur.text
val TILE:Color get()=Th.cur.tile; val TRACK:Color get()=Th.cur.track; val DEEP:Color get()=Th.cur.deep; val CHIP:Color get()=Th.cur.chip
val AMBER:Color get()=Th.cur.solar; val CYAN:Color get()=Th.cur.grid; val BLUE:Color get()=Th.cur.gridIn; val GREEN:Color get()=Th.cur.battery
val VIOLET:Color get()=Th.cur.home; val PINK:Color get()=Th.cur.soc; val RED=Color(0xFFEF5350)
fun kw(w:Int)=if(w>=1000) "%.2f kW".format(w/1000.0) else "$w W"
fun ip(d:String)=PathParser().parsePathString(d).toPath()
val I_SOL:Path get()=Packs.cur.sol
val I_GRID:Path get()=Packs.cur.grid
val I_HOME:Path get()=Packs.cur.home
val I_BAT:Path get()=Packs.cur.bat
val I_INV:Path get()=Packs.cur.inv
val I_RUN:Path get()=Packs.cur.run
val I_LIVE:Path get()=Packs.cur.live
val I_HIS:Path get()=Packs.cur.his
val I_SET:Path get()=Packs.cur.set
val I_EXTRA:Path get()=Packs.cur.extra
val I_TMP:Path get()=Packs.cur.tmp

fun DrawScope.icon(p:Path,col:Color,c:Offset,s:Float,glow:Boolean=true,keep:Boolean=false,pack:IconPack=Packs.cur){
  val mode=pack.mode
  if(mode==2){
    drawRoundRect(col,Offset(c.x-s*0.66f,c.y-s*0.66f),Size(s*1.32f,s*1.32f),CornerRadius(s*0.32f))
    val g=s*0.62f
    withTransform({translate(c.x-g/2,c.y-g/2);scale(g/24f,g/24f,Offset.Zero)}){
      if(pack.fills.contains(p)) drawPath(p,Color.White)
      drawPath(p,Color.White,style=Stroke(2.2f,cap=StrokeCap.Round,join=StrokeJoin.Round)) }
  } else {
    val cc=if(mode==1&&!keep) (if(col==DIM) DIM else WHITE) else col
    withTransform({translate(c.x-s/2,c.y-s/2);scale(s/24f,s/24f,Offset.Zero)}){
      if(mode==0&&glow) drawPath(p,cc.copy(alpha=.3f),style=Stroke(4.5f,cap=StrokeCap.Round,join=StrokeJoin.Round))
      drawPath(p,cc,style=if(mode==1) Stroke(1.5f,cap=StrokeCap.Butt,join=StrokeJoin.Miter) else Stroke(1.9f,cap=StrokeCap.Round,join=StrokeJoin.Round)) } }
}
fun DrawScope.label(tm:TextMeasurer,s:String,x:Float,y:Float,px:Float,col:Color,mono:Boolean=false,bold:Boolean=false,center:Boolean=false){
  val m=tm.measure(s,TextStyle(color=col,fontSize=px.toSp(),fontFamily=if(mono) FontFamily.Monospace else FontFamily.Default,fontWeight=if(bold) FontWeight.Bold else FontWeight.Normal))
  drawText(m,topLeft=Offset(if(center) x-m.size.width/2f else x,y-m.size.height/2f))
}
@Composable fun Ico(p:Path,c:Color,s:Int=16,glow:Boolean=true,keep:Boolean=false){ Canvas(Modifier.size(s.dp)){ icon(p,c,Offset(size.width/2,size.height/2),size.width*(if(Packs.cur.mode==2) 0.75f else 1f),glow,keep) } }

@Composable fun Hero(x:Lux,rt:String){
  val t by rememberInfiniteTransition(label="f").animateFloat(0f,1f,infiniteRepeatable(tween(900,easing=LinearEasing)),label="p")
  val tm=rememberTextMeasurer()
  Canvas(Modifier.fillMaxWidth().aspectRatio(358f/290f)){
    val k=size.width/358f
    fun P(a:Float,b:Float)=Offset(a*k,b*k)
    fun flow(a:Offset,b:Offset,on:Boolean,col:Color)=drawLine(if(on) col else LINE2,a,b,3f*k,
      pathEffect=if(on) PathEffect.dashPathEffect(floatArrayOf(4*k,6*k),(1f-t)*10*k) else null)
    fun pill(px:Float,py:Float,w:Float,h:Float,col:Color,fill:Color,ic:Path,lab:String,v:String,sub:String,tx:Float,vs:Float){
      drawRoundRect(fill,P(px,py),Size(w*k,h*k),CornerRadius(14*k))
      drawRoundRect(col.copy(alpha=.6f),P(px,py),Size(w*k,h*k),CornerRadius(14*k),style=Stroke(k))
      icon(ic,col,P(px+20,py+h/2),22*k)
      label(tm,lab,tx*k,(py+13)*k,9*k,col); label(tm,v,tx*k,(py+31)*k,vs*k,WHITE,mono=true,bold=true); label(tm,sub,tx*k,(py+51)*k,8.5f*k,DIM,mono=true) }
    val c=P(179f,150f)
    flow(P(179f,68f),P(179f,90f),x.pv>20,AMBER)
    if(x.gridOut>20) flow(P(119f,150f),P(100f,150f),true,CYAN) else flow(P(100f,150f),P(119f,150f),x.gridIn>20,BLUE)
    flow(P(239f,150f),P(258f,150f),x.load>20,VIOLET)
    drawCircle(TRACK,60*k,c,style=Stroke(10*k))
    drawArc(Brush.linearGradient(if(x.soc>20) listOf(CYAN,GREEN) else listOf(AMBER,RED),P(119f,90f),P(239f,210f)),-90f,360f*x.soc/100f,false,
      c-Offset(60*k,60*k),Size(120*k,120*k),style=Stroke(10*k,cap=StrokeCap.Round))
    drawCircle(DEEP,46*k,c); drawCircle(LINE,46*k,c,style=Stroke(k))
    icon(I_BAT,GREEN,P(179f,116f),16*k)
    label(tm,"${x.soc}%",179*k,141*k,28*k,WHITE,mono=true,bold=true,center=true)
    val st=if(x.charge>20) "CHARGING "+kw(x.charge) else if(x.discharge>20) "DISCHARGING "+kw(x.discharge) else "IDLE \u00B7 0 W"
    label(tm,st,179*k,167*k,9*k,GREEN,center=true)
    val gs="${x.vGrid.toInt()}V ${"%.1f".format(x.fGrid)}Hz"
    pill(84f,2f,190f,66f,AMBER,AMBER.copy(alpha=.12f),I_SOL,"SOLAR  (S1 \u00B7 S2 \u00B7 S3)",kw(x.pv),"${x.pv1} \u00B7 ${x.pv2} \u00B7 ${x.pv3} W",126f,18f)
    if(x.gridOut>20||x.gridIn<=20) pill(2f,118f,98f,64f,CYAN,CYAN.copy(alpha=.12f),I_GRID,"EXPORT",kw(x.gridOut),gs,34f,14f)
    else pill(2f,118f,98f,64f,BLUE,BLUE.copy(alpha=.12f),I_GRID,"IMPORT",kw(x.gridIn),gs,34f,14f)
    pill(258f,118f,98f,64f,VIOLET,VIOLET.copy(alpha=.12f),I_HOME,"HOME",kw(x.load),if(x.vEps>0) "${x.vEps.toInt()} V" else "\u2013 V",290f,14f)
    drawRoundRect(DEEP,P(59f,232f),Size(240*k,46*k),CornerRadius(23*k))
    drawRoundRect(LINE,P(59f,232f),Size(240*k,46*k),CornerRadius(23*k),style=Stroke(k))
    icon(I_RUN,GREEN,P(88f,255f),22*k)
    label(tm,"RUNTIME AT LOAD \u00B7 NO PV",196*k,243*k,9*k,DIM,center=true)
    label(tm,rt,196*k,262*k,15*k,GREEN,mono=true,bold=true,center=true)
  }
}

@Composable fun Section(title:String,ic:Path,col:Color,expanded:Boolean=false,summary:String="",content:@Composable ColumnScope.()->Unit){
  var o by remember{mutableStateOf(expanded)}
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
    Column(Modifier.padding(12.dp)){
      Row(Modifier.fillMaxWidth().clickable{o=!o},Arrangement.SpaceBetween,Alignment.CenterVertically){
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){ Ico(ic,col,18); Text(title,fontSize=12.sp,letterSpacing=1.5.sp,fontWeight=FontWeight.Bold,color=WHITE) }
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
          if(!o&&summary.isNotEmpty()) Text(summary,fontSize=11.sp,fontFamily=FontFamily.Monospace,color=WHITE)
          Text(if(o) "\u25BE" else "\u25B8",color=DIM) } }
      if(o){ Spacer(Modifier.height(10.dp)); content() } } }
}
@Composable fun Kpi(label:String,v:Double,col:Color,ic:Path,mod:Modifier,unit:String="kWh",dec:Int=1){
  Card(mod,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=TILE)){
    Column{ Column(Modifier.padding(8.dp,10.dp)){
      Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween,Alignment.CenterVertically){ Text(label,fontSize=9.sp,color=DIM); Ico(ic,col,14) }
      Text("%.${dec}f".format(v),fontSize=18.sp,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=WHITE,modifier=Modifier.padding(top=6.dp)); Text(unit,fontSize=10.sp,color=DIM) }
      Box(Modifier.fillMaxWidth().height(3.dp).background(col)) } }
}
@Composable fun Ratio(label:String,f:Float,col:Color,ic:Path,mod:Modifier){
  val fr=f.coerceIn(0f,1f)
  Card(mod,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=TILE)){
    Column(Modifier.padding(12.dp,10.dp)){
      Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween,Alignment.CenterVertically){ Text(label,fontSize=9.sp,color=DIM); Ico(ic,col,14) }
      Text("${(fr*100).toInt()}%",fontSize=22.sp,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=col)
      Box(Modifier.padding(top=6.dp).fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(TRACK)){
        Box(Modifier.fillMaxWidth(maxOf(fr,0.01f)).fillMaxHeight().background(col)) } } }
}

val CSER:List<Pair<String,Color>> get()=listOf("Solar" to AMBER,"Battery" to GREEN,"Grid" to CYAN,"Load" to VIOLET,"SOC" to PINK)
val DS:List<List<Float>> = run{
  val sol=ArrayList<Float>();val bat=ArrayList<Float>();val grd=ArrayList<Float>();val con=ArrayList<Float>();val soc=ArrayList<Float>()
  var s=30f
  for(i in 0 until 96){
    val so=if(i in 24..72) 7000f*kotlin.math.sin(Math.PI.toFloat()*(i-24)/48f) else 0f
    val c=800f+300f*kotlin.math.sin(i/6f); val b=if(so>c) minOf(2800f,so-c) else 0f
    sol.add(so);con.add(c);bat.add(b);grd.add(so-c-b); s=minOf(100f,s+b/3000f); soc.add(s) }
  listOf(sol,bat,grd,con,soc)
}

@Composable fun Chart(d:List<List<Float>>,ht:Dp=210.dp){
  val tm=rememberTextMeasurer()
  Canvas(Modifier.fillMaxWidth().height(ht)){
    val h=size.height; val w=size.width; val pl=30.dp.toPx(); val pr=32.dp.toPx(); val pw=w-pl-pr
    val mx=d.take(4).maxOf{it.maxOrNull()?:0f}; val mn=d.take(4).minOf{it.minOrNull()?:0f}
    val step=if(mx>12000f) 4000f else 2000f
    val hi=maxOf(step,kotlin.math.ceil(mx/step)*step); val lo=if(mn<0f) kotlin.math.floor(mn/step)*step else 0f
    fun yP(v:Float)=h-(v-lo)/(hi-lo)*h
    fun lab(s:String,x:Float,y:Float,col:Color,right:Boolean){
      val t=tm.measure(s,TextStyle(color=col,fontSize=9.sp,fontFamily=FontFamily.Monospace))
      drawText(t,topLeft=Offset(if(right) x else x-t.size.width,(y-t.size.height/2f).coerceIn(0f,h-t.size.height))) }
    var v=lo
    while(v<=hi+1f){ val y=yP(v)
      drawLine(if(v==0f) LINE2 else LINE,Offset(pl,y),Offset(pl+pw,y),1.dp.toPx(),pathEffect=if(v==0f) null else PathEffect.dashPathEffect(floatArrayOf(6f,8f)))
      lab("%.0f".format(v/1000f),pl-4.dp.toPx(),y,DIM,false); v+=step }
    for(s in intArrayOf(0,50,100)) lab("$s%",pl+pw+4.dp.toPx(),h-s/100f*h,PINK,true)
    val zy=yP(0f)
    d.forEachIndexed{k,vs-> if(vs.size>1){
      val path=Path()
      vs.forEachIndexed{i,y->
        val py=if(k==4) h-y/100f*h else yP(y); val px=pl+pw*i/(vs.size-1)
        if(i==0) path.moveTo(px,py) else path.lineTo(px,py) }
      if(k==0){ val f=Path(); f.addPath(path); f.lineTo(pl+pw,zy); f.lineTo(pl,zy); f.close(); drawPath(f,AMBER.copy(alpha=.2f)) }
      drawPath(path,CSER[k].second,style=if(k==4) Stroke(1.5.dp.toPx(),pathEffect=PathEffect.dashPathEffect(floatArrayOf(14f,10f))) else Stroke(2.dp.toPx(),cap=StrokeCap.Round,join=StrokeJoin.Round)) } }
  }
}

@Composable fun Legend(d:List<List<Float>>,note:Boolean=true){
  Row(Modifier.fillMaxWidth().padding(top=10.dp),Arrangement.SpaceBetween){
    CSER.forEachIndexed{k,e->
      val v=d[k].lastOrNull()
      Column(horizontalAlignment=Alignment.CenterHorizontally){
        Text("\u25CF "+e.first,fontSize=11.sp,color=e.second)
        Text(if(v==null) "\u2013" else if(k==4) "${v.toInt()}%" else "%.2f kW".format(v/1000f),fontSize=11.sp,fontFamily=FontFamily.Monospace,color=WHITE) } } }
  if(note) Text("Left axis: kW (solar, battery, grid, load). Right axis: battery %. Battery + = charging, \u2212 = discharging. Grid + = export, \u2212 = import.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
}

fun timeLabels(range:Int):List<String>{
  val n=System.currentTimeMillis()
  val (ms,fmt)=when(range){0->3600000L to "HH:mm";1->86400000L to "EEE HH:mm";else->7*86400000L to "EEE d"}
  val f=java.text.SimpleDateFormat(fmt,java.util.Locale.getDefault())
  return listOf(f.format(java.util.Date(n-ms)),f.format(java.util.Date(n-ms/2)),"now")
}

fun stateText(s:Int)=when(s){0,17->"Standby";1->"Fault";2->"Updating";4->"PV powering load, exporting surplus"
  8->"PV powering load & charging battery";12->"PV powering load, charging battery & exporting";16->"Battery discharging to load, exporting surplus"
  20->"PV & battery powering load, exporting surplus";32->"Grid charging battery";40->"Grid & PV charging battery";64->"Off-grid: battery powering load"
  96->"Off-grid: AC-coupled PV charging battery";136->"Off-grid: PV powering load & charging battery";192->"Off-grid: PV & battery powering load";else->"State $s"}
fun chartData(range:Int):List<List<Float>>{
  val src:List<Pt> = if(range==0) Store.series.map{Pt(0,it.pv,it.charge-it.discharge,it.gridOut-it.gridIn,it.load,it.soc)}
    else { val cut=System.currentTimeMillis()-(if(range==1) 86400000L else 7*86400000L); History.pts.filter{it.t>=cut} }
  val st=maxOf(1,src.size/240); val s=src.filterIndexed{i,_->i%st==0}
  return listOf(s.map{it.pv.toFloat()},s.map{it.bat.toFloat()},s.map{it.grid.toFloat()},s.map{it.load.toFloat()},s.map{it.soc.toFloat()})
}
fun hm(h:Double)=if(h>99) "99h+" else "${h.toInt()}h ${((h-h.toInt())*60).toInt()}m"
val DEMO=listOf(
  "Sunny" to Lux(100,53.6,7377,0,0,0,6465,766,pv1=2900,pv2=2500,pv3=1977,vEps=230.0),
  "Evening" to Lux(48,51.9,300,0,1900,0,0,2200,pv1=100,pv2=100,pv3=100,vEps=230.0),
  "Night" to Lux(18,50.6,0,0,0,900,0,900,vEps=230.0),
  "Charging" to Lux(35,51.4,0,3000,0,3900,0,900,vEps=230.0))
fun demoRt(x:Lux)=if(x.charge>x.discharge+50) "Full in "+hm(15360.0*(100-x.soc)/100/x.charge)
  else hm(15360.0*maxOf(0,x.soc-10)/100*0.94/maxOf(50,x.load))

@Composable fun NavItem(label:String,ic:Path,act:Boolean,mod:Modifier,onClick:()->Unit){
  val c=if(act) CYAN else DIM
  Column(mod.clickable(onClick=onClick).padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(4.dp)){
    Ico(ic,c,22,act,act); Text(label,fontSize=11.sp,color=c,fontWeight=if(act) FontWeight.Bold else FontWeight.Normal) }
}

@Composable fun Screen(vm:Vm,sp:SharedPreferences){
  var host by remember{mutableStateOf(sp.getString("h","")!!)}
  var dl by remember{mutableStateOf(sp.getString("d","")!!)}
  var sn by remember{mutableStateOf(sp.getString("s","")!!)}
  var cap by remember{mutableStateOf(sp.getString("c","15.36")!!)}
  var res by remember{mutableStateOf(sp.getString("r","10")!!)}
  var alr by remember{mutableStateOf(sp.getString("a","20")!!)}
  var pint by remember{mutableStateOf(sp.getString("pi","10")!!)}
  var xa by remember{mutableStateOf(sp.getString("xa","0")=="1")}
  var rimp by remember{mutableStateOf(sp.getString("ri","0.25")!!)}
  var rexp by remember{mutableStateOf(sp.getString("re","0.10")!!)}
  var cur by remember{mutableStateOf(sp.getString("cu","$")!!)}
  var range by remember{mutableStateOf(0)}
  var latS by remember{mutableStateOf(sp.getString("lat","")!!)}
  var lonS by remember{mutableStateOf(sp.getString("lon","")!!)}
  var kwpS by remember{mutableStateOf(sp.getString("kwp","10")!!)}
  var fcKey by remember{mutableStateOf(0)}
  var wall by remember{mutableStateOf(false)}

  var dFrom by remember{mutableStateOf(LocalDate.now().withDayOfMonth(1).toString())}
  var dTo by remember{mutableStateOf(LocalDate.now().toString())}
  var tab by remember{mutableStateOf(0)}
  var sel by remember{mutableStateOf(0)}
  val ctx=LocalContext.current
  val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri->
    if(uri!=null) android.widget.Toast.makeText(ctx,Monthly.importCsv(ctx,uri),android.widget.Toast.LENGTH_LONG).show() }
  LaunchedEffect(fcKey){
    val la=sp.getString("lat","")!!.trim(); val lo=sp.getString("lon","")!!.trim()
    val got=if(la.isEmpty()||lo.isEmpty()) null else withContext(Dispatchers.IO){ runCatching{fetchForecast(la,lo)}.getOrNull() }
    if(got!=null||la.isEmpty()) Store.fc=got }
  LaunchedEffect(Unit){ startMonitor(ctx) }
  LaunchedEffect(Th.auto){ while(Th.auto){ Th.idx=if(isNight(sp)) 1 else Th.dayIdx; delay(60000) } }
  val live=Store.d
  Box(Modifier.fillMaxSize()){
  Column(Modifier.fillMaxSize().statusBarsPadding()){
    val brand=sp.getString("brand","LuxPower")!!.ifBlank{"LuxPower"}; val model=sp.getString("model","LXP-LB-EU 12K")!!
    val srcLabel=when(Store.via){ "local"->"LOCAL"; "cloud"->"CLOUD"; else->"DEMO" }
    val srcCol=when(Store.via){ "local"->GREEN; "cloud"->AMBER; else->DIM }
    Row(Modifier.fillMaxWidth().padding(16.dp,12.dp),Arrangement.SpaceBetween,Alignment.CenterVertically){
      Column{
        Text("LUX MONITOR",fontSize=10.sp,letterSpacing=3.sp,fontWeight=FontWeight.Bold,color=CYAN)
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
          Text(brand.uppercase(),fontSize=20.sp,letterSpacing=2.sp,fontWeight=FontWeight.Bold,color=WHITE)
          if(model.isNotBlank()) Box(Modifier.clip(RoundedCornerShape(8.dp)).background(CHIP).padding(8.dp,3.dp)){
            Text(model,fontSize=11.sp,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=CYAN) } } }
      Row(Modifier.clip(RoundedCornerShape(14.dp)).background(CARD).padding(10.dp,6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)){
        Ico(I_LIVE,srcCol,16); Text(srcLabel,fontSize=11.sp,letterSpacing=1.sp,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=srcCol) } }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=16.dp),Arrangement.spacedBy(14.dp)){
      if(tab==0){
        val x=live?:DEMO[sel].second
        val land=LocalConfiguration.current.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE
        if(live==null){
          Text("Demo mode \u2013 add your inverter details in Settings to go live.",fontSize=13.sp,color=AMBER)
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(6.dp)){ DEMO.forEachIndexed{i,d->
            Button({sel=i},Modifier.weight(1f),contentPadding=PaddingValues(2.dp),
              colors=ButtonDefaults.buttonColors(containerColor=if(i==sel) AMBER else CARD,contentColor=if(i==sel) Color.Black else WHITE)){Text(d.first,fontSize=12.sp)} } }
        }
        val rtx=if(live==null) demoRt(x) else Store.runtime
        if(land) LandscapeBoard(x,rtx) else Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=CARD)){ Hero(x,rtx) }
        if(live!=null) Text(stateText(x.state),fontSize=12.sp,color=DIM)
        if(Store.err.isNotEmpty()) Text(Store.err,fontSize=12.sp,color=AMBER)
        val ri=rimp.toDoubleOrNull()?:0.0; val re=rexp.toDoubleOrNull()?:0.0
        if(!land){
        Section("DAILY ENERGY",I_SOL,AMBER,expanded=true){
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){ Kpi("YIELD",x.yld,AMBER,I_SOL,Modifier.weight(1f)); Kpi("USED",x.cons,VIOLET,I_HOME,Modifier.weight(1f))
            Kpi("IMPORT",x.impDay,BLUE,I_GRID,Modifier.weight(1f)); Kpi("EXPORT",x.expDay,CYAN,I_GRID,Modifier.weight(1f)) }
          Spacer(Modifier.height(8.dp))
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Ratio("SELF-USE",if(x.yld>0) ((x.yld-x.expDay)/x.yld).toFloat() else 0f,VIOLET,I_HOME,Modifier.weight(1f))
            Ratio("AUTARKY",if(x.cons>0) (1-x.impDay/x.cons).toFloat() else 0f,CYAN,I_GRID,Modifier.weight(1f))
            Ratio("INV LOAD",x.load/12000f,GREEN,I_INV,Modifier.weight(1f)) }
          Text("Runtime = usable battery energy \u00F7 5-min average load, no PV.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
        }
        Section("REAL-TIME POWER",I_HIS,CYAN,expanded=true){
          if(live!=null) Row(Modifier.fillMaxWidth().padding(bottom=8.dp),Arrangement.spacedBy(6.dp)){ listOf("1 h","24 h","7 d").forEachIndexed{i,t->
            Button({range=i},Modifier.weight(1f),contentPadding=PaddingValues(2.dp),
              colors=ButtonDefaults.buttonColors(containerColor=if(i==range) CYAN else TILE,contentColor=if(i==range) Color.Black else WHITE)){Text(t,fontSize=12.sp)} } }
          val cd=if(live==null) DS else chartData(range)
          Chart(cd)
          val tl=if(live==null) listOf("00:00","12:00","24:00") else timeLabels(range)
          Row(Modifier.fillMaxWidth().padding(start=30.dp,end=32.dp,top=4.dp),Arrangement.SpaceBetween){ tl.forEach{Text(it,fontSize=10.sp,color=DIM)} }
          Legend(cd)
        }
        Section("BATTERY BANK",I_BAT,GREEN,expanded=true){
          Text("$cap kWh \u00B7 reserve $res% \u00B7 ${x.vBat} V",fontSize=12.sp,fontFamily=FontFamily.Monospace,color=DIM)
          Box(Modifier.padding(top=10.dp).fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(TRACK)){
            Box(Modifier.fillMaxWidth(maxOf(x.soc/100f,0.01f)).fillMaxHeight().background(Brush.horizontalGradient(listOf(CYAN,GREEN)))) }
          Text("Charge ${"%.1f".format(x.chgDay)} kWh \u00B7 discharge ${"%.1f".format(x.dischgDay)} kWh today",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
        }
        }
        val coords=sp.getString("lat","")!!.isNotBlank()&&sp.getString("lon","")!!.isNotBlank()
        val fsrc=Store.fc?:(if(!coords) sampleFc() else null)
        val fres=fsrc?.let{ forecast(it,kwpS.toDoubleOrNull()?:10.0) }
        val fsum=fres?.rows?.firstOrNull()?.let{ "Today "+"%.0f".format(it.prod)+" kWh \u00B7 net "+"%+.0f".format(it.net) }?:""
        Section("FORECAST",I_SOL,AMBER,summary=fsum){
          if(fres==null) Text("Loading forecast\u2026 (needs internet). Check latitude and longitude in Settings.",fontSize=12.sp,color=DIM)
          else{
            if(!coords) Text("Sample forecast \u2013 add your latitude and longitude in Settings.",fontSize=12.sp,color=AMBER,modifier=Modifier.padding(bottom=8.dp))
            val f=fres
            if(f.rows.size>=2){
              val nv={n:Double->(if(n<0) "-" else "")+cur+"%.0f".format(Math.abs(if(n>=0) n*re else n*ri))}
              Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
                Kpi("TODAY NET",f.rows[0].net,if(f.rows[0].net>=0) CYAN else RED,I_GRID,Modifier.weight(1f),"kWh",1)
                Kpi("TOMORROW NET",f.rows[1].net,if(f.rows[1].net>=0) CYAN else RED,I_GRID,Modifier.weight(1f),"kWh",1)
                Kpi("7-DAY NET",f.rows.sumOf{it.net},if(f.rows.sumOf{it.net}>=0) CYAN else RED,I_GRID,Modifier.weight(1f),"kWh",0) }
              Spacer(Modifier.height(10.dp))
              val mp=maxOf(1.0,f.rows.maxOf{it.prod})
              Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Text("Day",fontSize=10.sp,color=DIM,modifier=Modifier.width(52.dp)); Text("Production (kWh)",fontSize=10.sp,color=DIM,modifier=Modifier.weight(1f))
                Text("Net kWh",fontSize=10.sp,color=DIM,textAlign=TextAlign.End,modifier=Modifier.width(54.dp)); Text("Value",fontSize=10.sp,color=DIM,textAlign=TextAlign.End,modifier=Modifier.width(54.dp)) }
              f.rows.forEach{ r->
                Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
                  Text(LocalDate.parse(r.date).format(java.time.format.DateTimeFormatter.ofPattern("EEE d")),fontSize=11.sp,color=WHITE,modifier=Modifier.width(52.dp))
                  Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(TRACK)){ Box(Modifier.fillMaxWidth((r.prod/mp).toFloat().coerceIn(0.02f,1f)).fillMaxHeight().background(AMBER)) }
                  Text("%.0f".format(r.prod),fontSize=11.sp,fontFamily=FontFamily.Monospace,color=AMBER,textAlign=TextAlign.End,modifier=Modifier.width(34.dp))
                  Text("%+.0f".format(r.net),fontSize=11.sp,fontFamily=FontFamily.Monospace,color=if(r.net>=0) CYAN else RED,textAlign=TextAlign.End,modifier=Modifier.width(54.dp))
                  Text(nv(r.net),fontSize=11.sp,fontFamily=FontFamily.Monospace,color=WHITE,textAlign=TextAlign.End,modifier=Modifier.width(54.dp)) } }
              if(live!=null) Text("Today so far: ${"%.1f".format(live.yld)} kWh of ${"%.0f".format(f.rows[0].prod)} forecast.",fontSize=12.sp,color=WHITE,modifier=Modifier.padding(top=8.dp))
              Text("Production = ${"%.1f".format(f.k)} kWh per kWh/m\u00B2 of sun (${f.note}${if(f.n>0) ", fit \u00B1"+(f.err*100).toInt()+"%" else ""}). Net export = production \u2212 typical use (${"%.0f".format(f.cons)} kWh/day) \u2212 battery charging (${"%.1f".format(f.bat)} kWh/day). The model re-learns as more days are recorded.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=6.dp))
            }
          }
        }
        Section("BATTERY HEALTH",I_BAT,GREEN){
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Kpi("BAT TEMP",x.tBat,AMBER,I_TMP,Modifier.weight(1f),"\u00B0C",0); Kpi("INV TEMP",x.tInv,AMBER,I_TMP,Modifier.weight(1f),"\u00B0C",0)
            Kpi("SOH",x.soh.toDouble(),GREEN,I_BAT,Modifier.weight(1f),"%",0); Kpi("CYCLES",x.cycles.toDouble(),GREEN,I_BAT,Modifier.weight(1f),"cycles",0) }
          Spacer(Modifier.height(8.dp))
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Kpi("CELL MAX",x.cellMaxV,CYAN,I_BAT,Modifier.weight(1f),"V",3); Kpi("CELL MIN",x.cellMinV,CYAN,I_BAT,Modifier.weight(1f),"V",3)
            Kpi("DELTA",(x.cellMaxV-x.cellMinV)*1000,AMBER,I_BAT,Modifier.weight(1f),"mV",0) }
          Text("Cell temperature ${"%.1f".format(x.cellTMin)} to ${"%.1f".format(x.cellTMax)} \u00B0C",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
        }
        Section("BILL COMPARE",I_GRID,BLUE){
          Row(Modifier.fillMaxWidth().padding(bottom=8.dp),Arrangement.spacedBy(6.dp)){
            listOf("This month","Last month","Last 7 d","Last 30 d").forEachIndexed{i,t->
              OutlinedButton({ val n=LocalDate.now()
                when(i){ 0->{dFrom=n.withDayOfMonth(1).toString();dTo=n.toString()}
                  1->{val lm=n.minusMonths(1);dFrom=lm.withDayOfMonth(1).toString();dTo=lm.withDayOfMonth(lm.lengthOfMonth()).toString()}
                  2->{dFrom=n.minusDays(6).toString();dTo=n.toString()} else->{dFrom=n.minusDays(29).toString();dTo=n.toString()} } },
                Modifier.weight(1f),contentPadding=PaddingValues(2.dp)){Text(t,fontSize=11.sp)} } }
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            OutlinedTextField(dFrom,{dFrom=it},label={Text("From (yyyy-mm-dd)")},singleLine=true,modifier=Modifier.weight(1f))
            OutlinedTextField(dTo,{dTo=it},label={Text("To")},singleLine=true,modifier=Modifier.weight(1f)) }
          val f=runCatching{LocalDate.parse(dFrom)}.getOrNull(); val t=runCatching{LocalDate.parse(dTo)}.getOrNull()
          if(f!=null&&t!=null&&!t.isBefore(f)){
            val r=period(f,t,ri,re); val s=r.s; val n=ChronoUnit.DAYS.between(f,t)+1
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
              Kpi("IMPORT",s[2],BLUE,I_GRID,Modifier.weight(1f),"kWh",1); Kpi("EXPORT",s[3],CYAN,I_GRID,Modifier.weight(1f),"kWh",1); Kpi("NET IMPORT",s[2]-s[3],AMBER,I_GRID,Modifier.weight(1f),"kWh",1) }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
              Kpi("GENERATION",s[0],AMBER,I_SOL,Modifier.weight(1f),"kWh",1); Kpi("CONSUMPTION",s[1],VIOLET,I_HOME,Modifier.weight(1f),"kWh",1); Kpi("NET COST",s[6]-s[7],GREEN,I_SOL,Modifier.weight(1f),cur,2) }
            Text("Days counted: ${r.exact} exact"+(if(r.est>0) ", ${r.est} estimated from monthly totals" else "")+(if(r.miss>0) ", ${r.miss} with no data" else "")+". Cost uses your imported bill data where available.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
          } else Text("Enter dates as yyyy-mm-dd, with the end on or after the start.",fontSize=11.sp,color=RED,modifier=Modifier.padding(top=8.dp))
        }
        Section("SAVINGS TODAY",I_SOL,GREEN){
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Kpi("SAVED",x.cons*ri-(x.impDay*ri-x.expDay*re),GREEN,I_SOL,Modifier.weight(1f),cur,2)
            Kpi("GRID COST",x.impDay*ri,BLUE,I_GRID,Modifier.weight(1f),cur,2)
            Kpi("EXPORT CREDIT",x.expDay*re,CYAN,I_GRID,Modifier.weight(1f),cur,2) }
          Text("Saved = what your consumption would cost at the import rate, minus grid cost, plus export credit. Set rates in Settings.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
        }
        Section("ENERGY OVERVIEW (LIFETIME)",I_HIS,AMBER){
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Kpi("GENERATION",x.totGen,AMBER,I_SOL,Modifier.weight(1f),"kWh",0); Kpi("EXPORT",x.totExp,CYAN,I_GRID,Modifier.weight(1f),"kWh",0); Kpi("IMPORT",x.totImp,BLUE,I_GRID,Modifier.weight(1f),"kWh",0) }
          Spacer(Modifier.height(8.dp))
          Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
            Kpi("BAT CHARGE",x.totChg,GREEN,I_BAT,Modifier.weight(1f),"kWh",0); Kpi("BAT DISCHARGE",x.totDis,GREEN,I_BAT,Modifier.weight(1f),"kWh",0) }
        }
        Spacer(Modifier.height(4.dp))
      } else if(tab==1){
        ExtrasTab(sp){wall=true}
      } else {
        AppearanceCard(sp)
        IconPackCard(sp)
        PrefField(sp,"brand","Brand shown on the main screen","LuxPower")
        PrefField(sp,"model","Model shown on the main screen","LXP-LB-EU 12K")
        OutlinedTextField(host,{host=it},label={Text("Dongle IP")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(dl,{dl=it},label={Text("Dongle serial (10 chars)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(sn,{sn=it},label={Text("Inverter serial (10 chars)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(cap,{cap=it},label={Text("Battery kWh (3 \u00D7 5.12)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(res,{res=it},label={Text("Reserve SOC %")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(alr,{alr=it},label={Text("Low-battery alert % (during outage)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(rimp,{rimp=it},label={Text("Import rate per kWh")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(rexp,{rexp=it},label={Text("Export rate per kWh")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(cur,{cur=it},label={Text("Currency symbol")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedButton({android.widget.Toast.makeText(ctx,History.export(ctx),android.widget.Toast.LENGTH_LONG).show()},Modifier.fillMaxWidth()){Text("Export history to CSV")}
        PrefSwitch(sp,"wl","Keep Wi-Fi awake for a more stable connection (uses a little more battery)")
        OutlinedTextField(pint,{pint=it},label={Text("Polling interval in seconds (10 to 60)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween,Alignment.CenterVertically){
          Text("Extra alerts (faults, battery temp, cells, connection). Off = outage alerts only.",color=WHITE,fontSize=13.sp,modifier=Modifier.weight(1f).padding(end=8.dp)); Switch(xa,{xa=it}) }
        OutlinedTextField(latS,{latS=it},label={Text("Latitude (for solar forecast)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(lonS,{lonS=it},label={Text("Longitude")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(kwpS,{kwpS=it},label={Text("Solar array size in kW (fallback)")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
          Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("Import history (Home Assistant CSV)",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=WHITE)
            Text(if(Monthly.rows.isEmpty()) "Nothing imported yet. Imported data feeds the forecast and Bill Compare." else "${Monthly.rows.size} months imported (${Monthly.rows.keys.minOrNull()} to ${Monthly.rows.keys.maxOrNull()}).",fontSize=11.sp,color=DIM)
            OutlinedButton({pick.launch(arrayOf("*/*"))},Modifier.fillMaxWidth()){Text("Choose CSV file")} } }
        LuxCloudCard(sp)
        OutlinedButton({alert(ctx,2,"Grid outage","Battery 82% \u00B7 about 14h 02m left at 0.77 kW load (test)")},Modifier.fillMaxWidth()){Text("Send test outage alert")}
        OutlinedButton({ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))},Modifier.fillMaxWidth()){Text("Allow background running")}
        Button({sp.edit().putString("h",host).putString("d",dl).putString("s",sn).putString("c",cap).putString("r",res).putString("a",alr).putString("pi",pint).putString("xa",if(xa) "1" else "0").putString("ri",rimp).putString("re",rexp).putString("cu",cur).putString("lat",latS.trim()).putString("lon",lonS.trim()).putString("kwp",kwpS).apply()
          startMonitor(ctx); fcKey++; tab=0},Modifier.fillMaxWidth()){Text("Save & connect")}
      }
    }
    Row(Modifier.fillMaxWidth().background(DEEP).navigationBarsPadding()){
      NavItem("Live",I_LIVE,tab==0,Modifier.weight(1f)){tab=0}
      NavItem("Extras",I_EXTRA,tab==1,Modifier.weight(1f)){tab=1}
      NavItem("Settings",I_SET,tab==2,Modifier.weight(1f)){tab=2} }
  }
  if(wall) WallScreen(Store.d?:DEMO[0].second,Store.runtime){wall=false}
  }
}
