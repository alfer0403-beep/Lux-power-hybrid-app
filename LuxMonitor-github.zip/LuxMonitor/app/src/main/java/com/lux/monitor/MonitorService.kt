package com.lux.monitor
import android.app.*
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import java.time.LocalDate

object Store{
  var d by mutableStateOf<Lux?>(null); var err by mutableStateOf(""); var runtime by mutableStateOf("\u2013")
  val series=mutableStateListOf<Lux>()
  var fc by mutableStateOf<Fc?>(null)
  var via by mutableStateOf("")
}

fun notifier(ctx:Context):NotificationManager=(ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).also{
  it.createNotificationChannel(NotificationChannel("monitor","Background monitoring (silent)",NotificationManager.IMPORTANCE_MIN))
  it.createNotificationChannel(NotificationChannel("live","Outage updates",NotificationManager.IMPORTANCE_LOW))
  it.createNotificationChannel(NotificationChannel("alerts","Alerts",NotificationManager.IMPORTANCE_HIGH)) }

fun build(ctx:Context,ch:String,title:String,text:String,ongoing:Boolean=false):Notification=
  Notification.Builder(ctx,ch).setSmallIcon(if(ch=="alerts") android.R.drawable.ic_dialog_alert else android.R.drawable.ic_dialog_info)
    .setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
    .setContentIntent(PendingIntent.getActivity(ctx,0,Intent(ctx,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE))
    .setOngoing(ongoing).setOnlyAlertOnce(true).build()

fun post(ctx:Context,id:Int,ch:String,title:String,text:String,ongoing:Boolean=false){
  val nm=notifier(ctx); nm.notify(id,build(ctx,ch,title,text,ongoing)) }
fun alert(ctx:Context,id:Int,title:String,text:String)=post(ctx,id,"alerts",title,text)

fun hasLocal(p:SharedPreferences)=!p.getString("h","").isNullOrBlank()&&!p.getString("d","").isNullOrBlank()&&!p.getString("s","").isNullOrBlank()
fun hasLuxCloud(p:SharedPreferences)=!p.getString("lcn","").isNullOrBlank()&&!p.getString("lcp","").isNullOrBlank()&&!p.getString("s","").isNullOrBlank()

fun startMonitor(ctx:Context){
  val pf=ctx.getSharedPreferences("c",0)
  if(!(hasLocal(pf)||hasLuxCloud(pf))) return
  ctx.startForegroundService(Intent(ctx,MonitorService::class.java))
}

class MonitorService:Service(){
  private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
  private var job:Job?=null
  private var wifiLock:android.net.wifi.WifiManager.WifiLock?=null
  private var wake:android.os.PowerManager.WakeLock?=null
  override fun onBind(i:Intent?):IBinder?=null
  override fun onDestroy(){ scope.cancel(); runCatching{wifiLock?.release()}; runCatching{wake?.release()}; LuxClient.close(); super.onDestroy() }
  override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
    val sp=getSharedPreferences("c",0)
    val host=sp.getString("h","")!!.trim(); val dl=sp.getString("d","")!!.trim(); val sn=sp.getString("s","")!!.trim()
    val cap=sp.getString("c","15.36")!!.toDoubleOrNull()?:15.36; val res=sp.getString("r","10")!!.toIntOrNull()?:10
    val low=sp.getString("a","20")!!.toIntOrNull()?:20
    val interval=(sp.getString("pi","10")!!.toIntOrNull()?:10).coerceIn(10,60)
    val extra=sp.getString("xa","0")=="1"
    val useLocal=hasLocal(sp); val useLux=hasLuxCloud(sp)
    notifier(this); History.init(this); Daily.init(this); Monthly.init(this)
    if(sp.getString("wl","1")=="1"){
      if(wifiLock==null){ val wm=applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
        wifiLock=wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF,"lux:wifi"); wifiLock?.setReferenceCounted(false); wifiLock?.acquire() }
      if(wake==null){ val pm=getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        wake=pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK,"lux:cpu"); wake?.setReferenceCounted(false); wake?.acquire() }
    } else { runCatching{wifiLock?.release()}; wifiLock=null; runCatching{wake?.release()}; wake=null }
    val first=build(this,"monitor","Lux Monitor","Monitoring your inverter in the background",true)
    if(Build.VERSION.SDK_INT>=34) startForeground(1,first,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1,first)
    job?.cancel()
    val ctx=this
    job=scope.launch{
      val hist=ArrayDeque<Int>(); val win=maxOf(3,300/interval); val maxS=3600/interval
      var bad=0; var good=0; var fail=0; var out=false; var lowSent=false; var lastUpd=0L
      var lastFault=0L; var lastWarn=0L; var hotSent=false; var imbSent=false; var lastFc=0L; var lastOk=0L; var localRetryAt=0L; var localFails=0; var lastLux=0L; var offlineSince=0L; var offlineSent=false; var lastScan=0L
      while(isActive){
        var cloudTried=false
        try{
          val tNow=System.currentTimeMillis()
          var xo:Lux?=null; var via=""; var lastErr:Exception?=null
          // 1) local dongle first (quick 3 s attempts after a failure, then back off 60 s while away from home)
          if(useLocal&&tNow>=localRetryAt){
            try{ xo=LuxClient.poll(host,dl,sn,localFails>0); via="local"; localFails=0 }
            catch(e:Exception){ lastErr=e; localFails++; localRetryAt=tNow+(if(localFails<3) 5000L else 60000L) } }
          // 2) otherwise the LuxPower cloud (at most every 30 s)
          if(xo==null&&useLux){
            if(tNow-lastLux>=30000L){ cloudTried=true; try{ xo=LuxCloud.poll(sp); via="cloud"; lastLux=tNow }catch(e:Exception){ lastErr=e } }
            else if(Store.d!=null&&Store.via=="cloud"){ xo=Store.d; via="cloud" } }
          if(xo==null&&lastErr==null) lastErr=IllegalStateException("Waiting to retry the inverter")
          val x:Lux=xo?:throw lastErr!!
          Store.via=via
          if(fail>=4&&extra) notifier(ctx).cancel(5)
          fail=0; lastOk=System.currentTimeMillis(); offlineSince=0L; offlineSent=false
          Store.d=x; Store.err=""; Store.series.add(x); while(Store.series.size>maxS) Store.series.removeAt(0)
          hist.addLast(x.load); while(hist.size>win) hist.removeFirst()
          val avg=maxOf(50.0,hist.average())
          val hours=cap*1000*maxOf(0,x.soc-res)/100*0.94/avg
          Store.runtime=if(x.charge>x.discharge+50) "Full in "+hm(cap*1000*(100-x.soc)/100/x.charge) else hm(hours)
          History.add(ctx,x)
          Daily.put(ctx,x); pushWidget(ctx,x,Store.runtime)
          if(tNow-lastScan>=1800000L){ lastScan=tNow; runCatching{ EventLog.scan(ctx) } }
          if(extra){
            fun bit(v:Long)=63-java.lang.Long.numberOfLeadingZeros(v)
            if(x.fault!=0L){ if(x.fault!=lastFault) alert(ctx,8,"Inverter fault","Code 0x${java.lang.Long.toHexString(x.fault)} (bit ${bit(x.fault)}).") } else if(lastFault!=0L) notifier(ctx).cancel(8)
            lastFault=x.fault
            if(x.warn!=0L&&x.warn!=lastWarn) alert(ctx,9,"Inverter warning","Code 0x${java.lang.Long.toHexString(x.warn)} (bit ${bit(x.warn)})")
            lastWarn=x.warn
            val hot=x.tBat>=45||x.cellTMax>=45
            if(hot&&!hotSent){ alert(ctx,6,"Battery temperature high","Battery ${x.tBat.toInt()}\u00B0C, hottest cell ${x.cellTMax}\u00B0C"); hotSent=true } else if(!hot) hotSent=false
            val dmv=(x.cellMaxV-x.cellMinV)*1000
            if(x.cellMaxV>0&&dmv>=150&&!imbSent){ alert(ctx,7,"Cell imbalance","${dmv.toInt()} mV between highest and lowest cell"); imbSent=true } else if(dmv<120) imbSent=false
          }
          val off=x.state in intArrayOf(64,96,128,136,192)||x.vGrid<80
          if(off){ bad++; good=0 } else { good++; bad=0 }
          val now=System.currentTimeMillis()
          val txt="Battery ${x.soc}% \u00B7 about ${hm(hours)} left at ${kw(avg.toInt())} load"
          if(!out&&bad>=3){ out=true; lastUpd=now; alert(ctx,2,"Grid outage",txt) }
          else if(out&&bad>=3&&now-lastUpd>=60000){ lastUpd=now; post(ctx,2,"live","Grid outage",txt,true) }
          if(out&&x.soc<=low&&!lowSent){ alert(ctx,4,"Battery low during outage","${x.soc}% \u00B7 about ${hm(hours)} left"); lowSent=true }
          if(out&&good>=3){ out=false; lowSent=false; notifier(ctx).cancel(2); notifier(ctx).cancel(4); post(ctx,3,"live","Grid restored","Battery ${x.soc}% \u00B7 solar ${kw(x.pv)}") }
          val ld=LocalDate.now(); val hourNow=java.time.LocalTime.now().hour
          val rI=sp.getString("ri","0.25")!!.toDoubleOrNull()?:0.0; val rE=sp.getString("re","0.10")!!.toDoubleOrNull()?:0.0
          if(sp.getString("ws","1")=="1"&&ld.dayOfWeek==java.time.DayOfWeek.SUNDAY&&hourNow>=18&&sp.getString("ws_last","")!=ld.toString()){
            sp.edit().putString("ws_last",ld.toString()).apply()
            val w=period(ld.minusDays(6),ld,rI,rE).s
            post(ctx,11,"live","Weekly summary","Solar ${"%.0f".format(w[0])} kWh, exported ${"%.0f".format(w[3])}, imported ${"%.0f".format(w[2])}, net ${"%.0f".format(w[3]-w[2])} kWh") }
          if(now-lastFc>30*60000L){ lastFc=now
            val la=sp.getString("lat","")!!.trim(); val lo=sp.getString("lon","")!!.trim()
            if(la.isNotEmpty()&&lo.isNotEmpty()) runCatching{fetchForecast(la,lo)}.getOrNull()?.let{ Store.fc=it } }
          val fcn=Store.fc
          if(sp.getString("sw","1")=="1"&&fcn!=null&&hourNow>=17&&sp.getString("sw_last","")!=ld.toString()){
            val f=forecast(fcn,sp.getString("kwp","10")!!.toDoubleOrNull()?:10.0)
            val rec=Daily.days.entries.filter{it.key<ld.toString()&&it.value[0]>1}.sortedByDescending{it.key}.take(7).map{it.value[0]}
            if(f.rows.size>=2&&rec.size>=3){
              val usual=rec.average(); val tm=f.rows[1].prod
              if(tm<0.4*usual&&x.soc<70){ sp.edit().putString("sw_last",ld.toString()).apply()
                alert(ctx,10,"Low sun forecast for tomorrow","Forecast ${"%.0f".format(tm)} kWh vs usual ${"%.0f".format(usual)}. Battery is at ${x.soc}%. Consider charging it fully if a storm is coming.") } } }
        }catch(e:CancellationException){throw e}
        catch(e:Exception){
          fail++
          if(e.message?.contains("offline",true)==true){
            if(offlineSince==0L) offlineSince=System.currentTimeMillis()
            if(!offlineSent&&System.currentTimeMillis()-offlineSince>600000L){
              alert(ctx,5,"Inverter offline","The LuxPower cloud has shown your inverter offline for 10 minutes. Power or internet may be out at home."); offlineSent=true } }
          Store.err=if(e.message?.startsWith("Cloud login failed")==true) (e.message?:"") else if(fail>=3) "Reconnecting to the inverter. Showing the last reading"+(if(lastOk>0) " from "+java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date(lastOk)) else "")+"." else ""
          if(extra&&fail==4) alert(ctx,5,"Can't reach inverter","Check Wi-Fi or VPN, or power may be out at home.")
        }
        delay(if(fail>0&&cloudTried) 45000L else if(fail in 1..5) 5000L else (if(Store.via=="cloud") maxOf(interval,30) else interval)*1000L)
      }
    }
    return START_STICKY
  }
}
