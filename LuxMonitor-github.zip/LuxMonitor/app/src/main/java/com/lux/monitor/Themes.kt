package com.lux.monitor
import android.content.SharedPreferences
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** style: 0 = line icons, 1 = solid duotone icons, 2 = badge-tile icons */
class ThemeDef(val name:String,val blurb:String,val style:Int,
  val bg:Color,val card:Color,val line:Color,val line2:Color,val dim:Color,val text:Color,val tile:Color,val track:Color,val deep:Color,val chip:Color,
  val solar:Color,val grid:Color,val gridIn:Color,val home:Color,val battery:Color,val soc:Color)

/** Sunrise and sunset as local minutes after midnight (NOAA approximation), or null in polar day/night. */
fun sunTimes(lat:Double,lon:Double,d:LocalDate):Pair<Int,Int>?{
  val n=d.dayOfYear; val b=2*Math.PI*(n-1)/365.0
  val eq=229.18*(0.000075+0.001868*Math.cos(b)-0.032077*Math.sin(b)-0.014615*Math.cos(2*b)-0.040849*Math.sin(2*b))
  val decl=0.006918-0.399912*Math.cos(b)+0.070257*Math.sin(b)-0.006758*Math.cos(2*b)+0.000907*Math.sin(2*b)-0.002697*Math.cos(3*b)+0.00148*Math.sin(3*b)
  val la=Math.toRadians(lat)
  val c=(Math.cos(Math.toRadians(90.833))-Math.sin(la)*Math.sin(decl))/(Math.cos(la)*Math.cos(decl))
  if(c>1||c<-1) return null
  val h=Math.toDegrees(Math.acos(c))
  val off=ZoneId.systemDefault().rules.getOffset(Instant.now()).totalSeconds/60
  val rise=(720-4*(lon+h)-eq+off).toInt(); val set=(720-4*(lon-h)-eq+off).toInt()
  return Pair(((rise%1440)+1440)%1440,((set%1440)+1440)%1440)
}
fun isNight(sp:SharedPreferences):Boolean{
  val lat=sp.getString("lat","")!!.toDoubleOrNull(); val lon=sp.getString("lon","")!!.toDoubleOrNull()
  val t=java.time.LocalTime.now(); val now=t.hour*60+t.minute
  val st=if(lat!=null&&lon!=null) sunTimes(lat,lon,LocalDate.now()) else null
  val rise=st?.first?:390; val set=st?.second?:1110
  return if(rise<set) now<rise||now>=set else now in set until rise
}

object Th{
  val list=listOf(
    ThemeDef("Midnight Neon","Deep navy with neon accents",0,
      Color(0xFF070B10),Color(0xFF0C131B),Color(0xFF1B2836),Color(0xFF3A4A5E),Color(0xFF9AA8BA),Color(0xFFE6EDF5),Color(0xFF0A0E12),Color(0xFF17212C),Color(0xFF0A1017),Color(0xFF0F2A33),
      Color(0xFFFBBF24),Color(0xFF22D3EE),Color(0xFF60A5FA),Color(0xFFA78BFA),Color(0xFF34D399),Color(0xFFF472B6)),
    ThemeDef("Ember","Warm charcoal with sunset colours",1,
      Color(0xFF0F0A08),Color(0xFF1A120E),Color(0xFF2E2019),Color(0xFF4A3426),Color(0xFFB5A296),Color(0xFFF5EBE4),Color(0xFF130D0A),Color(0xFF2A1D16),Color(0xFF120C09),Color(0xFF3A2212),
      Color(0xFFFFC233),Color(0xFFFF8A3D),Color(0xFFFF5E5E),Color(0xFFE879F9),Color(0xFFA3E635),Color(0xFFFDE68A)),
    ThemeDef("Arctic","Cool slate with icy pastels",2,
      Color(0xFF0B1220),Color(0xFF111B2E),Color(0xFF1E2B44),Color(0xFF3B4C6B),Color(0xFF93A4C0),Color(0xFFE8F0FF),Color(0xFF0D1526),Color(0xFF1A2740),Color(0xFF0C1424),Color(0xFF12304A),
      Color(0xFFFFD97A),Color(0xFF7DD3FC),Color(0xFFA5B4FC),Color(0xFFC4B5FD),Color(0xFF6EE7B7),Color(0xFFF9A8D4)))
  var idx by mutableStateOf(0)
  var auto by mutableStateOf(false)
  var dayIdx by mutableStateOf(2)
  val cur:ThemeDef get()=list[idx.coerceIn(0,list.size-1)]
}

@Composable fun AppearanceCard(sp:SharedPreferences){
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
      Text("Appearance",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=WHITE)
      Th.list.forEachIndexed{ i,t->
        val sel=!Th.auto&&Th.idx==i
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if(sel) TRACK else TILE)
          .clickable{ Th.auto=false; Th.idx=i; sp.edit().putString("theme",i.toString()).apply() }.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
          Column(Modifier.weight(1f)){
            Text(t.name,fontSize=13.sp,fontWeight=FontWeight.Bold,color=WHITE)
            Text(t.blurb,fontSize=11.sp,color=DIM)
            Row(Modifier.padding(top=6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
              listOf(t.solar,t.grid,t.gridIn,t.home,t.battery,t.soc).forEach{ Box(Modifier.size(14.dp).clip(CircleShape).background(it)) } } }
          if(sel) Text("Selected",fontSize=11.sp,fontWeight=FontWeight.Bold,color=GREEN) } }
      Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if(Th.auto) TRACK else TILE)
        .clickable{ Th.auto=true; Th.idx=if(isNight(sp)) 1 else Th.dayIdx; sp.edit().putString("theme","auto").apply() }.padding(10.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
          Column(Modifier.weight(1f)){
            Text("Auto: Ember at night",fontSize=13.sp,fontWeight=FontWeight.Bold,color=WHITE)
            Text("Switches at sunset and sunrise. Uses the location from the forecast settings, otherwise 6:30 and 18:30.",fontSize=11.sp,color=DIM) }
          if(Th.auto) Text("Selected",fontSize=11.sp,fontWeight=FontWeight.Bold,color=GREEN) }
        if(Th.auto) Row(Modifier.padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
          Text("Daytime look:",fontSize=11.sp,color=DIM)
          listOf(0 to "Midnight Neon",2 to "Arctic").forEach{ (i,n)->
            Button({ Th.dayIdx=i; Th.idx=if(isNight(sp)) 1 else i; sp.edit().putString("autoDay",i.toString()).apply() },contentPadding=PaddingValues(10.dp,2.dp),
              colors=ButtonDefaults.buttonColors(containerColor=if(Th.dayIdx==i) CYAN else TILE,contentColor=if(Th.dayIdx==i) Color.Black else WHITE)){ Text(n,fontSize=11.sp) } } } } } }
}

@Composable fun IconPackCard(sp:SharedPreferences){
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
      Text("Icon pack",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=WHITE)
      Packs.list.forEachIndexed{ i,pk->
        val sel=Packs.idx==i
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if(sel) TRACK else TILE)
          .clickable{ Packs.idx=i; sp.edit().putString("pack",i.toString()).apply() }.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
          Column(Modifier.weight(1f)){
            Text(pk.name,fontSize=13.sp,fontWeight=FontWeight.Bold,color=WHITE)
            Text(pk.blurb,fontSize=11.sp,color=DIM)
            Canvas(Modifier.fillMaxWidth().height(44.dp).padding(top=8.dp)){
              val g=size.height*0.62f
              listOf(pk.sol to AMBER,pk.grid to CYAN,pk.home to VIOLET,pk.bat to GREEN,pk.inv to CYAN,pk.live to AMBER).forEachIndexed{ k,e->
                icon(e.first,e.second,Offset(g*0.9f+k*g*1.9f,size.height/2f),g,true,false,pk) } } }
          if(sel) Text("Selected",fontSize=11.sp,fontWeight=FontWeight.Bold,color=GREEN) } } } }
}
