package com.lux.monitor
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** style: 0 = line icons, 1 = solid duotone icons, 2 = badge-tile icons */
class ThemeDef(val name:String,val blurb:String,val style:Int,
  val bg:Color,val card:Color,val line:Color,val line2:Color,val dim:Color,val text:Color,val tile:Color,val track:Color,val deep:Color,val chip:Color,
  val solar:Color,val grid:Color,val gridIn:Color,val home:Color,val battery:Color,val soc:Color)

object Th{
  val list=listOf(
    ThemeDef("Midnight Neon","Deep navy with neon accents and clean line icons",0,
      Color(0xFF070B10),Color(0xFF0C131B),Color(0xFF1B2836),Color(0xFF3A4A5E),Color(0xFF9AA8BA),Color(0xFFE6EDF5),Color(0xFF0A0E12),Color(0xFF17212C),Color(0xFF0A1017),Color(0xFF0F2A33),
      Color(0xFFFBBF24),Color(0xFF22D3EE),Color(0xFF60A5FA),Color(0xFFA78BFA),Color(0xFF34D399),Color(0xFFF472B6)),
    ThemeDef("Ember","Warm charcoal with sunset colours and solid duotone icons",1,
      Color(0xFF0F0A08),Color(0xFF1A120E),Color(0xFF2E2019),Color(0xFF4A3426),Color(0xFFB5A296),Color(0xFFF5EBE4),Color(0xFF130D0A),Color(0xFF2A1D16),Color(0xFF120C09),Color(0xFF3A2212),
      Color(0xFFFFC233),Color(0xFFFF8A3D),Color(0xFFFF5E5E),Color(0xFFE879F9),Color(0xFFA3E635),Color(0xFFFDE68A)),
    ThemeDef("Arctic","Cool slate with icy pastels and badge-style icons",2,
      Color(0xFF0B1220),Color(0xFF111B2E),Color(0xFF1E2B44),Color(0xFF3B4C6B),Color(0xFF93A4C0),Color(0xFFE8F0FF),Color(0xFF0D1526),Color(0xFF1A2740),Color(0xFF0C1424),Color(0xFF12304A),
      Color(0xFFFFD97A),Color(0xFF7DD3FC),Color(0xFFA5B4FC),Color(0xFFC4B5FD),Color(0xFF6EE7B7),Color(0xFFF9A8D4)))
  var idx by mutableStateOf(0)
  val cur:ThemeDef get()=list[idx.coerceIn(0,list.size-1)]
}

@Composable fun AppearanceCard(sp:SharedPreferences){
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
      Text("Appearance",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=WHITE)
      Th.list.forEachIndexed{ i,t->
        val sel=Th.idx==i
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if(sel) TRACK else TILE)
          .clickable{ Th.idx=i; sp.edit().putString("theme",i.toString()).apply() }.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
          Column(Modifier.weight(1f)){
            Text(t.name,fontSize=13.sp,fontWeight=FontWeight.Bold,color=WHITE)
            Text(t.blurb,fontSize=11.sp,color=DIM)
            Row(Modifier.padding(top=6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
              listOf(t.solar,t.grid,t.gridIn,t.home,t.battery,t.soc).forEach{ Box(Modifier.size(14.dp).clip(CircleShape).background(it)) } } }
          if(sel) Text("Selected",fontSize=11.sp,fontWeight=FontWeight.Bold,color=GREEN) } } } }
}
