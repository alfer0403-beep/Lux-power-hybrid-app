package com.lux.monitor

import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.PathMeasure
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.sin

/** Latest current weather from Open-Meteo (filled by fetchForecast). */
class WxData(val code:Int,val cloud:Int,val isDay:Boolean)
object WxState{ var data by mutableStateOf<WxData?>(null) }
/** true = sky scene, false = classic ring. Set from Settings > Appearance. */
object SceneCfg{ var on by mutableStateOf(true) }

@Composable fun HeroOrScene(x:Lux,rt:String){
  if(SceneCfg.on) SkyScene(x,rt) else Hero(x,rt)
}

private fun riseSet(sp:SharedPreferences):Pair<Int,Int>{
  val lat=sp.getString("lat","")!!.toDoubleOrNull(); val lon=sp.getString("lon","")!!.toDoubleOrNull()
  return (if(lat!=null&&lon!=null) sunTimes(lat,lon,LocalDate.now()) else null) ?: Pair(390,1110)
}

private fun wxText(w:WxData?,day:Float):String{
  if(w==null) return "Add location"
  return when{
    w.code==0 -> if(day<0.5f) "Clear night" else "Clear"
    w.code in 1..3 -> "Partly cloudy"
    w.code==45||w.code==48 -> "Fog"
    w.code in 51..67||w.code in 80..82 -> "Rain"
    w.code in 71..77||w.code in 85..86 -> "Snow"
    w.code>=95 -> "Thunderstorm"
    else -> "Cloudy"
  }
}

/** Soft cloud made of overlapping rounded blobs, in 360x330 design units. */
private fun DrawScope.drawCloud(cx:Float,cy:Float,s:Float,k:Float,col:Color,a:Float){
  drawRoundRect(color=col,topLeft=Offset((cx-38f*s)*k,(cy-6f*s)*k),size=Size(76f*s*k,22f*s*k),cornerRadius=CornerRadius(11f*s*k),alpha=a)
  drawCircle(color=col,radius=15f*s*k,center=Offset((cx-14f*s)*k,(cy-6f*s)*k),alpha=a)
  drawCircle(color=col,radius=20f*s*k,center=Offset((cx+6f*s)*k,(cy-10f*s)*k),alpha=a)
  drawCircle(color=col,radius=13f*s*k,center=Offset((cx+26f*s)*k,(cy-4f*s)*k),alpha=a)
}

/** Quadratic curve from a to b, bowed by [bow] pixels (negative = upward). */
private fun curve(a:Offset,b:Offset,bow:Float):Path=Path().apply{
  moveTo(a.x,a.y)
  quadraticBezierTo((a.x+b.x)/2f,(a.y+b.y)/2f+bow,b.x,b.y)
}

/** Base track, glow, then particles that travel along the curve. Speed scales with watts. */
private fun DrawScope.flowLine(p:Path,col:Color,on:Boolean,watts:Double,t:Float,k:Float){
  drawPath(p,col.copy(alpha=if(on)0.18f else 0.08f),style=Stroke(width=if(on)10f*k else 3f*k,cap=StrokeCap.Round))
  drawPath(p,col.copy(alpha=if(on)0.85f else 0.25f),style=Stroke(width=if(on)2.2f*k else 1.4f*k,cap=StrokeCap.Round))
  if(!on) return
  val pm=PathMeasure(p.asAndroidPath(),false)
  val len=pm.length
  if(len<=0f) return
  val n=if(watts>1500) 4 else 2
  val speed=0.12f+(watts.toFloat()/4000f).coerceAtMost(0.8f)
  val pos=FloatArray(2)
  for(i in 0 until n){
    val f=((t*speed)+i.toFloat()/n)%1f
    pm.getPosTan(f*len,pos,null)
    drawCircle(col,radius=8f*k,center=Offset(pos[0],pos[1]),alpha=0.25f)
    drawCircle(col,radius=3.2f*k,center=Offset(pos[0],pos[1]))
  }
}

/** Sky scene: the real photo of the house, drifting clouds, curved animated power flows, live readouts. */
@Composable fun SkyScene(x:Lux,rt:String){
  val ctx=LocalContext.current
  val sp=ctx.getSharedPreferences("c",0)
  val tm=rememberTextMeasurer()
  val photo=remember{ BitmapFactory.decodeResource(ctx.resources,R.drawable.house_photo).asImageBitmap() }
  var tSec by remember{ mutableStateOf(0f) }
  LaunchedEffect(Unit){
    var last=0L
    while(true){ withFrameNanos{ n -> if(last!=0L) tSec+=(n-last)/1e9f; last=n } }
  }
  val now=LocalTime.now(); val m=now.hour*60+now.minute
  val (rise,set)=riseSet(sp)
  val w=WxState.data; val code=w?.code?:0; val cloud=w?.cloud?:10
  val dawnT=((m-(rise-40)).toFloat()/80f).coerceIn(0f,1f)
  val duskT=(((set+40)-m).toFloat()/80f).coerceIn(0f,1f)
  val day=minOf(dawnT,duskT)
  val rainy=code in 51..67||code in 80..82||code>=95
  val snowy=code in 71..77||code in 85..86
  val clock="%02d:%02d".format(now.hour,now.minute)

  Canvas(Modifier.fillMaxWidth().aspectRatio(360f/330f)){
    val k=size.width/360f
    val full=IntSize(size.width.toInt(),size.height.toInt())
    fun P(a:Float,b:Float)=Offset(a*k,b*k)

    // 1) Photo, cropped to the scene aspect and centred on the house
    val bw=photo.width; val bh=photo.height
    val srcW=minOf(bw,(bh*360f/330f).toInt())
    val srcX=((bw*0.62f)-srcW/2f).toInt().coerceIn(0,bw-srcW)
    drawImage(image=photo,srcOffset=IntOffset(srcX,0),srcSize=IntSize(srcW,bh),dstSize=full)

    // 2) Time-of-day and weather tint
    drawRect(color=Color(0xFF050A18),alpha=(1f-day)*0.35f)
    val greyA=if(rainy||snowy||cloud>70) 0.35f else if(cloud>40) 0.12f else 0f
    drawRect(color=Color(0xFF8A9BB0),alpha=greyA)
    drawRect(brush=Brush.verticalGradient(listOf(Color(0x99000000),Color.Transparent),0f,size.height*0.35f),size=Size(size.width,size.height*0.35f))
    drawRect(brush=Brush.verticalGradient(listOf(Color.Transparent,Color(0xCC000000)),size.height*0.7f,size.height),topLeft=Offset(0f,size.height*0.7f),size=Size(size.width,size.height*0.3f))

    // 3) Stars at night, upper sky only
    val starA=(1f-day)*(if(cloud>60) 0.2f else 0.5f)
    if(starA>0.02f){
      val rnd=java.util.Random(11)
      repeat(60){
        val sx=rnd.nextFloat()*360f; val sy=rnd.nextFloat()*110f; val ph=rnd.nextFloat()*6.28f
        drawCircle(color=Color.White,radius=(0.6f+rnd.nextFloat()*0.8f)*k,center=P(sx,sy),alpha=starA*(0.55f+0.45f*sin(tSec*1.3f+ph)))
      }
    }

    // 4) Drifting clouds, density from live cloud cover
    val nClouds=(when{ cloud<15->0; cloud<40->2; cloud<70->4; else->6 })+(if(rainy) 2 else 0)
    val cCol=lerp(Color(0xFFE8EEF7),Color(0xFF8E9BB3),1f-day)
    repeat(nClouds){ i->
      val speed=3f+(i%3)*2f
      val cx=((((i*97+40)%400)+tSec*speed)%420f)-30f
      val cy=26f+((i*29)%55).toFloat()
      drawCloud(cx,cy,0.9f+(i%3)*0.25f,k,cCol,0.10f+0.30f*(cloud/100f))
    }

    // 5) Rain, snow, fog, storm flash
    if(rainy){ repeat(40){ i->
      val x0=((i*53)%360).toFloat(); val y0=((((i*41)%250).toFloat()+tSec*140f)%250f)+40f
      if(y0<300f) drawLine(color=Color(0xFF9ED8FF),start=P(x0,y0),end=P(x0-5f,y0+12f),strokeWidth=1.2f*k,cap=StrokeCap.Round,alpha=0.4f)
    } }
    if(snowy){ repeat(34){ i->
      val x0=((i*61)%360).toFloat(); val y0=((((i*43)%250).toFloat()+tSec*120f)%250f)+40f
      if(y0<300f) drawCircle(color=Color.White,radius=1.8f*k,center=P(x0,y0),alpha=0.7f)
    } }
    if(code>=95&&(tSec%5f)>4.8f) drawRect(color=Color.White,alpha=0.12f)

    // 6) Anchor points (design units), hub above the roof
    val H=P(180f,70f); val S=P(200f,150f); val G=P(70f,126f); val B=P(90f,206f); val L=P(306f,196f)

    // 7) Curved, animated flows
    flowLine(curve(S,H,-18f*k),AMBER,x.pv>20,x.pv.toDouble(),tSec,k)
    if(x.gridOut>20) flowLine(curve(H,G,-22f*k),CYAN,true,x.gridOut.toDouble(),tSec,k)
    else flowLine(curve(G,H,-22f*k),BLUE,x.gridIn>20,x.gridIn.toDouble(),tSec,k)
    if(x.discharge>20) flowLine(curve(B,H,-16f*k),GREEN,true,x.discharge.toDouble(),tSec,k)
    else flowLine(curve(H,B,-16f*k),if(x.charge>20) GREEN else DIM,x.charge>20,x.charge.toDouble(),tSec,k)
    flowLine(curve(H,L,-20f*k),VIOLET,x.load>20,x.load.toDouble(),tSec,k)

    // 8) Hub: soft pulse when anything is flowing
    val flowing=x.pv>20||x.gridIn>20||x.gridOut>20||x.charge>20||x.discharge>20||x.load>20
    val pulse=if(flowing) 0.5f+0.5f*sin(tSec*2.2f) else 0f
    drawCircle(color=GREEN.copy(alpha=0.10f+0.14f*pulse),radius=30f*k,center=H)
    drawCircle(color=Color(0xFF0C131B).copy(alpha=0.88f),radius=22f*k,center=H)
    drawCircle(color=WHITE.copy(alpha=0.55f),radius=22f*k,center=H,style=Stroke(1.6f*k))
    drawCircle(color=GREEN,radius=3f*k,center=H,alpha=0.6f+0.4f*pulse)

    // 9) Node dots
    drawCircle(AMBER,5f*k,S); drawCircle(CYAN,5f*k,G)
    drawCircle(if(x.discharge>20) RED else GREEN,5f*k,B); drawCircle(VIOLET,5f*k,L)

    // 10) Readouts
    drawRoundRect(color=Color(0xB3060A12),topLeft=P(150f,108f),size=Size(92f*k,30f*k),cornerRadius=CornerRadius(8f*k))
    label(tm,"SOLAR",156f*k,113f*k,9f*k,AMBER)
    label(tm,kw(x.pv),156f*k,126f*k,14f*k,WHITE,mono=true,bold=true)

    label(tm,"${x.soc}%",14f*k,34f*k,30f*k,WHITE,mono=true,bold=true)
    label(tm,"Runtime $rt",14f*k,58f*k,11f*k,DIM)
    label(tm,wxText(w,day),236f*k,20f*k,11f*k,WHITE,bold=true)
    label(tm,clock,236f*k,36f*k,11f*k,DIM,mono=true)

    drawRoundRect(color=Color(0xB3060A12),topLeft=P(8f,236f),size=Size(344f*k,64f*k),cornerRadius=CornerRadius(14f*k))
    label(tm,if(x.gridOut>20) "TO GRID" else "FROM GRID",18f*k,246f*k,9f*k,if(x.gridOut>20) CYAN else BLUE)
    label(tm,kw(if(x.gridOut>20) x.gridOut else x.gridIn),18f*k,262f*k,14f*k,WHITE,mono=true,bold=true)
    label(tm,"${x.vGrid.toInt()} V  \u00B7  ${"%.1f".format(x.fGrid)} Hz",18f*k,279f*k,9f*k,DIM,mono=true)
    label(tm,if(x.charge>20) "CHARGING" else if(x.discharge>20) "DISCHARGING" else "BATTERY",150f*k,246f*k,9f*k,GREEN,center=true)
    label(tm,"${x.soc}%",150f*k,262f*k,14f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,"HOME",300f*k,246f*k,9f*k,VIOLET,center=true)
    label(tm,kw(x.load),300f*k,262f*k,14f*k,WHITE,mono=true,bold=true,center=true)
  }
}
