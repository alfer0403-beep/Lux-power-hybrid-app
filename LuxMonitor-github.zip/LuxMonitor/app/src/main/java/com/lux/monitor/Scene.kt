package com.lux.monitor

import android.content.SharedPreferences
import android.graphics.PathMeasure
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.sin

/** Latest current weather from Open-Meteo (filled by fetchForecast). */
class WxData(val code:Int,val cloud:Int,val isDay:Boolean)
object WxState{ var data by mutableStateOf<WxData?>(null) }
/** true = sky scene, false = classic ring. Set from Settings > Appearance. */
object SceneCfg{ var on by mutableStateOf(true) }

@Composable fun HeroOrScene(x:Lux,rt:String){
  if(SceneCfg.on) SkyScene(x,rt) else Hero(x,rt)
}

/** Maps Open-Meteo weather codes to the weather names the villa page understands. */
private fun weatherKey(code:Int):String = when{
  code>=95 -> "storm"
  code in 51..67 || code in 80..82 -> "rain"
  code==45 || code==48 -> "fog"
  code in 1..3 -> "partly"
  code==0 -> "clear"
  else -> "cloudy"
}

private fun wxLabel(code:Int):String = when{
  code==0 -> "Clear"
  code in 1..3 -> "Partly cloudy"
  code==45 || code==48 -> "Fog"
  code in 51..67 || code in 80..82 -> "Rain"
  code in 71..77 || code in 85..86 -> "Snow"
  code>=95 -> "Thunderstorm"
  else -> "Cloudy"
}

/** Villa page background colour, used so the cards fade into the scene. */
private val SceneBg = Color(0xFF0D161B)

/** Quadratic curve in 360-wide design units, scaled by k to pixels. */
private fun quad(x0:Float,y0:Float,cx:Float,cy:Float,x1:Float,y1:Float,k:Float):Path=Path().apply{
  moveTo(x0*k,y0*k)
  quadraticBezierTo(cx*k,cy*k,x1*k,y1*k)
}

/** Thin glow track, fine core and small particles along the path. Strength grows with watts (full scale 3 kW). */
private fun DrawScope.flowLine(p:Path,col:Color,on:Boolean,watts:Double,t:Float,k:Float){
  if(!on){
    drawPath(p,col.copy(alpha=0.10f),style=Stroke(2f*k,cap=StrokeCap.Round))
    return
  }
  val s=(watts/3000.0).toFloat().coerceIn(0f,1f)
  drawPath(p,col.copy(alpha=0.15f+0.2f*s),style=Stroke((4f+4f*s)*k,cap=StrokeCap.Round))
  drawPath(p,col.copy(alpha=0.9f),style=Stroke((1f+1.2f*s)*k,cap=StrokeCap.Round))
  val pm=PathMeasure(p.asAndroidPath(),false)
  val len=pm.length
  if(len<=0f) return
  val n=if(watts>1500) 3 else 2
  val speed=0.12f+(watts.toFloat()/4000f).coerceAtMost(0.8f)
  val pos=FloatArray(2)
  for(i in 0 until n){
    val f=((t*speed)+i.toFloat()/n)%1f
    pm.getPosTan(f*len,pos,null)
    drawCircle(col,radius=(3f+2f*s)*k,center=Offset(pos[0],pos[1]),alpha=0.3f)
    drawCircle(Color.White,radius=(1.1f+0.7f*s)*k,center=Offset(pos[0],pos[1]))
  }
}

/** Places a child at design-unit coordinates inside a BoxWithConstraints scope. */
@Composable private fun Pos(k:Dp,px:Float,py:Float,w:Float,h:Float,content:@Composable BoxScope.()->Unit){
  Box(Modifier.offset(k*px,k*py).size(k*w,k*h)) { content() }
}

/** Glass card that fades into the scene: the fill is strongest at the centre and transparent at the edges, and the edge has no hard outline. */
@Composable private fun GlassCard(ic:Path,col:Color,label:String,value:String,sub:String,extra:String=""){
  val shadow=Shadow(color=Color(0xCC000000),blurRadius=6f)
  Row(
    Modifier.fillMaxSize()
      .clip(RoundedCornerShape(12.dp))
      .background(Brush.radialGradient(listOf(SceneBg.copy(alpha=0.78f),SceneBg.copy(alpha=0.0f))))
      .border(0.5.dp,Brush.linearGradient(listOf(col.copy(alpha=0.45f),Color.Transparent)),RoundedCornerShape(12.dp))
      .padding(horizontal=8.dp,vertical=4.dp),
    horizontalArrangement=Arrangement.spacedBy(6.dp),
    verticalAlignment=Alignment.CenterVertically
  ){
    Ico(ic,col,22)
    Column(verticalArrangement=Arrangement.Center){
      Text(label,color=Color.White,fontSize=9.sp,maxLines=1,style=TextStyle(shadow=shadow))
      Text(value,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Medium,maxLines=1,style=TextStyle(shadow=shadow))
      Text(sub,color=col,fontSize=9.sp,maxLines=1,style=TextStyle(shadow=shadow))
      if(extra.isNotEmpty()) Text(extra,color=Color(0xFFD0DAE6),fontSize=9.sp,maxLines=1,style=TextStyle(shadow=shadow))
    }
  }
}

/** Sky scene: the 3D villa (WebView, bundled in assets/villa) with live weather, faded glass cards with every reading, a small hub and thin animated power flows. */
@Composable fun SkyScene(x:Lux,rt:String){
  val ctx=LocalContext.current
  val sp=ctx.getSharedPreferences("c",0)
  val tm=rememberTextMeasurer()
  var loaded by remember{ mutableStateOf(false) }
  var tSec by remember{ mutableStateOf(0f) }
  LaunchedEffect(Unit){
    var last=0L
    while(true){ withFrameNanos{ n -> if(last!=0L) tSec+=(n-last)/1e9f; last=n } }
  }

  val q=sp.getString("villaQ","med")!!
  val web=remember{
    WebView(ctx).apply{
      setBackgroundColor(android.graphics.Color.TRANSPARENT)
      settings.javaScriptEnabled=true
      settings.domStorageEnabled=true
      webViewClient=object:WebViewClient(){
        override fun onPageFinished(view:WebView?,url:String?){ loaded=true }
      }
      // ui=0 hides the built-in panel, touch=0 lets the Android page scroll
      loadUrl("file:///android_asset/villa/index.html?q=$q&ui=0&touch=0")
    }
  }
  DisposableEffect(Unit){ onDispose{ web.destroy() } }

  val w=WxState.data; val code=w?.code?:0; val cloud=w?.cloud?:10
  LaunchedEffect(loaded,code,cloud){
    if(loaded) web.evaluateJavascript("LuxScene.update({live:true,weather:\"${weatherKey(code)}\",cloudCover:$cloud})",null)
  }

  val cap=sp.getString("c","15.36")!!
  val solarPct=(x.pv*100/11500).coerceIn(0,100)
  val loadPct=(x.load*100/11500).coerceIn(0,100)
  val gridPct=if(x.load>0) (x.gridIn*100/x.load).coerceIn(0,100) else 0
  val gridW=if(x.gridOut>20) x.gridOut else x.gridIn
  val gridLabel=if(x.gridOut>20) "Export" else "Grid"
  val chgA=if(x.vBat>0.0) (x.charge-x.discharge)/x.vBat else 0.0
  val gridCol=Color(0xFFE5E7EB)
  val loadCol=Color(0xFF38BDF8)

  Box(Modifier.fillMaxWidth().aspectRatio(360f/250f)){
    AndroidView(factory={web},modifier=Modifier.matchParentSize())
    Canvas(Modifier.matchParentSize()){
      val k=size.width/360f
      // Thin power flows (design units: hub centre 180,108 radius 20)
      flowLine(quad(128f,40f,152f,46f,166f,94f,k),AMBER,x.pv>20,x.pv.toDouble(),tSec,k)
      if(x.gridOut>20) flowLine(quad(166f,122f,150f,130f,128f,132f,k),gridCol,true,x.gridOut.toDouble(),tSec,k)
      else flowLine(quad(128f,132f,150f,130f,166f,122f,k),gridCol,x.gridIn>20,x.gridIn.toDouble(),tSec,k)
      flowLine(quad(194f,94f,214f,80f,232f,66f,k),GREEN,x.load>20,x.load.toDouble(),tSec,k)
      if(x.discharge>20) flowLine(quad(180f,184f,180f,156f,180f,128f,k),GREEN,true,x.discharge.toDouble(),tSec,k)
      else flowLine(quad(180f,128f,180f,156f,180f,184f,k),GREEN,x.charge>20,x.charge.toDouble(),tSec,k)

      // Small glowing hub with house icon
      val hub=Offset(180f*k,108f*k)
      val pulse=0.5f+0.5f*sin(tSec*2.2f)
      drawCircle(GREEN,radius=26f*k,center=hub,alpha=0.12f+0.10f*pulse)
      drawCircle(SceneBg,radius=20f*k,center=hub,alpha=0.85f)
      drawCircle(GREEN,radius=20f*k,center=hub,style=Stroke(1.6f*k),alpha=0.85f)
      icon(I_HOME,Color.White,hub,20f*k,false)

      // Weather, top right
      label(tm,wxLabel(code),236f*k,12f*k,10f*k,Color.White,bold=true)
    }
    BoxWithConstraints(Modifier.matchParentSize()){
      val k=maxWidth/360f
      Pos(k,4f,8f,124f,64f){ GlassCard(I_SOL,AMBER,"Solar","%,d W".format(x.pv),"$solarPct%  S1 ${x.pv1} · S2 ${x.pv2} · S3 ${x.pv3} W") }
      Pos(k,232f,36f,124f,60f){ GlassCard(I_HOME,loadCol,"Load","%,d W".format(x.load),"$loadPct% of inverter") }
      Pos(k,4f,100f,124f,64f){ GlassCard(I_GRID,gridCol,gridLabel,"%,d W".format(gridW),"$gridPct% of home","%.0f V · %.2f Hz".format(x.vGrid,x.fGrid)) }
      Pos(k,116f,186f,128f,62f){ GlassCard(I_BAT,GREEN,"Battery","${x.soc}%","%.1f V | %.1f A".format(x.vBat,chgA),"$cap kWh") }
    }
  }
}
