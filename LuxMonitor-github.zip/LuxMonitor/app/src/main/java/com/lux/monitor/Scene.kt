package com.lux.monitor

import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.asImageBitmap

import android.content.SharedPreferences
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.sin

/** Latest current weather from Open-Meteo (filled by fetchForecast). */
class WxData(val code:Int,val cloud:Int,val isDay:Boolean)
object WxState{ var data by mutableStateOf<WxData?>(null) }
/** true = sky scene, false = classic ring. Set from Settings > Appearance. */
object SceneCfg{ var on by mutableStateOf(true) }

/** Projection of the rendered house (isometric), in 360x330 design units. */
private const val AX_=7.6978f
private const val BX_=-7.6978f
private const val CX_=0f
private const val DX_=164.6044f
private const val EY_=4.4444f
private const val FY_=4.4444f
private const val GY_=-8.8889f
private const val HY_=142.6667f

@Composable fun HeroOrScene(x:Lux,rt:String){
  if(SceneCfg.on) SkyScene(x,rt) else Hero(x,rt)
}

private fun riseSet(sp:SharedPreferences):Pair<Int,Int>{
  val lat=sp.getString("lat","")!!.toDoubleOrNull(); val lon=sp.getString("lon","")!!.toDoubleOrNull()
  return (if(lat!=null&&lon!=null) sunTimes(lat,lon,LocalDate.now()) else null) ?: Pair(390,1110)
}
private fun wxText(w:WxData?,day:Float):String{
  if(w==null) return "Add location"
  return when{
    w.code==0 -> if(day<0.5f) "Clear night" else "Clear"
    w.code in 1..3 -> "Partly cloudy"
    w.code==45||w.code==48 -> "Fog"
    w.code in 51..67||w.code in 80..82 -> "Rain"
    w.code in 71..77||w.code in 85..86 -> "Snow"
    w.code>=95 -> "Thunderstorm"
    else -> "Cloudy"
  }
}
private fun DrawScope.drawCloud(cx:Float,cy:Float,s:Float,k:Float,col:Color,a:Float){
  drawRoundRect(color=col,topLeft=Offset((cx-38f*s)*k,(cy-6f*s)*k),size=Size(76f*s*k,22f*s*k),cornerRadius=CornerRadius(11f*s*k),alpha=a)
  drawCircle(color=col,radius=15f*s*k,center=Offset((cx-14f*s)*k,(cy-6f*s)*k),alpha=a)
  drawCircle(color=col,radius=20f*s*k,center=Offset((cx+6f*s)*k,(cy-10f*s)*k),alpha=a)
  drawCircle(color=col,radius=13f*s*k,center=Offset((cx+26f*s)*k,(cy-4f*s)*k),alpha=a)
}

/** Sky that follows the real time of day and the weather, with a rendered house: live values, flows and battery level drawn on top. */
@Composable fun SkyScene(x:Lux,rt:String){
  val sp=LocalContext.current.getSharedPreferences("c",0)
  val tm=rememberTextMeasurer()
  val resR=LocalContext.current.resources
  val houseImg=remember{ BitmapFactory.decodeResource(resR,R.drawable.scene_base).asImageBitmap() }
  val lightImg=remember{ BitmapFactory.decodeResource(resR,R.drawable.scene_lights).asImageBitmap() }
  val anim by rememberInfiniteTransition(label="sky").animateFloat(0f,1f,infiniteRepeatable(tween(4000,easing=LinearEasing)),label="a")
  val now=LocalTime.now(); val m=now.hour*60+now.minute
  val (rise,set)=riseSet(sp)
  val w=WxState.data; val code=w?.code?:0; val cloud=w?.cloud?:10
  val dawnT=((m-(rise-40)).toFloat()/80f).coerceIn(0f,1f)
  val duskT=(((set+40)-m).toFloat()/80f).coerceIn(0f,1f)
  val day=minOf(dawnT,duskT)
  val warm=(maxOf(0f,1f-abs((m-rise).toFloat())/50f)+maxOf(0f,1f-abs((m-set).toFloat())/50f)).coerceAtMost(1f)
  val rainy=code in 51..67||code in 80..82||code>=95
  val snowy=code in 71..77||code in 85..86
  val grey=if(rainy||snowy||cloud>70) 0.35f else 0f
  val top=lerp(lerp(Color(0xFF04070D),Color(0xFF0D2440),day),Color(0xFF1B2330),grey)
  val bot=lerp(lerp(lerp(Color(0xFF0B1628),Color(0xFF24527F),day),Color(0xFFE0784A),warm*0.55f),Color(0xFF232B38),grey)
  val inDay=m in rise..set
  val tt=if(inDay) (m-rise).toFloat()/maxOf(1,set-rise).toFloat()
    else ((m-set+1440)%1440).toFloat()/maxOf(1,(rise-set+1440)%1440).toFloat()
  val clock="%02d:%02d".format(now.hour,now.minute)
  Canvas(Modifier.fillMaxWidth().aspectRatio(360f/330f)){
    val k=size.width/360f
    val full=IntSize(size.width.toInt(),size.height.toInt())
    fun P(a:Float,b:Float)=Offset(a*k,b*k)
    fun W(x3:Float,y3:Float,z3:Float)=Offset((AX_*x3+BX_*y3+CX_*z3+DX_)*k,(EY_*x3+FY_*y3+GY_*z3+HY_)*k)
    val ground=236f
    // sky and ground
    drawRect(brush=Brush.verticalGradient(listOf(top,bot),0f,ground*k),size=Size(size.width,ground*k))
    drawRect(brush=Brush.verticalGradient(listOf(lerp(bot,Color.Black,0.5f),BG),ground*k,size.height),topLeft=Offset(0f,ground*k),size=Size(size.width,size.height-ground*k))
    // stars at night
    val starA=(1f-day)*(if(cloud>60) 0.35f else 0.9f)
    if(starA>0.02f){
      val rnd=java.util.Random(11)
      repeat(70){
        val sx=rnd.nextFloat()*360f; val sy=rnd.nextFloat()*200f; val ph=rnd.nextFloat()*6.28f
        drawCircle(color=Color.White,radius=(0.6f+rnd.nextFloat()*0.9f)*k,center=P(sx,sy),alpha=starA*(0.55f+0.45f*sin(anim*6.28f+ph)))
      }
    }
    // sun by day, moon by night, on the same arc
    val ax=40f+280f*tt; val ay=118f-92f*sin(Math.PI.toFloat()*tt)
    if(day>0.05f){
      val sc=P(ax,ay)
      drawCircle(brush=Brush.radialGradient(colors=listOf(Color(0xFFFDE68A).copy(alpha=0.5f*day),Color.Transparent),center=sc,radius=70f*k),radius=70f*k,center=sc)
      drawCircle(color=Color(0xFFFDE68A),radius=13f*k,center=sc,alpha=day)
    }
    if(day<0.95f){
      val mc=P(ax,ay); val ma=1f-day
      drawCircle(color=Color(0xFFE2E8F0),radius=11f*k,center=mc,alpha=ma)
      drawCircle(color=top,radius=10f*k,center=mc+Offset(5f*k,-3f*k),alpha=ma)
    }
    // clouds behind the house
    val nClouds=(when{ cloud<15->0; cloud<40->2; cloud<70->4; else->6 })+(if(rainy) 2 else 0)
    val cCol=lerp(Color(0xFF8DA2BF),Color(0xFF2A3446),1f-day)
    repeat(nClouds){ i->
      val cx=(((i*97+40)%400).toFloat()+anim*60f*(1f+(i%3)*0.3f))%400f-20f
      val cy=40f+((i*29)%70).toFloat()
      drawCloud(cx,cy,0.9f+(i%3)*0.25f,k,cCol,0.3f+0.35f*(cloud/100f))
    }
    // rendered house, then night tint and lit windows
    drawImage(image=houseImg,dstSize=full)
    drawRect(color=Color(0xFF060A16),alpha=(1f-day)*0.25f)
    drawImage(image=lightImg,dstSize=full,alpha=(1f-day)*0.95f)
    // battery level, filled on the front face of the stack
    val fz=0.15f+1.9f*(x.soc/100f)
    val bf=Path().apply{
      val a=W(0.75f,7.0f,0.15f); val b=W(2.05f,7.0f,0.15f); val c=W(2.05f,7.0f,fz); val d=W(0.75f,7.0f,fz)
      moveTo(a.x,a.y); lineTo(b.x,b.y); lineTo(c.x,c.y); lineTo(d.x,d.y); close() }
    drawPath(path=bf,color=GREEN.copy(alpha=0.9f))
    // inverter status light
    val led=W(9.28f,0.45f,2.0f)
    drawCircle(color=GREEN,radius=5f*k,center=led,alpha=0.3f)
    drawCircle(color=GREEN,radius=1.8f*k,center=led)
    // rain, snow, fog, storm flash over the house
    if(rainy){ repeat(42){ i->
      val x0=((i*53)%360).toFloat(); val y0=((((i*41)%250).toFloat()+anim*250f)%250f)+40f
      if(y0<ground-4f) drawLine(color=Color(0xFF9ED8FF),start=P(x0,y0),end=P(x0-5f,y0+12f),strokeWidth=1.2f*k,cap=StrokeCap.Round,alpha=0.4f)
    } }
    if(snowy){ repeat(36){ i->
      val x0=((i*61)%360).toFloat(); val y0=((((i*43)%250).toFloat()+anim*250f)%250f)+40f
      if(y0<ground-4f) drawCircle(color=Color.White,radius=1.8f*k,center=P(x0,y0),alpha=0.7f)
    } }
    if(code==45||code==48) drawRect(color=Color(0xFFB8C4D6),topLeft=P(0f,150f),size=Size(size.width,80f*k),alpha=0.22f)
    if(code>=95&&anim>0.94f) drawRect(color=Color.White,alpha=0.12f)
    // animated power flows, anchored to the rendered house
    fun flow(a:Offset,b:Offset,on:Boolean,col:Color,fwd:Boolean){
      if(!on){ drawLine(color=LINE2.copy(alpha=0.5f),start=a,end=b,strokeWidth=2f*k,cap=StrokeCap.Round); return }
      val ph=(if(fwd) 1f-anim else anim)*12f*k
      drawLine(color=col.copy(alpha=0.25f),start=a,end=b,strokeWidth=5f*k,cap=StrokeCap.Round)
      drawLine(color=col,start=a,end=b,strokeWidth=2.6f*k,cap=StrokeCap.Round,pathEffect=PathEffect.dashPathEffect(floatArrayOf(6f*k,8f*k),ph))
    }
    flow(W(3.0f,5.6f,6.6f),W(9.28f,0.45f,1.8f),x.pv>20,AMBER,true)
    flow(W(9.28f,0.45f,0.3f),W(1.4f,6.7f,1.1f),x.charge>20||x.discharge>20,if(x.charge>20) GREEN else RED,x.charge>20)
    flow(W(9.28f,0.45f,1.8f),W(-3f,5f,5.0f),x.gridOut>20||x.gridIn>20,if(x.gridOut>20) CYAN else BLUE,x.gridOut>20)
    flow(W(9.28f,0.45f,1.3f),W(9.28f,0.45f,0.05f),x.load>20,VIOLET,true)
    // readouts
    label(tm,"${x.soc}%",14f*k,34f*k,30f*k,WHITE,mono=true,bold=true)
    label(tm,"Runtime $rt",14f*k,58f*k,11f*k,DIM)
    label(tm,wxText(w,day),236f*k,20f*k,11f*k,WHITE,bold=true)
    label(tm,clock,236f*k,36f*k,11f*k,DIM,mono=true)
    label(tm,"SOLAR",150f*k,66f*k,9f*k,AMBER,center=true)
    label(tm,kw(x.pv),150f*k,82f*k,15f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,if(x.gridOut>20) "TO GRID" else "FROM GRID",14f*k,252f*k,9f*k,if(x.gridOut>20) CYAN else BLUE)
    label(tm,kw(if(x.gridOut>20) x.gridOut else x.gridIn),14f*k,268f*k,14f*k,WHITE,mono=true,bold=true)
    label(tm,"HOME",199f*k,252f*k,9f*k,VIOLET,center=true)
    label(tm,kw(x.load),199f*k,268f*k,14f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,if(x.charge>20) "CHARGING" else if(x.discharge>20) "DISCHARGING" else "BATTERY",262f*k,252f*k,9f*k,GREEN)
    label(tm,"${x.soc}%",262f*k,268f*k,14f*k,WHITE,mono=true,bold=true)
  }
}
