package com.lux.monitor

import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.PathMeasure
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.sin

/** Latest current weather from Open-Meteo (filled by fetchForecast). */
class WxData(val code:Int,val cloud:Int,val isDay:Boolean)
object WxState{ var data by mutableStateOf<WxData?>(null) }
/** true = sky scene, false = classic ring. Set from Settings > Appearance. */
object SceneCfg{ var on by mutableStateOf(true) }

@Composable fun HeroOrScene(x:Lux,rt:String){
  if(SceneCfg.on) SkyScene(x,rt) else Hero(x,rt)
}

private fun riseSet(sp:SharedPreferences):Pair<Int,Int>{
  val lat=sp.getString("lat","")!!.toDoubleOrNull(); val lon=sp.getString("lon","")!!.toDoubleOrNull()
  return (if(lat!=null&&lon!=null) sunTimes(lat,lon,LocalDate.now()) else null) ?: Pair(390,1110)
}

/** Quadratic curve in 360x330 design units, scaled by k to pixels. */
private fun quad(x0:Float,y0:Float,cx:Float,cy:Float,x1:Float,y1:Float,k:Float):Path=Path().apply{
  moveTo(x0*k,y0*k)
  quadraticBezierTo(cx*k,cy*k,x1*k,y1*k)
}

/** Glow track, bright core and particles along the path. Strength grows with watts (full scale 3 kW). */
private fun DrawScope.flowLine(p:Path,col:Color,on:Boolean,watts:Double,t:Float,k:Float){
  if(!on){
    drawPath(p,col.copy(alpha=0.10f),style=Stroke(3f*k,cap=StrokeCap.Round))
    return
  }
  val s=(watts/3000.0).toFloat().coerceIn(0f,1f)
  drawPath(p,col.copy(alpha=0.18f+0.22f*s),style=Stroke((9f+9f*s)*k,cap=StrokeCap.Round))
  drawPath(p,col.copy(alpha=0.95f),style=Stroke((1.8f+2.2f*s)*k,cap=StrokeCap.Round))
  val pm=PathMeasure(p.asAndroidPath(),false)
  val len=pm.length
  if(len<=0f) return
  val n=if(watts>1500) 3 else 2
  val speed=0.12f+(watts.toFloat()/4000f).coerceAtMost(0.8f)
  val pos=FloatArray(2)
  for(i in 0 until n){
    val f=((t*speed)+i.toFloat()/n)%1f
    pm.getPosTan(f*len,pos,null)
    drawCircle(col,radius=(5f+3f*s)*k,center=Offset(pos[0],pos[1]),alpha=0.3f)
    drawCircle(Color.White,radius=(1.8f+1f*s)*k,center=Offset(pos[0],pos[1]))
  }
}

/** Places a child at design-unit coordinates inside a BoxWithConstraints scope. */
@Composable private fun Pos(k:Dp,px:Float,py:Float,w:Float,h:Float,content:@Composable BoxScope.()->Unit){
  Box(Modifier.offset(k*px,k*py).size(k*w,k*h)) { content() }
}

/** Frosted glass card: dark translucent fill, gradient edge in the accent colour. */
@Composable private fun GlassCard(ic:Path,col:Color,label:String,value:String,sub:String,extra:String=""){
  Row(
    Modifier.fillMaxSize()
      .clip(RoundedCornerShape(18.dp))
      .background(Brush.verticalGradient(listOf(Color(0x66121B26),Color(0xD9080D14))))
      .border(1.dp,Brush.linearGradient(listOf(col,Color(0x33FFFFFF))),RoundedCornerShape(18.dp))
      .padding(horizontal=12.dp,vertical=8.dp),
    horizontalArrangement=Arrangement.spacedBy(10.dp),
    verticalAlignment=Alignment.CenterVertically
  ){
    Ico(ic,col,30)
    Column(verticalArrangement=Arrangement.Center){
      Text(label,color=Color.White,fontSize=11.sp,maxLines=1)
      Text(value,color=Color.White,fontSize=17.sp,fontWeight=FontWeight.Medium,maxLines=1)
      Text(sub,color=col,fontSize=11.sp,maxLines=1)
      if(extra.isNotEmpty()) Text(extra,color=Color(0xFFB8C4D4),fontSize=11.sp,maxLines=1)
    }
  }
}

/** Sky scene replicating the reference design: photo, glass cards for solar, grid, load and battery, a glowing hub and curved power flows. */
@Composable fun SkyScene(x:Lux,rt:String){
  val ctx=LocalContext.current
  val sp=ctx.getSharedPreferences("c",0)
  val photo=remember{ BitmapFactory.decodeResource(ctx.resources,R.drawable.house_photo).asImageBitmap() }
  var tSec by remember{ mutableStateOf(0f) }
  LaunchedEffect(Unit){
    var last=0L
    while(true){ withFrameNanos{ n -> if(last!=0L) tSec+=(n-last)/1e9f; last=n } }
  }
  val now=LocalTime.now(); val m=now.hour*60+now.minute
  val (rise,set)=riseSet(sp)
  val dawnT=((m-(rise-40)).toFloat()/80f).coerceIn(0f,1f)
  val duskT=(((set+40)-m).toFloat()/80f).coerceIn(0f,1f)
  val day=minOf(dawnT,duskT)
  val warm=(1f-minOf(abs(m-set),abs(m-rise)).toFloat()/60f).coerceIn(0f,1f)

  val cap=sp.getString("c","15.36")!!
  val solarPct=(x.pv*100/11500).coerceIn(0,100)
  val loadPct=(x.load*100/11500).coerceIn(0,100)
  val gridPct=if(x.load>0) (x.gridIn*100/x.load).coerceIn(0,100) else 0
  val gridW=if(x.gridOut>20) x.gridOut else x.gridIn
  val gridLabel=if(x.gridOut>20) "Export" else "Grid"
  val chgA=if(x.vBat>0.0) (x.charge-x.discharge)/x.vBat else 0.0
  val gridCol=Color(0xFFE5E7EB)
  val loadCol=Color(0xFF38BDF8)

  Box(Modifier.fillMaxWidth().aspectRatio(360f/330f)){
    Canvas(Modifier.matchParentSize()){
      val k=size.width/360f
      // Photo, cropped to the scene aspect and centred on the house
      val bw=photo.width; val bh=photo.height
      val srcW=minOf(bw,(bh*360f/330f).toInt())
      val srcX=((bw*0.62f)-srcW/2f).toInt().coerceIn(0,bw-srcW)
      drawImage(image=photo,srcOffset=IntOffset(srcX,0),srcSize=IntSize(srcW,bh),dstSize=IntSize(size.width.toInt(),size.height.toInt()))
      drawRect(Color(0xFF050A18),alpha=(1f-day)*0.35f)
      drawRect(Brush.verticalGradient(listOf(Color.Transparent,Color(0xFFFF7A3D)),size.height*0.25f,size.height*0.8f),alpha=warm*0.35f)

      // Power flows
      flowLine(quad(140f,70f,158f,70f,159f,97f,k),AMBER,x.pv>20,x.pv.toDouble(),tSec,k)
      if(x.gridOut>20) flowLine(quad(159f,139f,152f,152f,132f,155f,k),gridCol,true,x.gridOut.toDouble(),tSec,k)
      else flowLine(quad(132f,155f,152f,152f,159f,139f,k),gridCol,x.gridIn>20,x.gridIn.toDouble(),tSec,k)
      flowLine(quad(210f,118f,222f,116f,232f,112f,k),GREEN,x.load>20,x.load.toDouble(),tSec,k)
      if(x.discharge>20) flowLine(quad(180f,214f,180f,181f,180f,148f,k),GREEN,true,x.discharge.toDouble(),tSec,k)
      else flowLine(quad(180f,148f,180f,181f,180f,214f,k),GREEN,x.charge>20,x.charge.toDouble(),tSec,k)

      // Glowing hub with house icon
      val hub=Offset(180f*k,118f*k)
      val pulse=0.5f+0.5f*sin(tSec*2.2f)
      drawCircle(GREEN,radius=42f*k,center=hub,alpha=0.14f+0.12f*pulse)
      drawCircle(Color(0xFF0C131B),radius=30f*k,center=hub,alpha=0.92f)
      drawCircle(GREEN,radius=30f*k,center=hub,style=Stroke(2.5f*k),alpha=0.9f)
      icon(I_HOME,Color.White,hub,34f*k,false)
    }
    BoxWithConstraints(Modifier.matchParentSize()){
      val k=maxWidth/360f
      Pos(k,6f,34f,134f,72f){ GlassCard(I_SOL,AMBER,"Solar","%,d W".format(x.pv),"$solarPct% of inverter") }
      Pos(k,6f,122f,126f,66f){ GlassCard(I_GRID,Color(0xFFE5E7EB),gridLabel,"%,d W".format(gridW),"$gridPct% of home") }
      Pos(k,232f,76f,122f,72f){ GlassCard(I_HOME,loadCol,"Load","%,d W".format(x.load),"$loadPct% of inverter") }
      Pos(k,118f,214f,150f,96f){ GlassCard(I_BAT,GREEN,"Battery","${x.soc}%","%.1f V | %.1f A".format(x.vBat,chgA),"$cap kWh") }
    }
  }
}
