package com.lux.monitor
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Backup{
  private val names=listOf("history.csv","daily.csv","monthly.csv")
  fun backup(ctx:Context):String{
    if(android.os.Build.VERSION.SDK_INT<29) return "Backup needs Android 10 or newer"
    val v=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"LuxMonitor_backup.zip");put(MediaStore.Downloads.MIME_TYPE,"application/zip")}
    val u=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v)?:return "Backup failed"
    ZipOutputStream(ctx.contentResolver.openOutputStream(u)).use{ z->
      for(n in names){ val f=File(ctx.filesDir,n); if(f.exists()){ z.putNextEntry(ZipEntry(n)); f.inputStream().use{it.copyTo(z)}; z.closeEntry() } }
      val j=JSONObject(); ctx.getSharedPreferences("c",0).all.forEach{ (k,x)-> j.put(k,x.toString()) }
      z.putNextEntry(ZipEntry("prefs.json")); z.write(j.toString().toByteArray()); z.closeEntry() }
    return "Saved to Downloads/LuxMonitor_backup.zip"
  }
  fun restore(ctx:Context,uri:Uri):String{
    val input=ctx.contentResolver.openInputStream(uri)?:return "Couldn't read the file"
    var n=0
    ZipInputStream(input).use{ z->
      var e=z.nextEntry
      while(e!=null){
        if(e.name=="prefs.json"){
          val j=JSONObject(String(z.readBytes())); val ed=ctx.getSharedPreferences("c",0).edit()
          j.keys().forEach{ ed.putString(it,j.getString(it)) }; ed.apply(); n++
        } else if(e.name in names){ File(ctx.filesDir,e.name).outputStream().use{ z.copyTo(it) }; n++ }
        z.closeEntry(); e=z.nextEntry } }
    return if(n==0) "Not a Lux Monitor backup" else "Restored. Close the app completely and reopen it."
  }
}
