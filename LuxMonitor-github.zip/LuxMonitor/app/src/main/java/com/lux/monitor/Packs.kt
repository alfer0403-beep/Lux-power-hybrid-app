package com.lux.monitor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Path

/** mode 0 = coloured line icons with glow, 1 = thin sharp monochrome icons, 2 = white glyphs on coloured tiles */
class IconPack(val name:String,val blurb:String,val mode:Int,d:Map<String,String>,fillKeys:Set<String>){
  val sol=ip(d.getValue("sol")); val grid=ip(d.getValue("grid")); val home=ip(d.getValue("home")); val bat=ip(d.getValue("bat"))
  val inv=ip(d.getValue("inv")); val run=ip(d.getValue("run")); val live=ip(d.getValue("live")); val his=ip(d.getValue("his"))
  val set=ip(d.getValue("set")); val extra=ip(d.getValue("extra")); val tmp=ip(d.getValue("tmp"))
  private val all=mapOf("sol" to sol,"grid" to grid,"home" to home,"bat" to bat,"inv" to inv,"run" to run,"live" to live,"his" to his,"set" to set,"extra" to extra,"tmp" to tmp)
  val fills:Set<Path> = fillKeys.mapNotNull{ all[it] }.toSet()
}

object Packs{
  val list=listOf(
    IconPack("Classic","Coloured line icons with a soft glow",0,mapOf("sol" to "M4 15 L7 6 H21 L18 15 Z M12 6 L9.5 15 M16.5 6 L14 15 M5.5 10.5 H19.5 M12 15 V20 M8 20 H16",
    "grid" to "M12 2 L6.5 21 M12 2 L17.5 21 M5 6 H19 M8.8 9 H15.2 M7.6 14 H16.4 M8.8 9 L16.4 14 M15.2 9 L7.6 14",
    "home" to "M3.5 11 L12 4 L20.5 11 M6 9.5 V20 H18 V9.5 M10 20 V14 H14 V20",
    "bat" to "M5 7 H17 A2 2 0 0 1 19 9 V15 A2 2 0 0 1 17 17 H5 A2 2 0 0 1 3 15 V9 A2 2 0 0 1 5 7 Z M19 10.5 H21.5 V13.5 H19 M6.5 10.5 V13.5 M10 10.5 V13.5 M13.5 10.5 V13.5",
    "inv" to "M5 3 H19 A2 2 0 0 1 21 5 V19 A2 2 0 0 1 19 21 H5 A2 2 0 0 1 3 19 V5 A2 2 0 0 1 5 3 Z M6 12 C8 7 10 7 12 12 S16 17 18 12",
    "run" to "M3 12 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M12 7 V12 L15.5 14",
    "live" to "M3 12 H7 L9.5 6 L13 18 L15.5 12 H21",
    "his" to "M3 20 H21 M5 16 L10 10 L14 13 L20 5",
    "set" to "M4 8 H20 M4 16 H20 M11.2 8 a2.2 2.2 0 1 0 -4.4 0 a2.2 2.2 0 1 0 4.4 0 M17.2 16 a2.2 2.2 0 1 0 -4.4 0 a2.2 2.2 0 1 0 4.4 0",
    "extra" to "M4 4 H10 V10 H4 Z M14 4 H20 V10 H14 Z M4 14 H10 V20 H4 Z M14 14 H20 V20 H14 Z",
    "tmp" to "M10 14.5 V5 A2 2 0 0 1 14 5 V14.5 A4 4 0 1 1 10 14.5 Z"),emptySet()),
    IconPack("Tesla","Thin, sharp, minimal monochrome icons",1,mapOf("sol" to "M3 5 H21 V16 H3 Z M3 10.5 H21 M9 5 V16 M15 5 V16 M8 20 H16 M12 16 V20",
    "grid" to "M5 22 L12 2 L19 22 M7 15 H17 M9 9 H15 M4 6 H20",
    "home" to "M3 11 L12 3 L21 11 M5 9.5 V21 H19 V9.5",
    "bat" to "M7 2 H17 V22 H7 Z M10 6 H14 M10 10 H14 M10 14 H14",
    "inv" to "M3 5 H21 V19 H3 Z M6 12 C8 8 10 8 12 12 S16 16 18 12",
    "run" to "M3 12 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M12 7 V12 L16 14",
    "live" to "M13 2 L5 13 H11 L10 22 L19 10 H13 Z",
    "his" to "M4 20 H20 M7 20 V12 M12 20 V6 M17 20 V10",
    "set" to "M5 4 V20 M12 4 V20 M19 4 V20 M3 9 H7 M10 15 H14 M17 8 H21",
    "extra" to "M5 5 H9 V9 H5 Z M15 5 H19 V9 H15 Z M5 15 H9 V19 H5 Z M15 15 H19 V19 H15 Z",
    "tmp" to "M10 4 V14 A4 4 0 1 0 14 14 V4 A2 2 0 0 0 10 4 Z M12 8 V16"),emptySet()),
    IconPack("System","Rounded glyphs on coloured tiles, like a phone home app",2,mapOf("sol" to "M7 12 a5 5 0 1 0 10 0 a5 5 0 1 0 -10 0 M12 1.5 V4 M12 20 V22.5 M1.5 12 H4 M20 12 H22.5 M4.6 4.6 L6.4 6.4 M17.6 17.6 L19.4 19.4 M19.4 4.6 L17.6 6.4 M6.4 17.6 L4.6 19.4",
    "grid" to "M9 2 V6.5 M15 2 V6.5 M5.5 6.5 H18.5 V11 A6.5 6.5 0 0 1 5.5 11 Z M12 17.5 V22",
    "home" to "M12 2.5 L2.5 11 H5.5 V21 H10 V15 H14 V21 H18.5 V11 H21.5 Z",
    "bat" to "M3 7.5 H18 A1.5 1.5 0 0 1 19.5 9 V15 A1.5 1.5 0 0 1 18 16.5 H3 A1.5 1.5 0 0 1 1.5 15 V9 A1.5 1.5 0 0 1 3 7.5 Z M19.5 10 H22 V14 H19.5",
    "inv" to "M3 12 C5.5 5 8.5 5 12 12 S18.5 19 21 12",
    "run" to "M3 12 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M12 7 V12 L15.5 14",
    "live" to "M2.5 12 H7 L9.5 5 L14 19 L16.5 12 H21.5",
    "his" to "M4.5 12 H7.5 V20 H4.5 Z M10.5 6 H13.5 V20 H10.5 Z M16.5 10 H19.5 V20 H16.5 Z",
    "set" to "M3 8 H21 M3 16 H21 M9 5 V11 M15 13 V19",
    "extra" to "M4 4 H10 V10 H4 Z M14 4 H20 V10 H14 Z M4 14 H10 V20 H4 Z M14 14 H20 V20 H14 Z",
    "tmp" to "M10 3.5 A2 2 0 0 1 14 3.5 V13.2 A4.5 4.5 0 1 1 10 13.2 Z"),setOf("sol","grid","home","bat","his","extra","tmp")))
  var idx by mutableStateOf(0)
  val cur:IconPack get()=list[idx.coerceIn(0,list.size-1)]
}
