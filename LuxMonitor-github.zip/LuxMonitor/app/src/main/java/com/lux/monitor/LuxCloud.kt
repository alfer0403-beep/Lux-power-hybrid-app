package com.lux.monitor
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts the cloud password with a key that never leaves the phone's secure hardware keystore. */
object Vault{
  private const val AL="luxmonitor_pw"
  private fun key():SecretKey{
    val ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null)
    val k=ks.getKey(AL,null) as? SecretKey
    if(k!=null) return k
    val g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
    g.init(KeyGenParameterSpec.Builder(AL,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
      .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
    return g.generateKey()
  }
  fun enc(s:String):String{
    val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key())
    return Base64.encodeToString(c.iv+c.doFinal(s.toByteArray()),Base64.NO_WRAP)
  }
  fun dec(s:String):String{
    if(s.isEmpty()) return ""
    return try{
      val b=Base64.decode(s,Base64.NO_WRAP); val c=Cipher.getInstance("AES/GCM/NoPadding")
      c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,b,0,12)); String(c.doFinal(b,12,b.size-12))
    }catch(e:Exception){ "" }
  }
}

class SessionExpired:Exception("Session expired")

/** LuxPower / EG4 cloud monitoring API (same endpoints as the web portal). Field names and scaling follow the pylxpweb documentation. */
object LuxCloud{
  private var cookie=""; private var loginAt=0L
  private var energy:JSONObject?=null; private var energyAt=0L
  private var bat:JSONObject?=null; private var batAt=0L
  private fun base(sp:SharedPreferences)=sp.getString("lcu","https://server.luxpowertek.com")!!.trim().trimEnd('/')
  private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")

  private fun call(sp:SharedPreferences,path:String,body:String,isLogin:Boolean=false):JSONObject{
    val c=URL(base(sp)+path).openConnection() as HttpURLConnection
    c.requestMethod="POST"; c.connectTimeout=10000; c.readTimeout=15000; c.doOutput=true
    c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8")
    c.setRequestProperty("Accept","application/json"); c.setRequestProperty("User-Agent","Mozilla/5.0 (compatible; LuxMonitor/1.0)")
    if(!isLogin&&cookie.isNotEmpty()) c.setRequestProperty("Cookie",cookie)
    c.outputStream.use{ it.write(body.toByteArray()) }
    val code=c.responseCode
    if(isLogin){
      val sc=c.headerFields.entries.firstOrNull{ it.key!=null&&it.key.equals("Set-Cookie",true) }?.value
      sc?.firstOrNull{ it.startsWith("JSESSIONID") }?.let{ cookie=it.substringBefore(";") } }
    val txt=(if(code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText()?:""
    if(code==401||code==403) throw SessionExpired()
    if(code !in 200..299) error("Cloud HTTP $code")
    return JSONObject(txt)
  }
  private fun login(sp:SharedPreferences){
    cookie=""
    val u=sp.getString("lcn","")!!.trim(); val p=Vault.dec(sp.getString("lcp","")!!)
    require(u.isNotEmpty()&&p.isNotEmpty()){"Enter your cloud username and password in Settings"}
    val j=call(sp,"/WManage/api/login","account="+enc(u)+"&password="+enc(p),true)
    if(!j.optBoolean("success",false)) error("Cloud login failed: "+j.optString("message",j.optString("msg","check username, password and server")))
    if(cookie.isEmpty()) error("Cloud login gave no session")
    loginAt=System.currentTimeMillis()
  }
  private fun api(sp:SharedPreferences,path:String,sn:String):JSONObject{
    if(cookie.isEmpty()||System.currentTimeMillis()-loginAt>100*60000L) login(sp)
    var j=try{ call(sp,path,"serialNum="+sn) }catch(e:SessionExpired){ login(sp); call(sp,path,"serialNum="+sn) }
    if(!j.optBoolean("success",true)){
      login(sp); j=call(sp,path,"serialNum="+sn)
      if(!j.optBoolean("success",true)) error("Cloud: "+j.optString("message",j.optString("msg","request failed"))) }
    return j
  }

  fun poll(sp:SharedPreferences):Lux{
    val sn=sp.getString("s","")!!.trim()
    require(sn.isNotEmpty()){"Enter the inverter serial in Settings"}
    val r=api(sp,"/WManage/api/inverter/getInverterRuntime",sn)
    if(r.optBoolean("lost",false)) error("The cloud reports the inverter as offline")
    val now=System.currentTimeMillis()
    if(energy==null||now-energyAt>300000L){ energy=runCatching{ api(sp,"/WManage/api/inverter/getInverterEnergyInfo",sn) }.getOrNull()?:energy; energyAt=now }
    if(bat==null||now-batAt>600000L){ bat=runCatching{ api(sp,"/WManage/api/battery/getBatteryInfo",sn) }.getOrNull()?:bat; batAt=now }
    val e=energy; val b=bat
    fun ed(k:String)=(e?.optDouble(k,0.0)?:0.0)/10.0
    val p1=r.optInt("ppv1"); val p2=r.optInt("ppv2"); val p3=r.optInt("ppv3")
    val pv=if(r.optInt("ppv")>0) r.optInt("ppv") else p1+p2+p3
    val toUser=r.optInt("pToUser"); val toGrid=r.optInt("pToGrid"); val peps=r.optInt("peps")
    val status=r.optInt("status")
    val calc=maxOf(0,toUser+r.optInt("pinv")+peps-r.optInt("prec")-toGrid)
    val c114=r.optInt("consumptionPower114",0)
    val load=if(status==64) peps else if(r.has("consumptionPower114")&&!(c114==0&&calc>300)) c114 else calc
    var cMax=0.0; var cMin=0.0; var tMax=0.0; var tMin=0.0; var soh=0; var cyc=0
    val arr=b?.optJSONArray("batteryArray")
    if(arr!=null&&arr.length()>0){
      var mx=0.0; var mn=1e9; var tmx=-1e9; var tmn=1e9; var sh=101; var cy=0
      for(k in 0 until arr.length()){
        val o=arr.getJSONObject(k)
        fun dv(a:String,c2:String)=if(o.has(a)) o.optDouble(a,0.0) else o.optDouble(c2,0.0)
        mx=maxOf(mx,dv("batMaxCellVoltage","cellVoltageMax")/1000.0)
        val mi=dv("batMinCellVoltage","cellVoltageMin")/1000.0; if(mi>0) mn=minOf(mn,mi)
        tmx=maxOf(tmx,dv("batMaxCellTemp","temperature")/10.0); tmn=minOf(tmn,dv("batMinCellTemp","temperature")/10.0)
        sh=minOf(sh,o.optInt("soh",100)); cy=maxOf(cy,o.optInt("cycleCnt",o.optInt("cycleCount",0))) }
      cMax=mx; cMin=if(mn>1e8) 0.0 else mn; tMax=if(tmx<-1e8) 0.0 else tmx; tMin=if(tmn>1e8) 0.0 else tmn; soh=if(sh>100) 0 else sh; cyc=cy }
    val yld=ed("todayYielding"); val imp=ed("todayImport"); val exp=ed("todayExport"); val chg=ed("todayCharging"); val dis=ed("todayDischarging")
    return Lux(soc=r.optInt("soc"),vBat=r.optDouble("vBat",0.0)/10.0,pv=pv,charge=r.optInt("pCharge"),discharge=r.optInt("pDisCharge"),
      gridIn=toUser,gridOut=toGrid,load=load,vGrid=r.optDouble("vacr",0.0)/10.0,fGrid=r.optDouble("fac",0.0)/100.0,
      yld=yld,cons=if(e?.has("todayUsage")==true) ed("todayUsage") else maxOf(0.0,yld+imp+dis-exp-chg),
      chgDay=chg,dischgDay=dis,impDay=imp,expDay=exp,state=status,tInv=r.optDouble("tinner",0.0),tBat=r.optDouble("tBat",0.0),
      cellMaxV=cMax,cellMinV=cMin,cellTMax=tMax,cellTMin=tMin,cycles=cyc,soh=soh,
      totGen=ed("totalYielding"),totExp=ed("totalExport"),totImp=ed("totalImport"),totChg=ed("totalCharging"),totDis=ed("totalDischarging"),
      pv1=p1,pv2=p2,pv3=p3,vEps=r.optDouble("vepsr",0.0)/10.0,
      bmsChgA=r.optDouble("maxChgCurr",0.0)/100.0,bmsDisA=r.optDouble("maxDischgCurr",r.optDouble("maxDischargeCurr",0.0))/100.0,
      batCount=r.optInt("batParallelNum"),batAh=r.optInt("batCapacity"))
  }
  fun test(sp:SharedPreferences):String{
    cookie=""; energy=null; bat=null
    val x=poll(sp)
    return "Logged in. Battery ${x.soc}%, solar ${x.pv} W, load ${x.load} W, today's yield ${"%.1f".format(x.yld)} kWh."
  }
}

@Composable fun LuxCloudCard(sp:SharedPreferences){
  val scope=rememberCoroutineScope()
  var pw by remember{mutableStateOf("")}
  var msg by remember{mutableStateOf("")}
  val saved=Vault.dec(sp.getString("lcp","")!!).isNotEmpty()
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CARD)){
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
      Text("Remote access: LuxPower cloud",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=WHITE)
      Text("Used automatically when the local dongle can't be reached, for example when you are away from home. Your login is stored encrypted on this phone. Data is slightly delayed and polled at most every 30 seconds. Uses the inverter serial entered above.",fontSize=11.sp,color=DIM)
      PrefField(sp,"lcu","LuxPower server","https://server.luxpowertek.com")
      PrefField(sp,"lcn","Cloud username","")
      OutlinedTextField(pw,{ pw=it; if(it.isNotEmpty()) sp.edit().putString("lcp",Vault.enc(it)).apply() },
        label={Text(if(saved) "Cloud password (saved, type to change)" else "Cloud password")},singleLine=true,
        visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
      OutlinedButton({ scope.launch(Dispatchers.IO){ msg=try{ LuxCloud.test(sp) }catch(e:Exception){ "Failed: "+(e.message?:e.toString()) } } },Modifier.fillMaxWidth()){Text("Test cloud login")}
      if(msg.isNotEmpty()) Text(msg,fontSize=12.sp,color=WHITE) } }
}
