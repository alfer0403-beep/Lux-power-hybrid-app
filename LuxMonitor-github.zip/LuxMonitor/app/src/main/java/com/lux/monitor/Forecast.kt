package com.lux.monitor
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

class Fc(val dates:List<String>,val rad:List<Double>,val hrs:List<Pair<LocalDateTime,Double>> = emptyList())          // daily solar radiation in kWh/m2: 14 past days + 7 forecast days
class FDay(val date:String,val prod:Double,val net:Double)
class FRes(val rows:List<FDay>,val k:Double,val n:Int,val err:Double,val note:String,val cons:Double,val bat:Double)

fun fetchForecast(lat:String,lon:String):Fc?{
  val u=URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&daily=shortwave_radiation_sum&hourly=shortwave_radiation&timezone=auto&past_days=14&forecast_days=7")
  val c=u.openConnection() as HttpURLConnection; c.connectTimeout=8000; c.readTimeout=8000
  val root=JSONObject(c.inputStream.bufferedReader().readText()); val j=root.getJSONObject("daily")
  val hj=root.getJSONObject("hourly"); val ht=hj.getJSONArray("time"); val hr=hj.getJSONArray("shortwave_radiation")
  val t=j.getJSONArray("time"); val r=j.getJSONArray("shortwave_radiation_sum")
  return Fc((0 until t.length()).map{t.getString(it)},(0 until r.length()).map{ if(r.isNull(it)) 0.0 else r.getDouble(it)/3.6 },
    (0 until ht.length()).map{ Pair(LocalDateTime.parse(ht.getString(it)),if(hr.isNull(it)) 0.0 else hr.getDouble(it)) })
}
fun sampleFc():Fc{
  val t=LocalDate.now()
  val r=listOf(5.8,6.1,5.2,4.4,6.0,6.2,5.9,3.8,5.5,6.1,5.7,4.9,5.8,6.0, 5.9,6.1,4.2,5.5,6.0,3.1,5.8)
  val hrs=(0 until 21*24).map{ i-> val h=i%24; val day=r[i/24]; Pair(t.minusDays(14).atStartOfDay().plusHours(i.toLong()),if(h in 6..18) Math.sin(Math.PI*(h-6)/12.0)*850.0*day/5.8 else 0.0) }
  return Fc((0 until 21).map{t.minusDays(14L-it).toString()},r,hrs)
}

/** Adaptive model: production = k x daily radiation. k is learned from your recorded daily yield, then
 *  net export = production - typical consumption - typical battery charging (learned from the last 14 recorded days). */
fun forecast(fc:Fc,kwp:Double):FRes{
  val today=LocalDate.now().toString()
  fun yOf(d:String)=Daily.days[d]?.get(0)
  val cal=fc.dates.indices.filter{ fc.dates[it]<today&&(yOf(fc.dates[it])?:0.0)>1&&fc.rad[it]>1 }
  val past=fc.dates.indices.filter{ fc.dates[it]<today }
  val lm=Monthly.lastComplete()
  val k:Double; val note:String
  if(cal.size>=3){ k=cal.map{yOf(fc.dates[it])!!/fc.rad[it]}.sorted().let{it[it.size/2]}; note="learned from ${cal.size} recorded days" }
  else if(lm!=null&&past.isNotEmpty()){ k=lm.second[0]/YearMonth.parse(lm.first).lengthOfMonth()/maxOf(0.5,past.map{fc.rad[it]}.average()); note="scaled from ${lm.first} history" }
  else { k=kwp*0.8; note="estimated from system size" }
  val err=if(cal.isEmpty()) 0.0 else cal.map{ Math.abs(k*fc.rad[it]-yOf(fc.dates[it])!!)/yOf(fc.dates[it])!! }.average()
  val rec=Daily.days.entries.filter{it.key<today}.sortedByDescending{it.key}.take(14).map{it.value}
  val cons:Double; val bat:Double
  if(rec.size>=3){ cons=rec.map{it[1]}.average(); bat=rec.map{it[4]-it[5]}.average() }
  else if(lm!=null){ val n=YearMonth.parse(lm.first).lengthOfMonth(); cons=lm.second[1]/n; bat=(lm.second[4]-lm.second[5])/n }
  else { cons=15.0; bat=0.0 }
  val rows=fc.dates.indices.filter{fc.dates[it]>=today}.map{ val p=k*fc.rad[it]; FDay(fc.dates[it],p,p-cons-bat) }
  return FRes(rows,k,cal.size,err,note,cons,bat)
}

fun monthTable(ri:Double,re:Double):List<Pair<String,List<Double>>>{
  val m=HashMap<String,List<Double>>(Monthly.rows)
  val acc=HashMap<String,DoubleArray>()
  Daily.days.forEach{ (d,v)-> val k=d.substring(0,7); if(!m.containsKey(k)){ val a=acc.getOrPut(k){DoubleArray(8)}; for(i in 0..5) a[i]+=v[i] } }
  acc.forEach{ (k,a)-> a[6]=a[2]*ri; a[7]=a[3]*re; m[k]=a.toList() }
  return m.entries.sortedByDescending{it.key}.map{ Pair(it.key,it.value) }
}

class Period(val s:DoubleArray,val exact:Int,val est:Int,val miss:Int)
/** Totals for a date range. Uses whole imported months exactly, recorded/imported days next, and prorates monthly totals for the rest. */
fun period(f:LocalDate,t:LocalDate,ri:Double,re:Double):Period{
  val s=DoubleArray(8); var exact=0; var est=0; var miss=0
  var d=f
  while(!d.isAfter(t)){
    val ym=YearMonth.from(d); val first=ym.atDay(1); val last=ym.atEndOfMonth()
    val mr=Monthly.rows[ym.toString()]
    if(mr!=null&&!f.isAfter(first)&&!t.isBefore(last)){ for(i in 0..7) s[i]+=mr[i]; exact+=ym.lengthOfMonth(); d=last.plusDays(1); continue }
    val v=Daily.days[d.toString()]
    if(v!=null){ for(i in 0..5) s[i]+=v[i]; s[6]+=v[2]*ri; s[7]+=v[3]*re; exact++ }
    else if(mr!=null){ val n=ym.lengthOfMonth(); for(i in 0..7) s[i]+=mr[i]/n; est++ }
    else miss++
    d=d.plusDays(1)
  }
  return Period(s,exact,est,miss)
}
