package com.lux.monitor
import java.io.DataInputStream
import java.net.*

data class Lux(val soc:Int,val vBat:Double,val pv:Int,val charge:Int,val discharge:Int,
  val gridIn:Int,val gridOut:Int,val load:Int,val vGrid:Double=230.0,val fGrid:Double=50.0,
  val yld:Double=17.3,val cons:Double=11.6,val chgDay:Double=0.7,val dischgDay:Double=0.0,val impDay:Double=7.8,val expDay:Double=12.4,val state:Int=4,
  val tInv:Double=41.0,val tBat:Double=27.0,val cellMaxV:Double=3.345,val cellMinV:Double=3.338,
  val cellTMax:Double=27.5,val cellTMin:Double=26.1,val cycles:Int=112,val soh:Int=100,
  val totGen:Double=12840.0,val totExp:Double=7302.0,val totImp:Double=3121.0,val totChg:Double=2500.0,val totDis:Double=2310.0,val fault:Long=0,val warn:Long=0,
  val pv1:Int=0,val pv2:Int=0,val pv3:Int=0,val vEps:Double=0.0,val e1:Double=0.0,val e2:Double=0.0,val e3:Double=0.0)

/** LuxPower WiFi dongle protocol (TCP 8000). Register numbers verified against the Lux Modbus register list. */
object LuxClient {
  private const val PROTO = 2   // try 1 if the dongle doesn't answer
  private fun crc(b:ByteArray,n:Int):Int{var c=0xFFFF
    for(i in 0 until n){c=c xor (b[i].toInt() and 255);repeat(8){c=if(c and 1!=0)(c shr 1) xor 0xA001 else c shr 1}};return c}

  private fun req(datalog:String,serial:String,reg:Int,count:Int,func:Int=4):ByteArray{
    val d=ByteArray(18); d[1]=func.toByte()
    serial.toByteArray().copyInto(d,2)
    d[12]=reg.toByte();d[13]=(reg shr 8).toByte();d[14]=count.toByte();d[15]=(count shr 8).toByte()
    val c=crc(d,16);d[16]=c.toByte();d[17]=(c shr 8).toByte()
    val h=ByteArray(20);h[0]=0xA1.toByte();h[1]=0x1A;h[2]=PROTO.toByte();h[4]=(d.size+14).toByte()
    h[6]=1;h[7]=0xC2.toByte();datalog.toByteArray().copyInto(h,8);h[18]=d.size.toByte()
    return h+d
  }

  private var sock:Socket?=null
  private var sockHost=""
  @Synchronized fun close(){ runCatching{ sock?.close() }; sock=null }
  @Synchronized private fun conn(host:String,fast:Boolean=false):Socket{
    val c=sock
    if(c!=null&&!c.isClosed&&sockHost==host) return c
    close()
    val n=Socket(); n.connect(InetSocketAddress(host,8000),if(fast) 3000 else 8000); n.soTimeout=6000; n.keepAlive=true; n.tcpNoDelay=true
    sock=n; sockHost=host; return n
  }
  /** Keeps one connection open between polls (fewer handshakes for the dongle) and reconnects once automatically if it drops. */
  @Synchronized fun poll(host:String,datalog:String,serial:String,fast:Boolean=false):Lux{
    var last:Exception?=null
    for(attempt in 0..(if(fast) 0 else 1)){
      try{ return pollOnce(conn(host,fast),datalog,serial) }
      catch(e:Exception){ last=e; close() } }
    throw last!!
  }
  private fun pollOnce(s:Socket,datalog:String,serial:String):Lux{
    val r=IntArray(120); var b3=false
    run{
      val out=s.getOutputStream(); val inp=DataInputStream(s.getInputStream())
      for(base in intArrayOf(0,40,80)){
        try{
          out.write(req(datalog,serial,base,40));out.flush()
          var got=false
          repeat(8){ if(!got){
            val h=ByteArray(8);inp.readFully(h)
            val len=(h[4].toInt() and 255) or ((h[5].toInt() and 255) shl 8)
            val rest=ByteArray(len-2);inp.readFully(rest)
            val p=h+rest
            if(p[7]==0xC2.toByte()&&p.size>=117&&p[21].toInt()==4&&((p[32].toInt() and 255) or ((p[33].toInt() and 255) shl 8))==base){
              for(i in 0 until 40) r[base+i]=(p[35+2*i].toInt() and 255) or ((p[36+2*i].toInt() and 255) shl 8)
              got=true } } }
          if(!got) error("No valid reply from dongle")
          if(base==80) b3=true
        }catch(e:Exception){ if(base==0) throw e else break }
      }
    }
    fun e(i:Int)=r[i]/10.0
    fun sg(v:Int)=if(v>=32768) v-65536 else v
    fun l(i:Int)=((r[i+1].toLong() shl 16) or r[i].toLong())/10.0
    val pv=r[7]+r[8]+r[9]
    val imp=e(37); val exp=e(36)
    val calc=maxOf(0,r[27]+r[16]+r[24]-r[17]-r[26])
    val load=if(r[0]==64) r[24] else if(b3&&!(r[114]==0&&calc>300)) r[114] else calc
    return Lux(r[5] and 255,r[4]/10.0,pv,r[10],r[11],r[27],r[26],load,r[12]/10.0,r[15]/100.0,
      e(28)+e(29)+e(30),maxOf(0.0,imp+e(31)+e(35)-e(32)-exp),e(33),e(34),imp,exp,r[0],
      tInv=sg(r[64]).toDouble(),tBat=sg(r[67]).toDouble(),cellMaxV=r[101]/1000.0,cellMinV=r[102]/1000.0,
      cellTMax=sg(r[103])/10.0,cellTMin=sg(r[104])/10.0,cycles=r[106],soh=(r[5] shr 8) and 255,
      totGen=l(40)+l(42)+l(44),totExp=l(56),totImp=l(58),totChg=l(50),totDis=l(52),
      fault=(r[61].toLong() shl 16) or r[60].toLong(),warn=(r[63].toLong() shl 16) or r[62].toLong(),
      pv1=r[7],pv2=r[8],pv3=r[9],vEps=r[20]/10.0,e1=e(28),e2=e(29),e3=e(30))
  }

  private fun packet(h:DataInputStream):ByteArray{
    val hd=ByteArray(8); h.readFully(hd)
    val len=(hd[4].toInt() and 255) or ((hd[5].toInt() and 255) shl 8)
    val rest=ByteArray(len-2); h.readFully(rest); return hd+rest }
  /** Reads one holding register (function 3). */
  @Synchronized fun readHold(host:String,datalog:String,serial:String,reg:Int):Int{
    close()
    Socket().use{s->
      s.connect(InetSocketAddress(host,8000),8000);s.soTimeout=5000
      s.getOutputStream().apply{write(req(datalog,serial,reg,1,3));flush()}
      val inp=DataInputStream(s.getInputStream())
      repeat(8){ val p=packet(inp)
        if(p[7]==0xC2.toByte()&&p.size>=37&&p[21].toInt()==3&&((p[32].toInt() and 255) or ((p[33].toInt() and 255) shl 8))==reg)
          return (p[35].toInt() and 255) or ((p[36].toInt() and 255) shl 8) } }
    error("No reply reading register $reg")
  }
  /** Writes one holding register (function 6). Always read back afterwards to confirm. */
  @Synchronized fun writeHold(host:String,datalog:String,serial:String,reg:Int,value:Int){
    close()
    Socket().use{s->
      s.connect(InetSocketAddress(host,8000),8000);s.soTimeout=5000
      s.getOutputStream().apply{write(req(datalog,serial,reg,value,6));flush()}
      runCatching{ packet(DataInputStream(s.getInputStream())) } }
  }
}
