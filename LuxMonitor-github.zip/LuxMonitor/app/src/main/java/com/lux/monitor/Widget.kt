package com.lux.monitor
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.compose.ui.graphics.toArgb
import java.time.LocalDate

class LuxWidget:AppWidgetProvider(){
  override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ for(id in ids) m.updateAppWidget(id,views(c)) }
}
class LuxFlowWidget:AppWidgetProvider(){
  override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ for(id in ids) m.updateAppWidget(id,flowViews(c)) }
}
class BootReceiver:BroadcastReceiver(){
  override fun onReceive(c:Context,i:Intent){ if(i.action==Intent.ACTION_BOOT_COMPLETED) startMonitor(c) }
}

/** The widgets follow your chosen theme (including Auto day/night). */
fun widgetTheme(c:Context):ThemeDef{
  val sp=c.getSharedPreferences("c",0); val t=sp.getString("theme","0")!!
  val i=if(t=="auto") (if(isNight(sp)) 1 else (sp.getString("autoDay","2")!!.toIntOrNull()?:2)) else (t.toIntOrNull()?:0)
  return Th.list[i.coerceIn(0,Th.list.size-1)]
}
private fun tap(c:Context)=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)

/** Summary widget: rotates (with a fade) between live status, today's totals and the week. */
fun views(c:Context):RemoteViews{
  val sp=c.getSharedPreferences("c",0); val th=widgetTheme(c)
  val v=sp.getString("w","")!!.split("|")
  val rv=RemoteViews(c.packageName,R.layout.widget)
  intArrayOf(R.id.w_soc,R.id.w_rt,R.id.w_pv,R.id.w_load,R.id.wt_g,R.id.wt_e,R.id.wt_i,R.id.ww_g,R.id.ww_e,R.id.ww_i)
    .forEachIndexed{ i,id-> rv.setTextViewText(id,v.getOrElse(i){"\u2013"}) }
  rv.setTextColor(R.id.w_soc,th.battery.toArgb()); rv.setTextColor(R.id.w_rt,th.text.toArgb())
  rv.setTextColor(R.id.w_pv,th.solar.toArgb()); rv.setTextColor(R.id.w_load,th.home.toArgb())
  for(id in intArrayOf(R.id.wt_g,R.id.ww_g)) rv.setTextColor(id,th.solar.toArgb())
  for(id in intArrayOf(R.id.wt_e,R.id.ww_e)) rv.setTextColor(id,th.grid.toArgb())
  for(id in intArrayOf(R.id.wt_i,R.id.ww_i)) rv.setTextColor(id,th.gridIn.toArgb())
  rv.setInt(R.id.w_bg,"setColorFilter",th.card.toArgb())
  val ts=sp.getLong("wts",0L)
  rv.setChronometer(R.id.w_age,SystemClock.elapsedRealtime()-(if(ts>0) System.currentTimeMillis()-ts else 0L),"%s ago",true)
  rv.setOnClickPendingIntent(R.id.w_root,tap(c))
  return rv
}

/** Animated flow widget: four pre-drawn frames flipped quickly, so the dashes appear to travel along the lines. */
fun flowViews(c:Context):RemoteViews{
  val sp=c.getSharedPreferences("c",0); val th=widgetTheme(c)
  val frames=renderFlow(th,sp.getString("wf","")!!.split("|"))
  val rv=RemoteViews(c.packageName,R.layout.widget_flow)
  intArrayOf(R.id.f0,R.id.f1,R.id.f2,R.id.f3).forEachIndexed{ i,id-> rv.setImageViewBitmap(id,frames[i]) }
  rv.setInt(R.id.wf_bg,"setColorFilter",th.card.toArgb())
  rv.setOnClickPendingIntent(R.id.wf_root,tap(c))
  return rv
}

fun renderFlow(th:ThemeDef,f:List<String>):List<Bitmap>{
  fun n(i:Int)=f.getOrNull(i)?.toDoubleOrNull()?:0.0
  val soc=n(0).toInt(); val pv=n(1); val gin=n(2); val gout=n(3); val load=n(4); val chg=n(5); val dis=n(6)
  val vg=n(7); val ve=n(8); val rt=f.getOrNull(9)?:"-"
  val w=640; val h=320
  fun kwS(x:Double)=if(x>=1000) "%.2f kW".format(x/1000) else "%.0f W".format(x)
  return (0 until 4).map{ fr->
    val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); val cv=Canvas(bmp)
    val p=Paint(Paint.ANTI_ALIAS_FLAG)
    val cx=w/2f; val cy=172f; val r=62f
    fun flow(x1:Float,y1:Float,x2:Float,y2:Float,on:Boolean,col:Int){
      p.style=Paint.Style.STROKE; p.strokeWidth=6f; p.strokeCap=Paint.Cap.ROUND
      p.color=if(on) col else th.line2.toArgb()
      p.pathEffect=if(on) DashPathEffect(floatArrayOf(10f,14f),(24-fr*6).toFloat()) else null
      cv.drawLine(x1,y1,x2,y2,p); p.pathEffect=null }
    flow(cx,80f,cx,cy-r-12,pv>20,th.solar.toArgb())
    if(gout>20) flow(cx-r-12,cy,182f,cy,true,th.grid.toArgb()) else flow(182f,cy,cx-r-12,cy,gin>20,th.gridIn.toArgb())
    flow(cx+r+12,cy,w-182f,cy,load>20,th.home.toArgb())
    p.style=Paint.Style.STROKE; p.strokeWidth=14f; p.color=th.track.toArgb(); cv.drawCircle(cx,cy,r,p)
    p.color=th.battery.toArgb(); p.strokeCap=Paint.Cap.ROUND; cv.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,3.6f*soc,false,p)
    p.style=Paint.Style.FILL; p.textAlign=Paint.Align.CENTER
    p.typeface=Typeface.DEFAULT_BOLD; p.color=th.text.toArgb(); p.textSize=42f; cv.drawText("$soc%",cx,cy+14f,p)
    p.typeface=Typeface.DEFAULT; p.color=th.dim.toArgb(); p.textSize=19f
    cv.drawText(if(chg>20) "charging" else if(dis>20) "discharging" else "idle",cx,cy+40f,p)
    fun node(x:Float,y:Float,label:String,value:String,sub:String,col:Int){
      p.typeface=Typeface.DEFAULT_BOLD; p.color=col; p.textSize=20f; cv.drawText(label,x,y,p)
      p.typeface=Typeface.MONOSPACE; p.color=th.text.toArgb(); p.textSize=30f; cv.drawText(value,x,y+34f,p)
      if(sub.isNotEmpty()){ p.typeface=Typeface.DEFAULT; p.color=th.dim.toArgb(); p.textSize=18f; cv.drawText(sub,x,y+58f,p) } }
    node(cx,32f,"SOLAR",kwS(pv),"",th.solar.toArgb())
    node(98f,cy-26f,if(gout>20||gin<=20) "EXPORT" else "IMPORT",kwS(if(gout>20||gin<=20) gout else gin),if(vg>0) "%.0f V".format(vg) else "",if(gout>20||gin<=20) th.grid.toArgb() else th.gridIn.toArgb())
    node(w-98f,cy-26f,"HOME",kwS(load),if(ve>0) "%.0f V".format(ve) else "",th.home.toArgb())
    p.typeface=Typeface.DEFAULT; p.color=th.dim.toArgb(); p.textSize=22f; cv.drawText("Runtime  "+rt,cx,h-14f,p)
    bmp }
}

fun pushWidget(c:Context,x:Lux,rt:String){
  Daily.init(c); val n=LocalDate.now(); val w=Daily.sum(n.minusDays(6),n).first
  val f={d:Double->"%.1f".format(d)}
  c.getSharedPreferences("c",0).edit()
    .putString("w","${x.soc}%|$rt|${kw(x.pv)}|${kw(x.load)}|${f(x.yld)}|${f(x.expDay)}|${f(x.impDay)}|${f(w[0])}|${f(w[3])}|${f(w[2])}")
    .putString("wf","${x.soc}|${x.pv}|${x.gridIn}|${x.gridOut}|${x.load}|${x.charge}|${x.discharge}|${x.vGrid}|${x.vEps}|$rt")
    .putLong("wts",System.currentTimeMillis()).apply()
  val m=AppWidgetManager.getInstance(c)
  val a=ComponentName(c,LuxWidget::class.java); val b=ComponentName(c,LuxFlowWidget::class.java)
  if(m.getAppWidgetIds(a).isNotEmpty()) m.updateAppWidget(a,views(c))
  if(m.getAppWidgetIds(b).isNotEmpty()) m.updateAppWidget(b,flowViews(c))
}
