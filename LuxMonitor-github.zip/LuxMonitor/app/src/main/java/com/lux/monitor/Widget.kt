package com.lux.monitor
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate

class LuxWidget:AppWidgetProvider(){
  override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ for(id in ids) m.updateAppWidget(id,views(c)) }
}
class BootReceiver:BroadcastReceiver(){
  override fun onReceive(c:Context,i:Intent){ if(i.action==Intent.ACTION_BOOT_COMPLETED) startMonitor(c) }
}
fun views(c:Context):RemoteViews{
  val v=c.getSharedPreferences("c",0).getString("w","")!!.split("|")
  return RemoteViews(c.packageName,R.layout.widget).apply{
    intArrayOf(R.id.w_soc,R.id.w_rt,R.id.w_pv,R.id.w_load,R.id.w_tg,R.id.w_te,R.id.w_ti,R.id.w_wg,R.id.w_we,R.id.w_wi)
      .forEachIndexed{i,id-> setTextViewText(id,v.getOrElse(i){"\u2013"}) }
    setOnClickPendingIntent(R.id.w_root,PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE)) }
}
fun pushWidget(c:Context,x:Lux,rt:String){
  Daily.init(c); val n=LocalDate.now(); val w=Daily.sum(n.minusDays(6),n).first
  val f={d:Double->"%.1f".format(d)}
  c.getSharedPreferences("c",0).edit().putString("w","${x.soc}%|$rt|${kw(x.pv)}|${kw(x.load)}|${f(x.yld)}|${f(x.expDay)}|${f(x.impDay)}|${f(w[0])}|${f(w[3])}|${f(w[2])}").apply()
  AppWidgetManager.getInstance(c).updateAppWidget(ComponentName(c,LuxWidget::class.java),views(c))
}
