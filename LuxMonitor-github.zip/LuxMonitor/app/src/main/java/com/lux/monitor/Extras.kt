package com.lux.monitor
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

fun fmtT(t:LocalDateTime):String=t.format(DateTimeFormatter.ofPattern("EEE HH:mm"))
fun toast(ctx:Context,s:String)=android.widget.Toast.makeText(ctx,s,android.widget.Toast.LENGTH_LONG).show()

@Composable fun PrefField(sp:SharedPreferences,key:String,label:String,def:String,mod:Modifier=Modifier.fillMaxWidth()){
  var v by remember{mutableStateOf(sp.getString(key,def)!!)}
  OutlinedTextField(v,{v=it;sp.edit().putString(key,it).apply()},label={Text(label)},singleLine=true,modifier=mod)
}
@Composable fun PrefSwitch(sp:SharedPreferences,key:String,label:String,def:String="1"){
  var v by remember{mutableStateOf(sp.getString(key,def)=="1")}
  Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween,Alignment.CenterVertically){
    Text(label,color=WHITE,fontSize=13.sp,modifier=Modifier.weight(1f).padding(end=8.dp))
    Switch(v,{v=it;sp.edit().putString(key,if(it) "1" else "0").apply()}) }
}

/** Average household load for each hour of the day, learned from the saved 7-day history. */
fun loadProfile(fallback:Double):DoubleArray{
  val sum=DoubleArray(24); val n=IntArray(24); val z=ZoneId.systemDefault()
  History.pts.forEach{ val h=Instant.ofEpochMilli(it.t).atZone(z).hour; sum[h]+=it.load.toDouble(); n[h]++ }
  val tot=if(n.sum()>0) sum.sum()/n.sum() else fallback
  return DoubleArray(24){ if(n[it]>=5) sum[it]/n[it] else tot }
}

class Outlook(val emptyAt:LocalDateTime?,val minSoc:Int,val socAt:Int?)
fun sunriseOf(f:Fc):LocalDateTime?{
  val r=f.hrs.associate{it.first to it.second}
  var t=LocalDateTime.now().truncatedTo(ChronoUnit.HOURS).plusHours(1)
  for(i in 0 until 47){ if((r[t]?:0.0)>50&&(r[t.minusHours(1)]?:0.0)<=50) return t; t=t.plusHours(1) }
  return null
}
/** Hour-by-hour battery simulation for the next 48 h if the grid were down. */
fun simulate(f:Fc,k:Double,soc:Int,cap:Double,res:Int,prof:DoubleArray,sun:Boolean,target:LocalDateTime?):Outlook{
  val capWh=cap*1000; val resWh=capWh*res/100; var e=capWh*soc/100
  val rad=f.hrs.associate{it.first to it.second}
  var t=LocalDateTime.now().truncatedTo(ChronoUnit.HOURS)
  var minE=e; var at:Int?=null
  for(i in 0 until 48){
    if(t==target) at=(e/capWh*100).toInt()
    val net=(if(sun) k*(rad[t]?:0.0) else 0.0)-prof[t.hour]
    e=if(net>0) minOf(capWh,e+net*0.95) else e+net/0.94
    if(e<minE) minE=e
    if(e<=resWh) return Outlook(t,res,at)
    t=t.plusHours(1)
  }
  return Outlook(null,(minE/capWh*100).toInt(),at)
}
class Win(val start:LocalDateTime,val end:LocalDateTime,val kw:Double)
fun bestWindow(f:Fc,k:Double,prof:DoubleArray):Win?{
  val now=LocalDateTime.now().truncatedTo(ChronoUnit.HOURS); val rad=f.hrs.associate{it.first to it.second}
  var best:Win?=null
  for(i in 0..20){
    val s=now.plusHours(i.toLong())
    val avg=(0..2).map{ val t=s.plusHours(it.toLong()); k*(rad[t]?:0.0)-prof[t.hour] }.average()
    val b=best
    if(b==null||avg/1000.0>b.kw) best=Win(s,s.plusHours(3),avg/1000.0) }
  return best?.takeIf{it.kw>0.5}
}
fun peakShare(ps:Int,pe:Int):Double?{
  var tot=0.0; var pk=0.0; val z=ZoneId.systemDefault()
  History.pts.forEach{ if(it.grid<0){ val w=-it.grid.toDouble(); tot+=w; val h=Instant.ofEpochMilli(it.t).atZone(z).hour
    if(if(ps<=pe) h>=ps&&h<pe else h>=ps||h<pe) pk+=w } }
  return if(tot>0) pk/tot else null
}
class SH(val name:String,val share:Double,val normal:Double)
fun panelHealth():List<SH>?{
  val days=Daily.days.entries.filter{it.value.size>9&&it.value[6]+it.value[7]+it.value[8]>3}.sortedBy{it.key}.takeLast(15)
  if(days.size<3) return null
  fun share(v:List<Double>,i:Int)=v[6+i]/(v[6]+v[7]+v[8])
  val last=days.last().value; val hist=days.dropLast(1)
  return (0..2).map{ i-> SH("String ${i+1}",share(last,i),hist.map{ share(it.value,i) }.sorted().let{ l->l[l.size/2] }) }
}
fun cellTrend():Pair<Double,Double>?{
  val v=Daily.days.entries.filter{it.value.size>9&&it.value[9]>0}.sortedBy{it.key}.map{it.value[9]}
  if(v.size<4) return null
  val recent=v.takeLast(7).average(); val before=v.dropLast(7).takeLast(14).average()
  return Pair(recent,if(before.isNaN()) recent else before)
}

class NW(val startMin:Int,val endMin:Int,val impKwh:Double,val loadKwh:Double)
class NightStat(val n:Int,val startMin:Int,val endMin:Int,val impAvg:Double,val impMin:Double,val impMax:Double,val loadAvg:Double,val loadMax:Double,val hours:Double)
fun fmtMin(m:Int):String="%02d:%02d".format(m/60,m%60)

/** For each recent evening: from when the grid started supplying (import above 150 W for 10 minutes after noon)
 *  until the sun fully took over next morning (solar covering the load for 10 minutes after 04:00). */
fun nightWindows():List<NW>{
  val z=ZoneId.systemDefault()
  val pts=History.pts.toList().sortedBy{it.t}
  if(pts.size<200) return emptyList()
  val ts=pts.map{ Instant.ofEpochMilli(it.t).atZone(z).toLocalDateTime() }
  fun imp(i:Int)=maxOf(0,-pts[i].grid)
  val out=ArrayList<NW>()
  var d=ts.first().toLocalDate(); val last=ts.last().toLocalDate()
  while(d.isBefore(last)){
    val from=d.atTime(12,0); val to=d.plusDays(1).atTime(12,0)
    val idx=pts.indices.filter{ ts[it]>=from&&ts[it]<to }
    fun run(k:Int,c:(Int)->Boolean):Boolean{ if(k+10>idx.size) return false; for(j in k until k+10) if(!c(idx[j])) return false; return true }
    var si=-1
    for(k in idx.indices){ if(ts[idx[k]].toLocalDate()!=d) break; if(imp(idx[k])>150&&run(k){ imp(it)>150 }){ si=k; break } }
    var ek=-1
    if(si>=0) for(k in si+1 until idx.size){ val t=ts[idx[k]]
      if(t.toLocalDate()==d.plusDays(1)&&t.hour>=4&&run(k){ pts[it].pv>=pts[it].load&&imp(it)<150 }){ ek=k; break } }
    if(si>=0&&ek>si){
      var ik=0.0; var lk=0.0; var gap=0.0
      for(k in si until ek){
        val sec=java.time.Duration.between(ts[idx[k]],ts[idx[k+1]]).seconds
        gap=maxOf(gap,sec.toDouble()); val h=minOf(sec,300L)/3600.0
        ik+=imp(idx[k])*h/1000.0; lk+=pts[idx[k]].load*h/1000.0 }
      val dur=java.time.Duration.between(ts[idx[si]],ts[idx[ek]]).toMinutes()
      if(gap<=900&&dur>=120) out.add(NW(ts[idx[si]].hour*60+ts[idx[si]].minute,ts[idx[ek]].hour*60+ts[idx[ek]].minute,ik,lk)) }
    d=d.plusDays(1)
  }
  return out
}
fun nightStat():NightStat?{
  val w=nightWindows(); if(w.isEmpty()) return null
  val s=w.map{it.startMin}.average().toInt(); val e=w.map{it.endMin}.average().toInt()
  return NightStat(w.size,s,e,w.map{it.impKwh}.average(),w.minOf{it.impKwh},w.maxOf{it.impKwh},w.map{it.loadKwh}.average(),w.maxOf{it.loadKwh},(e+1440-s)/60.0)
}

@Composable fun OutlookLine(title:String,o:Outlook?,sr:LocalDateTime?){
  if(o==null) return
  val e=o.emptyAt
  val bad=e!=null&&sr!=null&&e.isBefore(sr)
  val txt=if(e!=null) "Runs down to reserve "+fmtT(e)+(if(sr!=null) (if(bad) " - BEFORE sunrise" else " - after sunrise") else "")
    else "Lasts 48 h or more. Lowest ${o.minSoc}%"
  Column(Modifier.padding(vertical=4.dp)){
    Text(title,fontSize=11.sp,color=DIM)
    Text(txt+(o.socAt?.let{" - about $it% at sunrise"}?:""),fontSize=13.sp,color=if(bad) RED else GREEN) }
}

@Composable fun ColumnScope.ExtrasTab(sp:SharedPreferences,onWall:()->Unit){
  val ctx=LocalContext.current; val scope=rememberCoroutineScope()
  val live=Store.d
  val cap=sp.getString("c","15.36")!!.toDoubleOrNull()?:15.36; val res=sp.getString("r","10")!!.toIntOrNull()?:10
  val cur=sp.getString("cu","$")!!
  val ri=sp.getString("ri","0.25")!!.toDoubleOrNull()?:0.0; val re=sp.getString("re","0.10")!!.toDoubleOrNull()?:0.0
  val coords=sp.getString("lat","")!!.isNotBlank()&&sp.getString("lon","")!!.isNotBlank()
  val src=Store.fc?:(if(!coords) sampleFc() else null)
  val kwp=sp.getString("kwp","10")!!.toDoubleOrNull()?:10.0
  val fr=src?.let{ forecast(it,kwp) }
  val prof=loadProfile(live?.load?.toDouble()?:900.0)
  val soc=live?.soc?:62
  val sRise=src?.let{ sunriseOf(it) }
  val oSun=if(src!=null&&fr!=null) simulate(src,fr.k,soc,cap,res,prof,true,sRise) else null
  val oNo=if(src!=null) simulate(src,0.0,soc,cap,res,prof,false,sRise) else null
  val noSunH=oNo?.emptyAt?.let{ ChronoUnit.HOURS.between(LocalDateTime.now(),it) }?:48L
  val usual=Daily.days.entries.filter{it.value[0]>1}.sortedByDescending{it.key}.take(7).map{it.value[0]}.takeIf{it.isNotEmpty()}?.average()
  val tmrw=fr?.rows?.getOrNull(1)?.prod
  val issues=ArrayList<String>()
  if(soc<80) issues.add("battery at $soc%")
  if(noSunH<24) issues.add("only about $noSunH h of backup without sun")
  if(tmrw!=null&&usual!=null&&tmrw<0.5*usual) issues.add("low sun forecast tomorrow")

  Section("SUNRISE OUTLOOK (IF THE GRID FAILS)",I_SOL,AMBER,expanded=true){
    Text("Battery $soc%, reserve $res%. Uses your usual load for each hour and the hourly sun forecast.",fontSize=11.sp,color=DIM)
    if(src==null) Text("Add your latitude and longitude in Settings for the forecast.",fontSize=12.sp,color=AMBER)
    else{
      if(!coords) Text("Sample forecast - add your location in Settings.",fontSize=12.sp,color=AMBER)
      if(sRise!=null) Text("Next sunrise about "+fmtT(sRise),fontSize=12.sp,color=WHITE,modifier=Modifier.padding(top=6.dp))
      OutlookLine("With the forecast sun",oSun,sRise)
      OutlookLine("With no sun at all (worst case)",oNo,sRise)
    }
    val ns=nightStat(); val st=ns?:NightStat(5,1060,495,7.8,5.1,9.9,9.4,13.1,14.6)
    Spacer(Modifier.height(10.dp))
    Text("GRID WINDOW "+(if(ns==null) "(SAMPLE - NEEDS A RECORDED NIGHT)" else "(LAST ${st.n} NIGHTS)"),fontSize=10.sp,letterSpacing=1.5.sp,color=if(ns==null) AMBER else DIM)
    Text("The grid starts supplying around ${fmtMin(st.startMin)} and the sun fully takes over around ${fmtMin(st.endMin)} (about ${"%.1f".format(st.hours)} h).",fontSize=13.sp,color=WHITE,modifier=Modifier.padding(vertical=4.dp))
    Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
      Kpi("AVG IMPORT",st.impAvg,BLUE,I_GRID,Modifier.weight(1f),"kWh",1)
      Kpi("HEAVIEST",st.impMax,AMBER,I_GRID,Modifier.weight(1f),"kWh",1)
      Kpi("AVG USE",st.loadAvg,VIOLET,I_HOME,Modifier.weight(1f),"kWh",1) }
    val capEff=cap*0.94; val resF=1-res/100.0
    val needT=st.loadAvg*1.2; val needM=st.loadMax*1.2
    val startT=res+needT/capEff*100; val startM=res+needM/capEff*100
    Text("Battery recommendation",fontSize=12.sp,fontWeight=FontWeight.Bold,color=WHITE,modifier=Modifier.padding(top=10.dp))
    Text(if(startT<=100) "Typical night: be at about ${Math.ceil(startT).toInt()}% when the grid starts supplying (around ${fmtMin(st.startMin)}) to ride through on battery with a 20% margin."
      else "A ${"%.1f".format(cap)} kWh bank can't cover a typical night on its own. You would need about ${"%.0f".format(needT/(0.94*resF))} kWh.",fontSize=12.sp,color=if(startT<=100) GREEN else AMBER)
    Text(if(startM<=100) "Heaviest recent night: needs about ${Math.ceil(startM).toInt()}% at the evening start."
      else "Heaviest recent night needs about ${"%.0f".format(needM/(0.94*resF))} kWh of battery.",fontSize=12.sp,color=if(startM<=100) GREEN else AMBER)
    Text("Uses your real load between the grid start and sun takeover, 94% efficiency and your ${res}% reserve. Average import is what the grid supplied in that window.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=4.dp))
  }

  LoadInsightsCard(sp)
  AppliancesCard(sp)
  OffGridCard(sp)

  var confirm by remember{mutableStateOf(false)}
  var smMsg by remember{mutableStateOf("")}
  val host=sp.getString("h","")!!.trim(); val dl=sp.getString("d","")!!.trim(); val sn=sp.getString("s","")!!.trim()
  val target=(sp.getString("smres","90")!!.toIntOrNull()?:90).coerceIn(10,90)
  fun doIt(block:()->String){ scope.launch(Dispatchers.IO){ smMsg=try{ block() }catch(e:Exception){ "Failed: "+(e.message?:e.toString()) } } }
  if(confirm) AlertDialog(onDismissRequest={confirm=false},
    title={Text("Enable storm mode?")},
    text={Text("This changes two settings on your inverter: the discharge cut-off is raised to $target% so the battery is kept full for an outage, and the AC-charge SOC limit is set to 100%. Your current values are saved so you can restore them. AC charging must already be enabled on the inverter for grid charging to happen. This is untested on your hardware, so check the LuxPower app afterwards.")},
    confirmButton={TextButton({ confirm=false
      doIt{
        val a=LuxClient.readHold(host,dl,sn,105); val b=LuxClient.readHold(host,dl,sn,67)
        if(a !in 0..100||b !in 0..100) return@doIt "Unexpected values read ($a, $b). Nothing was changed."
        sp.edit().putString("sm105",a.toString()).putString("sm67",b.toString()).putString("sm_on","1").apply()
        LuxClient.writeHold(host,dl,sn,105,target); LuxClient.writeHold(host,dl,sn,67,100)
        val a2=LuxClient.readHold(host,dl,sn,105); val b2=LuxClient.readHold(host,dl,sn,67)
        if(a2==target&&b2==100) "Storm mode ON. Cut-off $a to $a2%, AC-charge limit $b to $b2%. Originals saved." else "Write not confirmed (read back $a2 and $b2). Check the LuxPower app." }
    }){Text("Enable")}},
    dismissButton={TextButton({confirm=false}){Text("Cancel")}})
  Section("STORM READINESS & STORM MODE",I_BAT,GREEN,summary=if(issues.isEmpty()) "Ready" else "Caution"){
    Text(if(issues.isEmpty()) "Ready: battery is well charged and about ${noSunH}h of backup even with no sun." else "Caution: "+issues.joinToString(", ")+".",
      fontSize=13.sp,color=if(issues.isEmpty()) GREEN else AMBER)
    PrefField(sp,"smres","Storm reserve % (10 to 90)","90")
    Button({ if(host.isBlank()||dl.isBlank()||sn.isBlank()) smMsg="Enter your connection details in Settings first." else confirm=true },Modifier.fillMaxWidth()){Text("Enable storm mode")}
    OutlinedButton({ doIt{ val a=LuxClient.readHold(host,dl,sn,105); val b=LuxClient.readHold(host,dl,sn,67); "Discharge cut-off $a%, AC-charge limit $b%" } },Modifier.fillMaxWidth()){Text("Read inverter settings")}
    OutlinedButton({ doIt{
      val a=sp.getString("sm105","")!!.toIntOrNull(); val b=sp.getString("sm67","")!!.toIntOrNull()
      if(a==null||b==null) return@doIt "No saved original values."
      LuxClient.writeHold(host,dl,sn,105,a); LuxClient.writeHold(host,dl,sn,67,b)
      val a2=LuxClient.readHold(host,dl,sn,105); val b2=LuxClient.readHold(host,dl,sn,67)
      if(a2==a&&b2==b){ sp.edit().putString("sm_on","0").apply(); "Restored: cut-off $a2%, AC-charge limit $b2%." } else "Restore not confirmed (read back $a2 and $b2). Check the LuxPower app." } },Modifier.fillMaxWidth()){Text("Restore normal settings")}
    if(smMsg.isNotEmpty()) Text(smMsg,fontSize=12.sp,color=WHITE)
    if(sp.getString("sm_on","0")=="1") Text("Storm mode is ON. Remember to restore normal settings afterwards.",fontSize=12.sp,color=AMBER)
  }

  val ph=panelHealth(); val ct=cellTrend()
  Section("PANEL & BATTERY HEALTH",I_TMP,CYAN){
    val rows=ph?:listOf(SH("String 1",0.34,0.33),SH("String 2",0.27,0.34),SH("String 3",0.39,0.33))
    if(ph==null) Text("Sample - needs 3 or more recorded days with sun.",fontSize=12.sp,color=AMBER)
    rows.forEach{ r->
      val low=r.share<r.normal*0.85
      Row(Modifier.fillMaxWidth().padding(vertical=3.dp),Arrangement.SpaceBetween){
        Text(r.name,fontSize=12.sp,color=WHITE,modifier=Modifier.weight(1f))
        Text("${(r.share*100).toInt()}% of yield (normal ${(r.normal*100).toInt()}%)",fontSize=12.sp,fontFamily=FontFamily.Monospace,color=DIM)
        Text(if(low) "  CHECK" else "  OK",fontSize=12.sp,fontWeight=FontWeight.Bold,color=if(low) RED else GREEN) } }
    Text("A string producing well under its usual share on a sunny day may be shaded, dirty or faulty.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=6.dp))
    if(ct!=null) Text("Battery cell spread: ${ct.first.toInt()} mV over the last 7 days vs ${ct.second.toInt()} mV before"+(if(ct.first>ct.second+30) " - rising, worth watching." else "."),fontSize=12.sp,color=if(ct.first>ct.second+30) AMBER else WHITE,modifier=Modifier.padding(top=8.dp))
    else Text("Cell spread trend needs 4 or more recorded days.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
  }

  HealthTrendsCard(sp)

  Section("BILL ESTIMATOR & TIME-OF-USE",I_GRID,BLUE){
    PrefField(sp,"fx","Fixed monthly charge","0")
    PrefField(sp,"rp","Peak import rate per kWh (0 = no peak rate)","0")
    Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){ PrefField(sp,"ps","Peak starts (hour)","17",Modifier.weight(1f)); PrefField(sp,"pe","Peak ends (hour)","21",Modifier.weight(1f)) }
    val fx=sp.getString("fx","0")!!.toDoubleOrNull()?:0.0; val rp=sp.getString("rp","0")!!.toDoubleOrNull()?:0.0
    val ps=sp.getString("ps","17")!!.toIntOrNull()?:17; val pe=sp.getString("pe","21")!!.toIntOrNull()?:21
    val today=LocalDate.now(); val share=peakShare(ps,pe)
    val eff=if(rp>0&&share!=null) ri*(1-share)+rp*share else ri
    val pr=period(today.withDayOfMonth(1),today,ri,re).s
    val soFar=pr[2]*eff-pr[3]*re+fx
    val rec=Daily.days.entries.filter{it.key<today.toString()}.sortedByDescending{it.key}.take(7).map{it.value}
    val avgNet=if(rec.isEmpty()) 0.0 else rec.map{ it[2]*eff-it[3]*re }.average()
    val proj=soFar+avgNet*(today.lengthOfMonth()-today.dayOfMonth)
    val lastM=Monthly.rows[YearMonth.now().minusMonths(1).toString()]?.let{ it[6]-it[7] }
    Spacer(Modifier.height(4.dp))
    Row(Modifier.fillMaxWidth(),Arrangement.spacedBy(8.dp)){
      Kpi("SO FAR",soFar,BLUE,I_GRID,Modifier.weight(1f),cur,2); Kpi("PROJECTED",proj,AMBER,I_GRID,Modifier.weight(1f),cur,2)
      Kpi("LAST MONTH",lastM?:0.0,GREEN,I_GRID,Modifier.weight(1f),cur,2) }
    Text("Month to date: import ${"%.0f".format(pr[2])} kWh, export ${"%.0f".format(pr[3])} kWh."+(if(share!=null&&rp>0) " Peak hours are ${(share*100).toInt()}% of your imports (last 7 days), so the import rate is blended." else "")+" Projection assumes the last 7 days continue. Last month comes from your imported Home Assistant data.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=8.dp))
  }

  val bw=if(src!=null&&fr!=null) bestWindow(src,fr.k,prof) else null
  Section("BEST TIME FOR BIG LOADS",I_SOL,AMBER,summary=bw?.let{ "%02d:00-%02d:00".format(it.start.hour,it.end.hour) }?:""){
    if(bw!=null) Text("Run the dryer, EV charger or dishwasher "+fmtT(bw.start)+" to "+fmtT(bw.end)+" - about ${"%.1f".format(bw.kw)} kW of spare solar.",fontSize=13.sp,color=GREEN)
    else Text("No strong solar surplus in the next 24 hours.",fontSize=13.sp,color=DIM)
    Text("Based on the forecast sun and your usual load for each hour.",fontSize=11.sp,color=DIM,modifier=Modifier.padding(top=6.dp))
  }

  val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri-> if(uri!=null) toast(ctx,Backup.restore(ctx,uri)) }
  Section("NOTIFICATIONS, DISPLAY & BACKUP",I_SET,VIOLET){
    PrefSwitch(sp,"ws","Weekly summary (Sundays, 6 pm)")
    PrefSwitch(sp,"sw","Storm-watch alert (low sun tomorrow and low battery)")
    OutlinedButton({ onWall() },Modifier.fillMaxWidth()){Text("Wall display (landscape, screen stays on)")}
    Button({ toast(ctx,Backup.backup(ctx)) },Modifier.fillMaxWidth()){Text("Back up history and settings")}
    OutlinedButton({ restore.launch(arrayOf("*/*")) },Modifier.fillMaxWidth()){Text("Restore from backup")}
    Text("Backup saves history, daily totals, imported months and settings to Downloads.",fontSize=11.sp,color=DIM)
  }
}

@Composable fun WallScreen(x:Lux,rt:String,onExit:()->Unit){
  val ctx=LocalContext.current
  DisposableEffect(Unit){
    val a=ctx as? Activity
    a?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    a?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    onDispose{ a?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; a?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } }
  Column(Modifier.fillMaxSize().background(BG).clickable{onExit()}.verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
    LandscapeBoard(x,rt)
    Text("Tap anywhere to exit",fontSize=11.sp,color=DIM) }
}
