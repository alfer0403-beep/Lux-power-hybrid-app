package com.lux.monitor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import kotlinx.coroutines.delay

import android.content.SharedPreferences
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.rememberTextMeasurer
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.sin

/** Latest current weather from Open-Meteo (filled by fetchForecast). */
class WxData(val code:Int,val cloud:Int,val isDay:Boolean)
object WxState{ var data by mutableStateOf<WxData?>(null) }
/** true = sky scene, false = classic ring. Set from Settings > Appearance. */
object SceneCfg{ var on by mutableStateOf(true) }


@Composable
fun MobileTropicalHero(x: Lux, rt: String) {
    val sp = LocalContext.current.getSharedPreferences("c", 0)

    var minuteTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            minuteTick++
        }
    }

    val now = remember(minuteTick) { LocalTime.now() }
    val minute = now.hour * 60 + now.minute
    val (rise, set) = riseSet(sp)

    val wx = WxState.data
    val code = wx?.code ?: 0
    val cloud = wx?.cloud ?: 10

    val rainy = code in 51..67 || code in 80..82 || code >= 95
    val snowy = code in 71..77 || code in 85..86
    val foggy = code == 45 || code == 48
    val storm = code >= 95

    val day = when {
        minute in rise..set -> 1f
        else -> 0f
    }

    val daylight = (
        (minute - (rise - 35)).toFloat() / 70f
    ).coerceIn(0f, 1f) *
        (((set + 35) - minute).toFloat() / 70f).coerceIn(0f, 1f)

    val transition = rememberInfiniteTransition(label = "portrait-scene")

    val anim by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "scene-motion"
    )

    val pulse by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "energy-pulse"
    )

    val rainAnim by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1000, easing = LinearEasing)),
        label = "rain-motion"
    )

    val flash by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(4500, easing = LinearEasing)),
        label = "lightning"
    )

    val inDay = minute in rise..set
    val sunProgress = if (inDay) {
        (minute - rise).toFloat() / maxOf(1, set - rise)
    } else {
        ((minute - set + 1440) % 1440).toFloat() /
            maxOf(1, (rise - set + 1440) % 1440)
    }.coerceIn(0f, 1f)

    val weather = wxText(wx, if (daylight > 0.5f) 1f else 0f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = Color(0xFF091421)
        )
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(RoundedCornerShape(24.dp))
        ) {

            // Full animated portrait illustration
            Canvas(Modifier.fillMaxSize()) {

                val k = size.width / 360f
                val h = size.height / 500f

                fun p(x: Float, y: Float) =
                    Offset(x * k, y * h)

                val skyTop = lerp(
                    Color(0xFF030817),
                    Color(0xFF1476A6),
                    daylight
                )

                val skyBottom = when {
                    rainy || storm -> Color(0xFF34445A)
                    snowy -> Color(0xFF8196AB)
                    else -> lerp(
                        Color(0xFF111B3B),
                        Color(0xFFFFA66C),
                        daylight * 0.75f
                    )
                }

                // SKY
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(skyTop, skyBottom, Color(0xFF172D3B))
                    )
                )

                // Night stars
                val starAlpha = (1f - daylight) *
                    if (cloud > 60) 0.25f else 0.9f

                if (starAlpha > 0.02f) {
                    val random = java.util.Random(17)
                    repeat(65) {
                        val sx = random.nextFloat() * 360f
                        val sy = random.nextFloat() * 210f
                        val phase = random.nextFloat() * 6.28f
                        val twinkle =
                            0.4f + 0.6f * sin(anim * 6.28f + phase)

                        drawCircle(
                            Color.White,
                            radius = 1.1f * k,
                            center = p(sx, sy),
                            alpha = starAlpha * twinkle
                        )
                    }
                }

                // SUN AND MOON
                val celestialX = 35f + 290f * sunProgress
                val celestialY =
                    135f - 82f * sin(Math.PI.toFloat() * sunProgress)

                if (daylight > 0.02f) {
                    val sun = p(celestialX, celestialY)

                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(
                                Color(0xFFFFE6A0).copy(alpha = 0.55f),
                                Color.Transparent
                            ),
                            center = sun,
                            radius = 65f * k
                        ),
                        radius = 65f * k,
                        center = sun
                    )

                    drawCircle(
                        Color(0xFFFFE7A3),
                        radius = 13f * k,
                        center = sun,
                        alpha = daylight
                    )
                }

                if (daylight < 0.98f) {
                    val moon = p(celestialX, celestialY)
                    val alpha = 1f - daylight

                    drawCircle(
                        Color(0xFFE5EDF8),
                        radius = 11f * k,
                        center = moon,
                        alpha = alpha
                    )

                    drawCircle(
                        skyTop,
                        radius = 10f * k,
                        center = moon + Offset(5f * k, -3f * k),
                        alpha = alpha
                    )
                }

                // MOVING CLOUDS
                val cloudCount = when {
                    cloud < 15 -> 0
                    cloud < 40 -> 2
                    cloud < 70 -> 4
                    else -> 6
                } + if (rainy || snowy) 2 else 0

                val cloudColor = lerp(
                    Color(0xFFE0EAF5),
                    Color(0xFF26374B),
                    if (rainy || snowy) 0.65f else 1f - daylight
                )

                repeat(cloudCount) { i ->
                    val speed = 1f + (i % 3) * 0.35f
                    val cx = (
                        (i * 105f + anim * 85f * speed) % 430f
                    ) - 35f

                    val cy = 55f + (i % 4) * 30f

                    drawCloud(
                        cx, cy,
                        0.8f + (i % 3) * 0.22f,
                        k,
                        cloudColor,
                        0.25f + cloud / 180f
                    )
                }

                // RAIN
                if (rainy) {
                    repeat(75) { i ->
                        val rx = (i * 47f) % 360f
                        val ry = (
                            (i * 37f + rainAnim * 310f) % 250f
                        ) + 80f

                        drawLine(
                            Color(0xFFB9E3FF).copy(alpha = 0.55f),
                            p(rx, ry),
                            p(rx - 5f, ry + 16f),
                            strokeWidth = 1.4f * k,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // SNOW
                if (snowy) {
                    repeat(45) { i ->
                        val sx = (i * 61f) % 360f
                        val sy = ((i * 43f + anim * 180f) % 260f) + 75f

                        drawCircle(
                            Color.White,
                            radius = 2f * k,
                            center = p(sx, sy),
                            alpha = 0.8f
                        )
                    }
                }

                // FOG
                if (foggy) {
                    repeat(4) { i ->
                        val y = 180f + i * 28f
                        val shift = (anim * 80f + i * 75f) % 100f

                        drawLine(
                            Color(0xFFDCE8F4).copy(alpha = 0.18f),
                            p(-20f + shift, y),
                            p(360f + shift, y),
                            strokeWidth = 13f * k,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // LIGHTNING FLASH
                if (storm && flash > 0.94f) {
                    drawRect(
                        Color.White.copy(alpha = 0.18f)
                    )

                    val bolt = Path().apply {
                        moveTo(265f * k, 105f * h)
                        lineTo(245f * k, 145f * h)
                        lineTo(260f * k, 145f * h)
                        lineTo(238f * k, 185f * h)
                    }

                    drawPath(
                        bolt,
                        Color(0xFFFFF4C2),
                        style = Stroke(width = 3f * k)
                    )
                }

                // DISTANT LANDSCAPE
                val ground = 410f

                drawPath(
                    Path().apply {
                        moveTo(0f, 320f * h)
                        lineTo(70f * k, 285f * h)
                        lineTo(145f * k, 330f * h)
                        lineTo(245f * k, 280f * h)
                        lineTo(360f * k, 325f * h)
                        lineTo(360f * k, ground * h)
                        lineTo(0f, ground * h)
                        close()
                    },
                    Color(0xFF183B42)
                )

                // GROUND
                drawRect(
                    Color(0xFF102B2C),
                    topLeft = p(0f, ground),
                    size = Size(size.width, size.height - ground * h)
                )

                // TROPICAL HOME
                val houseColor = lerp(
                    Color(0xFF1B2937),
                    Color(0xFF526779),
                    daylight * 0.5f
                )

                drawRoundRect(
                    houseColor,
                    topLeft = p(65f, 250f),
                    size = Size(225f * k, 130f * h),
                    cornerRadius = CornerRadius(7f * k)
                )

                // Roof
                val roof = Path().apply {
                    moveTo(45f * k, 250f * h)
                    lineTo(170f * k, 205f * h)
                    lineTo(310f * k, 250f * h)
                    close()
                }

                drawPath(roof, Color(0xFF35495A))

                // SOLAR PANELS
                val panel = Path().apply {
                    moveTo(105f * k, 226f * h)
                    lineTo(165f * k, 207f * h)
                    lineTo(235f * k, 230f * h)
                    lineTo(175f * k, 249f * h)
                    close()
                }

                drawPath(
                    panel,
                    Color(0xFF123C62)
                )

                // Panel reflections
                for (i in 1..3) {
                    drawLine(
                        Color(0xFF5BA7D4).copy(alpha = 0.6f),
                        p(105f + i * 17f, 226f + i * 5.7f),
                        p(175f + i * 17f, 249f - i * 6f),
                        strokeWidth = 1.2f * k
                    )
                }

                drawLine(
                    Color(0xFF5BA7D4),
                    p(140f, 216f),
                    p(210f, 239f),
                    strokeWidth = 1f * k
                )

                // WINDOWS
                val windowColor = lerp(
                    Color(0xFF183A55),
                    Color(0xFFFFC66D),
                    (1f - daylight) * 0.9f
                )

                listOf(90f, 155f, 220f).forEach { wx ->
                    drawRoundRect(
                        windowColor,
                        topLeft = p(wx, 275f),
                        size = Size(43f * k, 55f * h),
                        cornerRadius = CornerRadius(4f * k)
                    )

                    drawLine(
                        Color(0xFF263A4C),
                        p(wx + 21f, 275f),
                        p(wx + 21f, 330f),
                        strokeWidth = 2f * k
                    )

                    if (daylight < 0.7f) {
                        drawCircle(
                            Color(0xFFFFC66D).copy(alpha = 0.12f),
                            radius = 28f * k,
                            center = p(wx + 21f, 302f)
                        )
                    }
                }

                // INVERTER
                drawRoundRect(
                    Color(0xFFCED8E2),
                    topLeft = p(170f, 345f),
                    size = Size(26f * k, 42f * h),
                    cornerRadius = CornerRadius(4f * k)
                )

                drawCircle(
                    GREEN,
                    radius = 3f * k,
                    center = p(183f, 354f)
                )

                // BATTERY
                val bx = 275f
                val by = 330f
                val bw = 38f
                val bh = 72f

                drawRoundRect(
                    Color(0xFF07121E),
                    topLeft = p(bx, by),
                    size = Size(bw * k, bh * h),
                    cornerRadius = CornerRadius(6f * k)
                )

                val fillHeight =
                    (bh - 6f) * x.soc.coerceIn(0, 100) / 100f

                if (fillHeight > 0f) {
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(GREEN, CYAN)
                        ),
                        topLeft = p(bx + 3f, by + bh - 3f - fillHeight),
                        size = Size(
                            (bw - 6f) * k,
                            fillHeight * h
                        ),
                        cornerRadius = CornerRadius(3f * k)
                    )
                }

                drawRoundRect(
                    Color(0xFF9BAEC1),
                    topLeft = p(bx, by),
                    size = Size(bw * k, bh * h),
                    cornerRadius = CornerRadius(6f * k),
                    style = Stroke(1.5f * k)
                )

                // ENERGY FLOW CONNECTIONS
                fun energyFlow(
                    a: Offset,
                    b: Offset,
                    active: Boolean,
                    color: Color,
                    forward: Boolean
                ) {
                    drawLine(
                        Color.White.copy(alpha = 0.18f),
                        a, b,
                        strokeWidth = 3f * k,
                        cap = StrokeCap.Round
                    )

                    if (!active) return

                    drawLine(
                        color.copy(alpha = 0.3f),
                        a, b,
                        strokeWidth = 7f * k,
                        cap = StrokeCap.Round
                    )

                    drawLine(
                        color,
                        a, b,
                        strokeWidth = 2.4f * k,
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(
                            floatArrayOf(7f * k, 9f * k),
                            if (forward) anim * 16f * k
                            else -anim * 16f * k
                        )
                    )

                    repeat(3) { i ->
                        val t = (
                            (anim + i / 3f) % 1f
                        )

                        val progress = if (forward) t else 1f - t

                        val px = a.x + (b.x - a.x) * progress
                        val py = a.y + (b.y - a.y) * progress

                        drawCircle(
                            color,
                            radius = (2.8f + pulse * 1.8f) * k,
                            center = Offset(px, py)
                        )
                    }
                }

                energyFlow(
                    p(170f, 245f),
                    p(183f, 345f),
                    x.pv > 20,
                    AMBER,
                    true
                )

                energyFlow(
                    p(196f, 365f),
                    p(275f, 365f),
                    x.charge > 20 || x.discharge > 20,
                    if (x.charge > 20) GREEN else RED,
                    x.charge > 20
                )

                energyFlow(
                    p(170f, 365f),
                    p(38f, 365f),
                    x.gridOut > 20 || x.gridIn > 20,
                    if (x.gridOut > 20) CYAN else BLUE,
                    x.gridOut > 20
                )

                energyFlow(
                    p(183f, 388f),
                    p(183f, 405f),
                    x.load > 20,
                    VIOLET,
                    true
                )

                // SOLAR GLOW
                drawCircle(
                    AMBER.copy(alpha = 0.12f + pulse * 0.08f),
                    radius = 34f * k,
                    center = p(170f, 235f)
                )

                // GRID POLE
                drawLine(
                    Color(0xFF9CAFC1),
                    p(38f, 350f),
                    p(38f, 285f),
                    strokeWidth = 3f * k
                )

                drawLine(
                    Color(0xFF9CAFC1),
                    p(24f, 295f),
                    p(52f, 295f),
                    strokeWidth = 2f * k
                )
            }

            // HEADER
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            "LUX MONITOR",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )

                        Text(
                            "SMART ENERGY · SMARTER LIVING",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 8.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            weather.uppercase(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            "%02d:%02d".format(now.hour, now.minute),
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // LIVE ENERGY PANELS
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    MobileFlowMetric(
                        "SOLAR",
                        kw(x.pv),
                        AMBER,
                        Modifier.weight(1f)
                    )

                    MobileFlowMetric(
                        "HOME",
                        kw(x.load),
                        VIOLET,
                        Modifier.weight(1f)
                    )
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    MobileFlowMetric(
                        "BATTERY",
                        "${x.soc}%",
                        GREEN,
                        Modifier.weight(1f)
                    )

                    MobileFlowMetric(
                        if (x.gridOut > 20) "GRID EXPORT" else "GRID IMPORT",
                        kw(if (x.gridOut > 20) x.gridOut else x.gridIn),
                        if (x.gridOut > 20) CYAN else BLUE,
                        Modifier.weight(1f)
                    )
                }

                Text(
                    "BATTERY ${x.vBat} V  ·  RUNTIME $rt",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 9.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}


/** Mobile-only photographic hero. LandscapeBoard continues to use the original HeroOrScene renderer. */
@Composable fun MobileTropicalHero(x:Lux,rt:String){
    HeroOrScene(x,rt)
}
@Composable private fun MobileFlowMetric(label:String,value:String,color:Color,modifier:Modifier){
  Column(modifier.clip(RoundedCornerShape(13.dp)).background(Color(0xD90A121B)).padding(horizontal=9.dp,vertical=8.dp)){
    Text(label,fontSize=8.sp,letterSpacing=0.7.sp,color=Color(0xFFB9C5D4),maxLines=1)
    Text(value,fontSize=14.sp,fontWeight=FontWeight.Bold,color=Color(0xFFF1F5F9),maxLines=1)
    Box(Modifier.padding(top=4.dp).fillMaxWidth().height(2.dp).clip(RoundedCornerShape(2.dp)).background(color.copy(alpha=0.78f)))
  }
}

private fun riseSet(sp:SharedPreferences):Pair<Int,Int>{
  val lat=sp.getString("lat","")!!.toDoubleOrNull(); val lon=sp.getString("lon","")!!.toDoubleOrNull()
  return (if(lat!=null&&lon!=null) sunTimes(lat,lon,LocalDate.now()) else null) ?: Pair(390,1110)
}
private fun wxText(w:WxData?,day:Float):String{
  if(w==null) return "Add location"
  return when{
    w.code==0 -> if(day<0.5f) "Clear night" else "Clear"
    w.code in 1..3 -> "Partly cloudy"
    w.code==45||w.code==48 -> "Fog"
    w.code in 51..67||w.code in 80..82 -> "Rain"
    w.code in 71..77||w.code in 85..86 -> "Snow"
    w.code>=95 -> "Thunderstorm"
    else -> "Cloudy"
  }
}
private fun DrawScope.drawCloud(cx:Float,cy:Float,s:Float,k:Float,col:Color,a:Float){
  drawRoundRect(color=col,topLeft=Offset((cx-38f*s)*k,(cy-6f*s)*k),size=Size(76f*s*k,22f*s*k),cornerRadius=CornerRadius(11f*s*k),alpha=a)
  drawCircle(color=col,radius=15f*s*k,center=Offset((cx-14f*s)*k,(cy-6f*s)*k),alpha=a)
  drawCircle(color=col,radius=20f*s*k,center=Offset((cx+6f*s)*k,(cy-10f*s)*k),alpha=a)
  drawCircle(color=col,radius=13f*s*k,center=Offset((cx+26f*s)*k,(cy-4f*s)*k),alpha=a)
}

/** Sky that follows the real time of day (sunrise and sunset from your location), the weather, and the battery/solar state. */
@Composable fun SkyScene(x:Lux,rt:String){
  val sp=LocalContext.current.getSharedPreferences("c",0)
  val tm=rememberTextMeasurer()
  val anim by rememberInfiniteTransition(label="sky").animateFloat(0f,1f,infiniteRepeatable(tween(4000,easing=LinearEasing)),label="a")
  val now=LocalTime.now(); val m=now.hour*60+now.minute
  val (rise,set)=riseSet(sp)
  val w=WxState.data; val code=w?.code?:0; val cloud=w?.cloud?:10
  val dawnT=((m-(rise-40)).toFloat()/80f).coerceIn(0f,1f)
  val duskT=(((set+40)-m).toFloat()/80f).coerceIn(0f,1f)
  val day=minOf(dawnT,duskT)
  val warm=(maxOf(0f,1f-abs((m-rise).toFloat())/50f)+maxOf(0f,1f-abs((m-set).toFloat())/50f)).coerceAtMost(1f)
  val rainy=code in 51..67||code in 80..82||code>=95
  val snowy=code in 71..77||code in 85..86
  val grey=if(rainy||snowy||cloud>70) 0.35f else 0f
  val top=lerp(lerp(Color(0xFF04070D),Color(0xFF0D2440),day),Color(0xFF1B2330),grey)
  val bot=lerp(lerp(lerp(Color(0xFF0B1628),Color(0xFF24527F),day),Color(0xFFE0784A),warm*0.55f),Color(0xFF232B38),grey)
  val inDay=m in rise..set
  val tt=if(inDay) (m-rise).toFloat()/maxOf(1,set-rise).toFloat()
    else ((m-set+1440)%1440).toFloat()/maxOf(1,(rise-set+1440)%1440).toFloat()
  val clock="%02d:%02d".format(now.hour,now.minute)
  Canvas(Modifier.fillMaxWidth().aspectRatio(360f/330f)){
    val k=size.width/360f
    fun P(a:Float,b:Float)=Offset(a*k,b*k)
    fun pt(u:Float,v:Float)=P(60f+150f*u-16f*v,140f-36f*v)
    val ground=236f
    val facade=lerp(Color(0xFF0A0F16),lerp(CARD,Color.White,0.09f),0.35f+0.65f*day)
    val facadeHi=lerp(facade,Color.White,0.06f)
    val edge=lerp(LINE,LINE2,0.5f)
    val carC=lerp(Color(0xFFE6EDF5),CARD,(1f-day)*0.4f)
    // sky and ground
    drawRect(brush=Brush.verticalGradient(listOf(top,bot),0f,ground*k),size=Size(size.width,ground*k))
    drawRect(brush=Brush.verticalGradient(listOf(lerp(bot,Color.Black,0.5f),BG),ground*k,size.height),topLeft=Offset(0f,ground*k),size=Size(size.width,size.height-ground*k))
    // stars at night
    val starA=(1f-day)*(if(cloud>60) 0.35f else 0.9f)
    if(starA>0.02f){
      val rnd=java.util.Random(11)
      repeat(70){
        val sx=rnd.nextFloat()*360f; val sy=rnd.nextFloat()*200f; val ph=rnd.nextFloat()*6.28f
        drawCircle(color=Color.White,radius=(0.6f+rnd.nextFloat()*0.9f)*k,center=P(sx,sy),alpha=starA*(0.55f+0.45f*sin(anim*6.28f+ph)))
      }
    }
    // sun by day, moon by night, both travelling the same arc
    val ax=40f+280f*tt; val ay=118f-92f*sin(Math.PI.toFloat()*tt)
    if(day>0.05f){
      val sc=P(ax,ay)
      drawCircle(brush=Brush.radialGradient(colors=listOf(Color(0xFFFDE68A).copy(alpha=0.5f*day),Color.Transparent),center=sc,radius=70f*k),radius=70f*k,center=sc)
      drawCircle(color=Color(0xFFFDE68A),radius=13f*k,center=sc,alpha=day)
    }
    if(day<0.95f){
      val mc=P(ax,ay); val ma=1f-day
      drawCircle(color=Color(0xFFE2E8F0),radius=11f*k,center=mc,alpha=ma)
      drawCircle(color=top,radius=10f*k,center=mc+Offset(5f*k,-3f*k),alpha=ma)
    }
    // clouds: more cover, more clouds; rain adds two more
    val nClouds=(when{ cloud<15->0; cloud<40->2; cloud<70->4; else->6 })+(if(rainy) 2 else 0)
    val cCol=lerp(Color(0xFF8DA2BF),Color(0xFF2A3446),1f-day)
    repeat(nClouds){ i->
      val cx=(((i*97+40)%400).toFloat()+anim*60f*(1f+(i%3)*0.3f))%400f-20f
      val cy=40f+((i*29)%70).toFloat()
      drawCloud(cx,cy,0.9f+(i%3)*0.25f,k,cCol,0.3f+0.35f*(cloud/100f))
    }
    if(rainy){ repeat(42){ i->
      val x=((i*53)%360).toFloat(); val y=((((i*41)%250).toFloat()+anim*250f)%250f)+40f
      if(y<ground-4f) drawLine(color=Color(0xFF9ED8FF),start=P(x,y),end=P(x-5f,y+12f),strokeWidth=1.2f*k,cap=StrokeCap.Round,alpha=0.4f)
    } }
    if(snowy){ repeat(36){ i->
      val x=((i*61)%360).toFloat(); val y=((((i*43)%250).toFloat()+anim*250f)%250f)+40f
      if(y<ground-4f) drawCircle(color=Color.White,radius=1.8f*k,center=P(x,y),alpha=0.7f)
    } }
    if(code==45||code==48) drawRect(color=Color(0xFFB8C4D6),topLeft=P(0f,150f),size=Size(size.width,80f*k),alpha=0.22f)
    if(code>=95&&anim>0.94f) drawRect(color=Color.White,alpha=0.12f)
    // horizon
    drawLine(color=lerp(Color(0xFFE0784A),LINE2,0.6f).copy(alpha=0.25f+0.35f*warm),start=P(0f,ground),end=P(360f,ground),strokeWidth=1f*k)
    // grid pole
    val pole=lerp(Color(0xFF8A99AD),LINE2,0.3f)
    drawLine(color=pole,start=P(28f,ground),end=P(28f,118f),strokeWidth=2.5f*k,cap=StrokeCap.Round)
    drawLine(color=pole,start=P(16f,128f),end=P(40f,128f),strokeWidth=2f*k,cap=StrokeCap.Round)
    drawLine(color=pole.copy(alpha=0.6f),start=P(16f,128f),end=P(2f,142f),strokeWidth=0.8f*k)
    drawLine(color=pole.copy(alpha=0.6f),start=P(40f,128f),end=P(56f,142f),strokeWidth=0.8f*k)
    // house: main block, cantilever upper box, garage with car
    drawRoundRect(color=facade,topLeft=P(56f,140f),size=Size(158f*k,96f*k),cornerRadius=CornerRadius(4f*k))
    drawRoundRect(color=lerp(facade,Color.White,0.12f),topLeft=P(48f,132f),size=Size(176f*k,10f*k),cornerRadius=CornerRadius(3f*k))
    drawRoundRect(color=facadeHi,topLeft=P(214f,108f),size=Size(86f*k,42f*k),cornerRadius=CornerRadius(4f*k))
    drawRoundRect(color=lerp(facadeHi,Color.White,0.12f),topLeft=P(208f,102f),size=Size(98f*k,8f*k),cornerRadius=CornerRadius(3f*k))
    drawRoundRect(color=facade,topLeft=P(262f,186f),size=Size(82f*k,50f*k),cornerRadius=CornerRadius(3f*k))
    drawRoundRect(color=lerp(facade,Color.White,0.12f),topLeft=P(258f,180f),size=Size(90f*k,7f*k),cornerRadius=CornerRadius(3f*k))
    drawRect(color=Color(0xFF05080D),topLeft=P(270f,196f),size=Size(66f*k,40f*k))
    drawRoundRect(color=carC,topLeft=P(276f,212f),size=Size(60f*k,16f*k),cornerRadius=CornerRadius(7f*k))
    drawRoundRect(color=carC,topLeft=P(288f,203f),size=Size(34f*k,12f*k),cornerRadius=CornerRadius(6f*k))
    drawCircle(color=Color(0xFF05080D),radius=4f*k,center=P(288f,230f))
    drawCircle(color=Color(0xFF05080D),radius=4f*k,center=P(326f,230f))
    // windows: dark glass by day, warm light by night
    fun win(x0:Float,y0:Float,w0:Float,h0:Float){
      drawRoundRect(color=lerp(Color(0xFF0A1220),Color(0xFF2A4A6E),day*0.6f),topLeft=P(x0,y0),size=Size(w0*k,h0*k),cornerRadius=CornerRadius(3f*k))
      drawRoundRect(color=lerp(Color(0xFF3A2A12),AMBER,0.85f),topLeft=P(x0,y0),size=Size(w0*k,h0*k),cornerRadius=CornerRadius(3f*k),alpha=(1f-day)*0.9f)
      drawRoundRect(brush=Brush.verticalGradient(listOf(Color.White.copy(alpha=0.14f*day),Color.Transparent),y0*k,(y0+h0)*k),topLeft=P(x0,y0),size=Size(w0*k,h0*k),cornerRadius=CornerRadius(3f*k))
      drawLine(color=lerp(facade,Color.White,0.25f),start=P(x0+w0/2f,y0),end=P(x0+w0/2f,y0+h0),strokeWidth=1.5f*k)
      if(day<0.9f) drawCircle(color=AMBER,radius=38f*k,center=P(x0+w0/2f,y0+h0/2f),alpha=0.08f*(1f-day))
    }
    win(72f,164f,50f,40f); win(132f,164f,50f,40f); win(226f,118f,62f,20f)
    // solar array on the roof plane
    val pp=Path().apply{ val a=pt(0f,0f); val b=pt(1f,0f); val c=pt(1f,1f); val d=pt(0f,1f); moveTo(a.x,a.y); lineTo(b.x,b.y); lineTo(c.x,c.y); lineTo(d.x,d.y); close() }
    drawPath(path=pp,color=lerp(Color(0xFF0C2238),Color(0xFF1F4C7A),day))
    for(i in 1..3) drawLine(color=Color(0xFF2B5C84),start=pt(i/4f,0f),end=pt(i/4f,1f),strokeWidth=1f*k)
    drawLine(color=Color(0xFF2B5C84),start=pt(0f,0.5f),end=pt(1f,0.5f),strokeWidth=1f*k)
    drawPath(path=pp,color=Color.White,alpha=0.05f+0.08f*day,style=Stroke(1.2f*k))
    // inverter on the wall
    drawRoundRect(color=lerp(Color(0xFFD8E0EA),Color(0xFF3A4656),1f-day),topLeft=P(190f,186f),size=Size(18f*k,24f*k),cornerRadius=CornerRadius(3f*k))
    drawCircle(color=GREEN,radius=1.6f*k,center=P(199f,197f))
    // battery stack, filled to the state of charge
    val bx=222f; val byy=196f; val bw=24f; val bh=40f
    drawRoundRect(color=Color(0xFF0E1622),topLeft=P(bx,byy),size=Size(bw*k,bh*k),cornerRadius=CornerRadius(3f*k))
    val fh=(bh-4f)*x.soc/100f
    if(fh>0.5f) drawRoundRect(brush=Brush.verticalGradient(listOf(GREEN,CYAN),(byy+bh-2f-fh)*k,(byy+bh-2f)*k),topLeft=P(bx+2f,byy+bh-2f-fh),size=Size((bw-4f)*k,fh*k),cornerRadius=CornerRadius(2f*k))
    for(j in 1..2) drawLine(color=Color(0xFF05080D).copy(alpha=0.6f),start=P(bx+2f,byy+bh*j/3f),end=P(bx+bw-2f,byy+bh*j/3f),strokeWidth=1f*k)
    drawRoundRect(color=edge,topLeft=P(bx,byy),size=Size(bw*k,bh*k),cornerRadius=CornerRadius(3f*k),style=Stroke(1f*k))
    drawRect(color=edge,topLeft=P(bx+8f,byy-3f),size=Size(8f*k,3f*k))
    // animated power flows
    fun flow(a:Offset,b:Offset,on:Boolean,col:Color,fwd:Boolean){
      if(!on){ drawLine(color=LINE2.copy(alpha=0.5f),start=a,end=b,strokeWidth=2f*k,cap=StrokeCap.Round); return }
      val ph=(if(fwd) 1f-anim else anim)*12f*k
      drawLine(color=col.copy(alpha=0.25f),start=a,end=b,strokeWidth=5f*k,cap=StrokeCap.Round)
      drawLine(color=col,start=a,end=b,strokeWidth=2.6f*k,cap=StrokeCap.Round,pathEffect=PathEffect.dashPathEffect(floatArrayOf(6f*k,8f*k),ph))
    }
    flow(pt(0.5f,0f),P(199f,186f),x.pv>20,AMBER,true)
    flow(P(208f,200f),P(222f,210f),x.charge>20||x.discharge>20,if(x.charge>20) GREEN else RED,x.charge>20)
    flow(P(190f,206f),P(30f,206f),x.gridOut>20||x.gridIn>20,if(x.gridOut>20) CYAN else BLUE,x.gridOut>20)
    flow(P(199f,210f),P(199f,234f),x.load>20,VIOLET,true)
    // readouts
    label(tm,"${x.soc}%",14f*k,34f*k,30f*k,WHITE,mono=true,bold=true)
    label(tm,"Runtime $rt",14f*k,58f*k,11f*k,DIM)
    label(tm,wxText(w,day),236f*k,20f*k,11f*k,WHITE,bold=true)
    label(tm,clock,236f*k,36f*k,11f*k,DIM,mono=true)
    label(tm,"SOLAR",150f*k,66f*k,9f*k,AMBER,center=true)
    label(tm,kw(x.pv),150f*k,82f*k,15f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,if(x.gridOut>20) "TO GRID" else "FROM GRID",14f*k,252f*k,9f*k,if(x.gridOut>20) CYAN else BLUE)
    label(tm,kw(if(x.gridOut>20) x.gridOut else x.gridIn),14f*k,268f*k,14f*k,WHITE,mono=true,bold=true)
    label(tm,"HOME",199f*k,252f*k,9f*k,VIOLET,center=true)
    label(tm,kw(x.load),199f*k,268f*k,14f*k,WHITE,mono=true,bold=true,center=true)
    label(tm,if(x.charge>20) "CHARGING" else if(x.discharge>20) "DISCHARGING" else "BATTERY",262f*k,252f*k,9f*k,GREEN)
    label(tm,"${x.soc}%",262f*k,268f*k,14f*k,WHITE,mono=true,bold=true)
  }
}
