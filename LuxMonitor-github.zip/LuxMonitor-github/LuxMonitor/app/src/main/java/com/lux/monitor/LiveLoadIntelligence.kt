package com.lux.monitor

import android.content.SharedPreferences
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

/**
 * Compact live household-load card.
 *
 * The inverter reading is the measured total. The baseline and manually configured
 * appliances are estimates only; this card deliberately does not claim that a
 * manually configured appliance is currently running.
 */
@Composable
fun LiveLoadIntelligenceCard(
    actualLoadW: Number,
    baselineWatts: Number?,
    sp: SharedPreferences
) {
    val actual = actualLoadW.toDouble().coerceAtLeast(0.0)
    val baseline = (baselineWatts?.toDouble() ?: 0.0).coerceAtLeast(0.0)
    val unclassified = (actual - baseline).coerceAtLeast(0.0)
    val manualItems = Appl.load(sp)
    val configuredWatts = manualItems.sumOf { it.w }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "LIVE LOAD INTELLIGENCE",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Measured household load",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${actual.toInt()} W",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column {
                    Text(
                        text = "Above baseline",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${unclassified.toInt()} W",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Text(
                text = if (baselineWatts == null) {
                    "Always-on baseline: not available"
                } else {
                    "Estimated always-on baseline: ${baseline.toInt()} W"
                },
                style = MaterialTheme.typography.bodyMedium
            )

            if (actual < baseline) {
                Text(
                    text = "The measured load is below the baseline estimate. Check the baseline setting; the live reading has not been altered.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            if (manualItems.isNotEmpty()) {
                Text(
                    text = "Configured appliance estimates",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                manualItems.take(4).forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = item.name,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "${item.w.toInt()} W",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                if (manualItems.size > 4) {
                    Text(
                        text = "+ ${manualItems.size - 4} more configured items",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "Configured items are estimates, not confirmation that they are running now. Combined configured rating: ${configuredWatts.toInt()} W.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = "Add steady appliances in Extras to show their configured estimates here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "The remaining load above baseline is not yet identified by appliance.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
